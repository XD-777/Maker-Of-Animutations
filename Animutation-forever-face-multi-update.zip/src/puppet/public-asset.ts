import { previewPathPrefix } from "@/lib/preview-path-prefix";

/** Absolute URL that still works when the preview is mounted under a path prefix. */
export function publicAsset(path: string): string {
  const clean = path.startsWith("/") ? path : `/${path}`;
  if (typeof window === "undefined") return clean;
  const prefix = previewPathPrefix(window.location.hostname, window.location.pathname) ?? "";
  return `${prefix}${clean}`;
}
