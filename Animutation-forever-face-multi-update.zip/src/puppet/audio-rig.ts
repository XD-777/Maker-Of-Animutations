import type { AudioLevels } from "./types";

export type SourceKind = "none" | "mic" | "file";

/** Mic stream and context, readable from the rest of the app after the user accepts. */
export let micStream: MediaStream | null = null;
export let micAudioContext: AudioContext | null = null;

function publishMic(stream: MediaStream | null, ctx: AudioContext | null) {
  micStream = stream;
  micAudioContext = ctx;
  if (typeof window === "undefined") return;
  const host = window as Window & { micStream?: MediaStream | null; micAudioContext?: AudioContext | null };
  host.micStream = stream;
  host.micAudioContext = ctx;
}

export class AudioRig {
  readonly ctx: AudioContext;
  private readonly analyser: AnalyserNode;
  private readonly audible: GainNode;
  private readonly freq: Uint8Array<ArrayBuffer>;
  private readonly time: Uint8Array<ArrayBuffer>;
  private kind: SourceKind = "none";
  private stream: MediaStream | null = null;
  private micNode: MediaStreamAudioSourceNode | null = null;
  private fileEl: HTMLAudioElement | null = null;
  private fileNode: MediaElementAudioSourceNode | null = null;
  private fileUrl: string | null = null;
  private tap: MediaStreamAudioDestinationNode | null = null;
  private micSilent: GainNode | null = null;
  private prevLevel = 0;
  volume = 0.85;

  constructor() {
    const ctx = new AudioContext();
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 1024;
    analyser.smoothingTimeConstant = 0.72;
    const audible = ctx.createGain();
    audible.gain.value = this.volume;
    audible.connect(ctx.destination);
    audible.connect(analyser);
    const mute = ctx.createGain();
    mute.gain.value = 0;
    analyser.connect(mute);
    mute.connect(ctx.destination);
    this.ctx = ctx;
    this.analyser = analyser;
    this.audible = audible;
    this.freq = new Uint8Array(analyser.frequencyBinCount);
    this.time = new Uint8Array(analyser.fftSize);
    publishMic(null, ctx);
  }

  /** Call from the click handler so the context resumes inside the user gesture. */
  arm(): Promise<void> {
    if (this.ctx.state === "running") return Promise.resolve();
    return this.ctx.resume().then(() => undefined);
  }

  async ensure() {
    await this.arm();
  }

  setVolume(value: number) {
    this.volume = value;
    this.audible.gain.value = value;
  }

  getKind(): SourceKind {
    return this.kind;
  }

  getMicStream(): MediaStream | null {
    return this.kind === "mic" ? this.stream : null;
  }

  sample(): AudioLevels {
    this.analyser.getByteTimeDomainData(this.time);
    this.analyser.getByteFrequencyData(this.freq);
    let sum = 0;
    for (let i = 0; i < this.time.length; i++) {
      const x = ((this.time[i] ?? 128) - 128) / 128;
      sum += x * x;
    }
    const rms = Math.sqrt(sum / this.time.length);
    const level = Math.min(1, rms * 3.4);
    const n = this.freq.length;
    const bassN = Math.max(2, Math.floor(n * 0.08));
    let bass = 0;
    let lowMid = 0;
    let highMid = 0;
    const lm1 = Math.floor(n * 0.28);
    const hm1 = Math.floor(n * 0.6);
    for (let i = 0; i < n; i++) {
      const v = (this.freq[i] ?? 0) / 255;
      if (i < bassN) bass += v;
      else if (i < lm1) lowMid += v;
      else if (i < hm1) highMid += v;
    }
    bass /= bassN;
    const lm = lowMid / Math.max(1, lm1 - bassN);
    const hm = highMid / Math.max(1, hm1 - lm1);
    const tilt = Math.max(-1, Math.min(1, (hm - lm) * 2.4));
    const onset = Math.max(0, level - this.prevLevel);
    this.prevLevel = level;
    return { level, bass: Math.min(1, bass * 1.6), tilt, onset };
  }

  private hush(except: SourceKind) {
    if (except !== "file" && this.fileEl && !this.fileEl.paused) this.fileEl.pause();
    if (except !== "mic" && (this.micNode || this.stream)) {
      this.micNode?.disconnect();
      this.micNode = null;
      this.micSilent?.disconnect();
      this.micSilent = null;
      this.stream?.getTracks().forEach((track) => track.stop());
      this.stream = null;
      publishMic(null, this.ctx);
    }
  }

  async startMic() {
    const resume = this.arm();
    if (!window.isSecureContext) {
      throw new Error(
        "El micrófono solo se puede pedir en una página segura (https). Sube un MP3 o WAV: esa opción sigue funcionando.",
      );
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error(
        "Este navegador o el iframe bloqueó el micrófono (no hay mediaDevices). Sube un MP3 o WAV: esa opción sigue funcionando.",
      );
    }
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
    } catch (err) {
      const name = err instanceof DOMException ? err.name : "";
      if (name === "NotAllowedError" || name === "PermissionDeniedError" || name === "SecurityError") {
        throw new Error(
          "Permiso denegado. El navegador o el iframe bloqueó el micrófono. Ábrelo en el candado de la barra, o sube un MP3/WAV.",
        );
      }
      if (name === "NotFoundError" || name === "OverconstrainedError") {
        throw new Error("No encontré un micrófono en este dispositivo. Puedes subir un MP3 o WAV igualmente.");
      }
      if (name === "NotReadableError" || name === "AbortError") {
        throw new Error("El micrófono está ocupado o se canceló el permiso. Prueba de nuevo, o sube un MP3/WAV.");
      }
      throw new Error("No pude pedir permiso para el micrófono. Sube un MP3 o WAV para mover la boca.");
    }
    const track = stream.getAudioTracks()[0];
    if (!track || track.readyState === "ended") {
      stream.getTracks().forEach((item) => item.stop());
      throw new Error("El permiso se abrió, pero el micrófono no entregó audio. Prueba de nuevo o sube un MP3/WAV.");
    }
    try {
      await resume;
      if (this.ctx.state !== "running") await this.ctx.resume();
    } catch {
      stream.getTracks().forEach((item) => item.stop());
      throw new Error("No pude activar el audio del navegador. Pulsa el micrófono otra vez.");
    }
    if (this.ctx.state !== "running") {
      stream.getTracks().forEach((item) => item.stop());
      throw new Error("El navegador dejó el audio en pausa. Vuelve a pulsar el micrófono.");
    }
    this.hush("mic");
    this.micNode?.disconnect();
    this.micSilent?.disconnect();
    this.stream?.getTracks().forEach((item) => item.stop());
    this.stream = stream;
    publishMic(stream, this.ctx);
    const source = this.ctx.createMediaStreamSource(stream);
    const silent = this.ctx.createGain();
    silent.gain.value = 0;
    source.connect(this.analyser);
    source.connect(silent);
    silent.connect(this.ctx.destination);
    this.micNode = source;
    this.micSilent = silent;
    this.kind = "mic";
    track.onended = () => {
      if (this.stream === stream) {
        this.micNode?.disconnect();
        this.micNode = null;
        this.micSilent?.disconnect();
        this.micSilent = null;
        this.stream = null;
        publishMic(null, this.ctx);
        if (this.kind === "mic") this.kind = "none";
      }
    };
  }

  async loadFile(file: File) {
    await this.ensure();
    this.hush("file");
    if (!this.fileEl) {
      this.fileEl = new Audio();
      this.fileEl.preload = "auto";
      this.fileNode = this.ctx.createMediaElementSource(this.fileEl);
      this.fileNode.connect(this.audible);
    }
    if (this.fileUrl) URL.revokeObjectURL(this.fileUrl);
    this.fileUrl = URL.createObjectURL(file);
    this.fileEl.src = this.fileUrl;
    try {
      await this.fileEl.play();
    } catch {
      throw new Error("Ese audio no se pudo leer. Prueba con un MP3 o WAV.");
    }
    this.kind = "file";
  }

  fileIsPaused(): boolean {
    return !this.fileEl || this.fileEl.paused;
  }

  async toggleFile() {
    if (!this.fileEl) return;
    await this.ensure();
    if (this.fileEl.paused) {
      this.hush("file");
      await this.fileEl.play();
      this.kind = "file";
    } else {
      this.fileEl.pause();
    }
  }

  suspendAudible() {
    if (this.fileEl && !this.fileEl.paused) this.fileEl.pause();
    if (this.micNode || this.stream) {
      this.micNode?.disconnect();
      this.micNode = null;
      this.micSilent?.disconnect();
      this.micSilent = null;
      this.stream?.getTracks().forEach((track) => track.stop());
      this.stream = null;
      publishMic(null, this.ctx);
      if (this.kind === "mic") this.kind = "none";
    }
  }

  async resumeSelected() {
    if (this.kind === "file") await this.toggleFileIfPaused();
    else if (this.kind === "mic") await this.startMic();
  }

  /** Speakers tap for MediaRecorder. Mic stays out of the speakers. */
  captureAudio(): MediaStream | null {
    if (this.kind !== "file") return null;
    if (!this.tap) {
      this.tap = this.ctx.createMediaStreamDestination();
      this.audible.connect(this.tap);
    }
    return this.tap.stream;
  }

  private async toggleFileIfPaused() {
    if (this.fileEl && this.fileEl.paused) {
      this.hush("file");
      await this.fileEl.play();
    }
  }

  close() {
    this.suspendAudible();
    this.stream?.getTracks().forEach((track) => track.stop());
    if (this.fileUrl) URL.revokeObjectURL(this.fileUrl);
    void this.ctx.close();
  }
}
