import { publicAsset } from "./public-asset";
import type { Markers } from "./types";

/** Markers sit on the Bean photo: eyes, lip line, and chin flap. */
export function beanMarkers(w: number, h: number): Markers {
  const sx = w / 384;
  const sy = h / 520;
  const p = (x: number, y: number) => ({ x: x * sx, y: y * sy });
  return {
    eyeL: p(158, 258),
    eyeR: p(228, 255),
    nose: p(198, 300),
    mouth: [p(178, 318), p(192, 328), p(206, 332), p(220, 328), p(240, 318)],
    jaw: [p(170, 340), p(160, 370), p(175, 400), p(206, 418), p(235, 400), p(250, 370), p(246, 340)],
  };
}

export async function createSample(): Promise<{ canvas: HTMLCanvasElement; markers: Markers }> {
  const img = await loadBean();
  const canvas = document.createElement("canvas");
  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("No se pudo preparar el personaje.");
  ctx.drawImage(img, 0, 0);
  return { canvas, markers: beanMarkers(canvas.width, canvas.height) };
}

function loadBean(): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("No pude cargar el personaje."));
    img.src = publicAsset("/bean.jpg");
  });
}
