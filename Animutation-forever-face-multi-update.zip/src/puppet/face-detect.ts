import { markersFromBox, markersFromLandmarks } from "./markers";
import { publicAsset } from "./public-asset";
import type { Markers, Pt } from "./types";

export type DetectOutcome =
  | { ok: true; markers: Markers; precise: boolean }
  | { ok: false; message: string };

type Landmark = { x: number; y: number };

type Landmarker = {
  detect: (image: CanvasImageSource) => { faceLandmarks: Landmark[][] };
};

let landmarkerPromise: Promise<Landmarker> | null = null;

async function loadLandmarker(): Promise<Landmarker> {
  if (!landmarkerPromise) {
    landmarkerPromise = (async () => {
      const vision = (await import("@mediapipe/tasks-vision")) as {
        FilesetResolver: { forVisionTasks: (basePath?: string) => Promise<unknown> };
        FaceLandmarker: {
          createFromOptions: (
            fileset: unknown,
            options: unknown,
          ) => Promise<Landmarker>;
        };
      };
      const fileset = await vision.FilesetResolver.forVisionTasks(publicAsset("/mediapipe"));
      return vision.FaceLandmarker.createFromOptions(fileset, {
        baseOptions: {
          modelAssetPath: publicAsset("/models/face_landmarker.task"),
          delegate: "CPU",
        },
        runningMode: "IMAGE",
        numFaces: 1,
        minFaceDetectionConfidence: 0.35,
        minFacePresenceConfidence: 0.35,
      });
    })().catch((err: unknown) => {
      landmarkerPromise = null;
      throw err;
    });
  }
  return landmarkerPromise;
}

type FaceBox = { x: number; y: number; width: number; height: number; left?: number; top?: number };
type FaceLandmark = { type?: string; locations?: Array<{ x: number; y: number }> };
type DetectedFace = { boundingBox: FaceBox; landmarks?: FaceLandmark[] };
type FaceDetectorLike = { detect: (source: CanvasImageSource) => Promise<DetectedFace[]> };

function shapeDetector(): FaceDetectorLike | null {
  const ctor = (
    window as unknown as {
      FaceDetector?: new (opts?: { fastMode?: boolean; maxDetectedFaces?: number }) => FaceDetectorLike;
    }
  ).FaceDetector;
  if (!ctor) return null;
  try {
    return new ctor({ fastMode: false, maxDetectedFaces: 1 });
  } catch {
    return null;
  }
}

export async function detectFace(canvas: HTMLCanvasElement): Promise<DetectOutcome> {
  try {
    const landmarker = await loadLandmarker();
    const result = landmarker.detect(canvas);
    const face = result.faceLandmarks[0];
    if (face) {
      const markers = markersFromLandmarks(face, canvas.width, canvas.height);
      if (markers) return { ok: true, markers, precise: true };
    }
  } catch (err) {
    console.warn("MediaPipe no pudo detectar", err);
  }

  const basic = await detectWithShape(canvas);
  if (basic) return { ok: true, markers: basic, precise: false };

  return {
    ok: false,
    message:
      "No veo un rostro claro en esta imagen. No pasa nada: coloca los puntos con el dedo o el mouse. Funciona igual con dibujos.",
  };
}

async function detectWithShape(canvas: HTMLCanvasElement): Promise<Markers | null> {
  const detector = shapeDetector();
  if (!detector) return null;
  let faces: DetectedFace[] = [];
  try {
    faces = await detector.detect(canvas);
  } catch {
    return null;
  }
  const face = faces[0];
  if (!face?.boundingBox) return null;
  const box = face.boundingBox;
  const x = box.x ?? box.left ?? 0;
  const y = box.y ?? box.top ?? 0;
  const markers = markersFromBox(x, y, box.width, box.height);
  let eyeL: Pt | null = null;
  let eyeR: Pt | null = null;
  let nose: Pt | null = null;
  let mouth: Pt | null = null;
  for (const landmark of face.landmarks ?? []) {
    const loc = landmark.locations?.[0];
    if (!loc) continue;
    const p = { x: loc.x, y: loc.y };
    if (landmark.type === "eye") {
      if (!eyeL || p.x < eyeL.x) {
        if (eyeL) eyeR = eyeL;
        eyeL = p;
      } else {
        eyeR = p;
      }
    } else if (landmark.type === "nose") nose = p;
    else if (landmark.type === "mouth") mouth = p;
  }
  if (eyeL) markers.eyeL = eyeL;
  if (eyeR) markers.eyeR = eyeR;
  if (nose) markers.nose = nose;
  if (mouth) {
    const dx = mouth.x - (markers.mouth[2]?.x ?? mouth.x);
    const dy = mouth.y - (markers.mouth[2]?.y ?? mouth.y);
    markers.mouth = markers.mouth.map((p) => ({ x: p.x + dx, y: p.y + dy }));
  }
  return markers;
}
