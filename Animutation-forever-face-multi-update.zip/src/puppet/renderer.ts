import { cutPath, mapMarkers, mouthAngle, mouthOpenPx } from "./markers";
import type { AudioLevels, FaceSlot, Fx, Markers, View } from "./types";

type Layers = { upper: HTMLCanvasElement; jaw: HTMLCanvasElement; cut: Path2D; key: string };

const PALETTE = ["#ff2f7b", "#ffe14a", "#3dffe8", "#fff6df"];

export class PuppetRenderer {
  private canvas: HTMLCanvasElement | null = null;
  private image: HTMLCanvasElement | null = null;
  private markers: Markers | null = null;
  private view: View = { scale: 1, ox: 0, oy: 0 };
  private layers: Layers | null = null;
  private stars = makeStars(48);
  private t = 0;
  private mouth = 0;
  private bassSmooth = 0;
  private tiltSmooth = 0;
  private autoPeak = 0.05;
  private bassPeak = 0.05;

  private imageToken = 0;
  private faces: FaceSlot[] = [];
  private scratch: HTMLCanvasElement | null = null;
  private patchCache = new Map<string, { key: string; local: HTMLCanvasElement; layers: Layers; localMarkers: Markers }>();

  setFaces(faces: FaceSlot[]) {
    this.faces = faces;
  }

  attach(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
  }

  setScene(image: HTMLCanvasElement, markers: Markers, view: View) {
    if (this.image !== image) {
      this.imageToken += 1;
      this.layers = null;
    }
    this.image = image;
    this.markers = markers;
    this.view = view;
  }

  resetMotion() {
    this.mouth = 0;
    this.bassSmooth = 0;
    this.tiltSmooth = 0;
    this.t = 0;
  }

  drawEdit(mouthWidth = 1) {
    const ctx = this.prep();
    if (!ctx || !this.image || !this.markers) return;
    const { dpr, w, h } = this.size();
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    drawChecker(ctx, w, h);
    this.blitImage(ctx, dpr, this.image);
    if (this.faces.length > 0) this.strokeFaceGuides(ctx, dpr, mouthWidth);
    else this.strokeGuides(ctx, dpr, mouthWidth);
  }

  frame(dt: number, levels: AudioLevels, fx: Fx, reduceMotion: boolean) {
    const ctx = this.prep();
    if (!ctx || !this.image || !this.markers) return;
    const { dpr, w, h } = this.size();
    this.t += dt;
    this.follow(dt, levels, fx.sensitivity);
    const markers = this.markers;
    const faceH = Math.max(
      40,
      Math.max(...markers.jaw.map((p) => p.y)) - Math.min(markers.eyeL.y, markers.eyeR.y),
    );
    const openPx = mouthOpenPx(markers, this.mouth, fx.mouthMax ?? 1, fx.mouthWidth ?? 1);
    const backdropSpin = reduceMotion ? 0.15 : 1;
    const mouthOnly = fx.mouthOnly === true;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    drawBackdrop(ctx, w, h, this.t * backdropSpin, fx, this.stars);

    if (this.faces.length > 0) {
      const view = this.view;
      ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.ox, dpr * view.oy);
      ctx.drawImage(this.image, 0, 0);
      for (const face of this.faces) {
        const patch = this.renderFace(face, this.mouth, fx, reduceMotion, mouthOnly);
        ctx.drawImage(patch, face.box.x, face.box.y, face.box.w, face.box.h);
      }
      return;
    }

    const allowSpin = !mouthOnly && fx.spin !== false;
    const headRot = allowSpin ? Math.sin(this.t * 1.7) * (0.035 + this.mouth * 0.1) * (reduceMotion ? 0.35 : 1) : 0;
    const bob = mouthOnly ? 0 : -this.bassSmooth * faceH * 0.045;
    const sway = allowSpin ? Math.sin(this.t * 1.25) * this.mouth * faceH * 0.02 : 0;
    const zoom = !mouthOnly && fx.zoom ? 1 + this.bassSmooth * 0.16 : 1;

    const view = this.view;
    ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.ox, dpr * view.oy);
    const pivot = markers.nose;
    ctx.translate(pivot.x + sway, pivot.y);
    ctx.rotate(headRot);
    ctx.translate(0, bob);
    ctx.scale(zoom, zoom);
    ctx.translate(-pivot.x, -pivot.y);

    const layers = this.ensureLayers(fx.mouthWidth ?? 1);
    drawMouthInterior(ctx, layers.cut);
    ctx.drawImage(layers.upper, 0, 0);
    drawJaw(ctx, layers.jaw, openPx, mouthAngle(markers));
  }

  /** Frozen face, mouth held open, solid black gap. No motion and no soundtrack. */
  drawOpenFace(mouthMax = 1, mouthWidth = 1) {
    const ctx = this.prep();
    if (!ctx || !this.image || !this.markers) return;
    const { dpr, w, h } = this.size();
    const markers = this.markers;
    const openPx = mouthOpenPx(markers, 0.92, mouthMax, mouthWidth);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, w, h);
    const view = this.view;
    ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.ox, dpr * view.oy);
    if (this.faces.length > 0) {
      ctx.drawImage(this.image, 0, 0);
      for (const face of this.faces) {
        const patch = this.renderFace(face, 0.92, { ...STILL_FX, mouthMax, mouthWidth }, true, true);
        ctx.drawImage(patch, face.box.x, face.box.y, face.box.w, face.box.h);
      }
      return;
    }
    const layers = this.ensureLayers(mouthWidth);
    drawMouthInterior(ctx, layers.cut);
    ctx.drawImage(layers.upper, 0, 0);
    drawJaw(ctx, layers.jaw, openPx, mouthAngle(markers));
  }

  private follow(dt: number, levels: AudioLevels, sensitivity: number) {
    this.autoPeak = Math.max(levels.level, this.autoPeak * Math.exp(-dt * 0.45));
    if (this.autoPeak < 0.035) this.autoPeak = 0.035;
    const norm = Math.min(1, levels.level / this.autoPeak);
    const drive = Math.min(1, norm * sensitivity);
    const attack = drive > this.mouth ? 18 : 8;
    this.mouth += (drive - this.mouth) * (1 - Math.exp(-dt * attack));
    this.bassPeak = Math.max(levels.bass, this.bassPeak * Math.exp(-dt * 1.1));
    const bnorm = Math.min(1, levels.bass / Math.max(0.04, this.bassPeak));
    this.bassSmooth += (bnorm - this.bassSmooth) * (1 - Math.exp(-dt * 14));
    const tiltTarget = levels.tilt * this.mouth;
    this.tiltSmooth += (tiltTarget - this.tiltSmooth) * (1 - Math.exp(-dt * 8));
    return drive;
  }

  private ensureLayers(widthScale = 1): Layers {
    if (!this.image || !this.markers) throw new Error("sin escena");
    const key = `${this.imageToken}:${layerKey(this.image, this.markers)}:${widthScale.toFixed(3)}`;
    if (this.layers?.key === key) return this.layers;
    const w = this.image.width;
    const h = this.image.height;
    const cut = cutPath(this.markers, widthScale);
    const upper = document.createElement("canvas");
    upper.width = w;
    upper.height = h;
    const uctx = upper.getContext("2d");
    if (!uctx) throw new Error("lienzo");
    uctx.drawImage(this.image, 0, 0);
    uctx.globalCompositeOperation = "destination-out";
    uctx.fill(cut);

    const jaw = document.createElement("canvas");
    jaw.width = w;
    jaw.height = h;
    const jctx = jaw.getContext("2d");
    if (!jctx) throw new Error("lienzo");
    jctx.save();
    jctx.clip(cut);
    jctx.drawImage(this.image, 0, 0);
    jctx.restore();
    this.layers = { upper, jaw, cut, key };
    return this.layers;
  }

  private prep(): CanvasRenderingContext2D | null {
    const canvas = this.canvas;
    if (!canvas) return null;
    const { dpr, w, h } = this.size();
    const bw = Math.max(1, Math.round(w * dpr));
    const bh = Math.max(1, Math.round(h * dpr));
    if (canvas.width !== bw || canvas.height !== bh) {
      canvas.width = bw;
      canvas.height = bh;
    }
    return canvas.getContext("2d");
  }

  private size() {
    const canvas = this.canvas;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    return {
      dpr,
      w: canvas?.clientWidth ?? 1,
      h: canvas?.clientHeight ?? 1,
    };
  }

  private blitImage(ctx: CanvasRenderingContext2D, dpr: number, image: HTMLCanvasElement) {
    const view = this.view;
    ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.ox, dpr * view.oy);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(image, 0, 0);
  }

  private strokeGuides(ctx: CanvasRenderingContext2D, dpr: number, mouthWidth = 1) {
    if (!this.markers) return;
    const view = this.view;
    ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.ox, dpr * view.oy);
    const weight = 3 / view.scale;
    ctx.save();
    ctx.lineWidth = weight;
    ctx.strokeStyle = "#ffe14a";
    ctx.stroke(cutPath(this.markers, mouthWidth));
    ctx.restore();
    const left = this.markers.mouth[0];
    const right = this.markers.mouth[this.markers.mouth.length - 1];
    if (left && right) {
      ctx.beginPath();
      ctx.moveTo(left.x, left.y);
      ctx.lineTo(right.x, right.y);
      ctx.strokeStyle = "#ff2f7b";
      ctx.lineWidth = weight;
      ctx.lineCap = "round";
      ctx.stroke();
    }
  }

  private renderFace(
    face: FaceSlot,
    mouth: number,
    fx: Fx,
    reduceMotion: boolean,
    mouthOnly: boolean,
  ): HTMLCanvasElement {
    const packed = this.facePatch(face, fx.mouthWidth ?? 1);
    const scratch = this.scratch ?? document.createElement("canvas");
    this.scratch = scratch;
    if (scratch.width !== packed.local.width || scratch.height !== packed.local.height) {
      scratch.width = packed.local.width;
      scratch.height = packed.local.height;
    }
    const ctx = scratch.getContext("2d");
    if (!ctx) return scratch;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, scratch.width, scratch.height);
    const markers = packed.localMarkers;
    const faceH = Math.max(40, Math.max(...markers.jaw.map((p) => p.y)) - Math.min(markers.eyeL.y, markers.eyeR.y));
    const openPx = mouthOpenPx(markers, mouth, fx.mouthMax ?? 1, fx.mouthWidth ?? 1);
    const allowSpin = !mouthOnly && fx.spin !== false;
    const headRot = allowSpin ? Math.sin(this.t * 1.7) * (0.035 + mouth * 0.1) * (reduceMotion ? 0.35 : 1) : 0;
    const bob = mouthOnly ? 0 : -this.bassSmooth * faceH * 0.045;
    const sway = allowSpin ? Math.sin(this.t * 1.25) * mouth * faceH * 0.02 : 0;
    const zoom = !mouthOnly && fx.zoom ? 1 + this.bassSmooth * 0.16 : 1;
    const pivot = markers.nose;
    ctx.translate(pivot.x + sway, pivot.y);
    ctx.rotate(headRot);
    ctx.translate(0, bob);
    ctx.scale(zoom, zoom);
    ctx.translate(-pivot.x, -pivot.y);
    drawMouthInterior(ctx, packed.layers.cut);
    ctx.drawImage(packed.layers.upper, 0, 0);
    drawJaw(ctx, packed.layers.jaw, openPx, mouthAngle(markers));
    return scratch;
  }

  private facePatch(face: FaceSlot, widthScale = 1): { local: HTMLCanvasElement; layers: Layers; localMarkers: Markers } {
    const image = this.image;
    if (!image) throw new Error("sin escena");
    const box = face.box;
    const key = `${this.imageToken}:${Math.round(box.x)}:${Math.round(box.y)}:${Math.round(box.w)}:${Math.round(box.h)}:${layerKey(image, face.markers)}:${widthScale.toFixed(3)}`;
    const cached = this.patchCache.get(face.id);
    if (cached?.key === key) return cached;
    const w = Math.max(2, Math.round(box.w));
    const h = Math.max(2, Math.round(box.h));
    const local = document.createElement("canvas");
    local.width = w;
    local.height = h;
    const lctx = local.getContext("2d");
    if (!lctx) throw new Error("lienzo");
    lctx.drawImage(image, box.x, box.y, box.w, box.h, 0, 0, w, h);
    const sx = w / Math.max(1, box.w);
    const sy = h / Math.max(1, box.h);
    const localMarkers = mapMarkers(face.markers, (p) => ({
      x: (p.x - box.x) * sx,
      y: (p.y - box.y) * sy,
    }));
    const layers = makeLayers(local, localMarkers, widthScale);
    const packed = { key, local, layers, localMarkers };
    this.patchCache.set(face.id, packed);
    return packed;
  }

  private strokeFaceGuides(ctx: CanvasRenderingContext2D, dpr: number, mouthWidth = 1) {
    const view = this.view;
    ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.ox, dpr * view.oy);
    const weight = 3 / view.scale;
    for (const face of this.faces) {
      ctx.save();
      ctx.lineWidth = weight;
      ctx.strokeStyle = "#3dffe8";
      ctx.strokeRect(face.box.x, face.box.y, face.box.w, face.box.h);
      ctx.strokeStyle = "#ffe14a";
      ctx.stroke(cutPath(face.markers, mouthWidth));
      ctx.restore();
    }
  }
}

const STILL_FX: Fx = {
  spiral: false,
  rays: false,
  stars: false,
  zoom: false,
  spin: false,
  mouthOnly: true,
  sensitivity: 1,
  mouthMax: 1,
  mouthWidth: 1,
};

function layerKey(image: HTMLCanvasElement, markers: Markers): string {
  const pts = [markers.eyeL, markers.eyeR, markers.nose, ...markers.mouth, ...markers.jaw];
  const body = pts.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(";");
  return `${image.width}x${image.height}:${body}`;
}

function makeLayers(image: HTMLCanvasElement, markers: Markers, widthScale = 1): Layers {
  const w = image.width;
  const h = image.height;
  const cut = cutPath(markers, widthScale);
  const upper = document.createElement("canvas");
  upper.width = w;
  upper.height = h;
  const uctx = upper.getContext("2d");
  if (!uctx) throw new Error("lienzo");
  uctx.drawImage(image, 0, 0);
  uctx.globalCompositeOperation = "destination-out";
  uctx.fill(cut);
  const jaw = document.createElement("canvas");
  jaw.width = w;
  jaw.height = h;
  const jctx = jaw.getContext("2d");
  if (!jctx) throw new Error("lienzo");
  jctx.save();
  jctx.clip(cut);
  jctx.drawImage(image, 0, 0);
  jctx.restore();
  return { upper, jaw, cut, key: layerKey(image, markers) };
}

function drawChecker(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const size = 18;
  for (let y = 0; y < h; y += size) {
    for (let x = 0; x < w; x += size) {
      const odd = ((x / size) | 0) + ((y / size) | 0);
      ctx.fillStyle = odd % 2 === 0 ? "#241833" : "#1a1028";
      ctx.fillRect(x, y, size, size);
    }
  }
}

function drawBackdrop(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  t: number,
  fx: Fx,
  stars: Star[],
) {
  ctx.fillStyle = "#140c22";
  ctx.fillRect(0, 0, w, h);
  if (fx.rays) {
    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.rotate(t * 0.28);
    const radius = Math.hypot(w, h);
    const slices = 16;
    for (let i = 0; i < slices; i++) {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, radius, (i * Math.PI * 2) / slices, ((i + 1) * Math.PI * 2) / slices);
      ctx.closePath();
      ctx.fillStyle = PALETTE[i % PALETTE.length] ?? "#ffe14a";
      ctx.fill();
    }
    ctx.restore();
  }
  if (fx.spiral) {
    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.rotate(t * 0.45);
    ctx.lineWidth = Math.max(10, w * 0.018);
    ctx.lineCap = "round";
    for (let k = 0; k < 4; k++) {
      ctx.beginPath();
      ctx.strokeStyle = PALETTE[k] ?? "#ff2f7b";
      const off = (k * Math.PI) / 2;
      let started = false;
      for (let a = 0; a < Math.PI * 9; a += 0.14) {
        const r = 6 + a * (Math.max(w, h) * 0.018);
        const x = Math.cos(a + off) * r;
        const y = Math.sin(a + off) * r;
        if (!started) {
          ctx.moveTo(x, y);
          started = true;
        } else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.restore();
  }
  if (fx.stars) {
    for (const star of stars) {
      const tw = 0.55 + Math.sin(t * 2.4 + star.phase) * 0.45;
      const x = star.nx * w;
      const y = star.ny * h;
      drawStar(ctx, x, y, star.r * (0.7 + tw * 0.5), t * star.spin + star.phase, PALETTE[star.color] ?? "#fff6df");
    }
  }
}

function drawMouthInterior(ctx: CanvasRenderingContext2D, cut: Path2D) {
  ctx.save();
  ctx.clip(cut);
  ctx.fillStyle = "#000000";
  ctx.fillRect(-2000, -2000, 8000, 8000);
  ctx.restore();
  ctx.save();
  ctx.strokeStyle = "#000000";
  ctx.lineWidth = 2;
  ctx.stroke(cut);
  ctx.restore();
}

function drawJaw(ctx: CanvasRenderingContext2D, jaw: HTMLCanvasElement, openPx: number, angle = 0) {
  ctx.save();
  ctx.translate(-Math.sin(angle) * openPx, Math.cos(angle) * openPx);
  ctx.drawImage(jaw, 0, 0);
  ctx.restore();
}

type Star = { nx: number; ny: number; r: number; phase: number; spin: number; color: number };

function makeStars(count: number): Star[] {
  let seed = 202003;
  const rand = () => {
    seed = (seed * 16807 + 11) % 2147483647;
    return (seed & 2147483647) / 2147483647;
  };
  const stars: Star[] = [];
  for (let i = 0; i < count; i++) {
    stars.push({
      nx: rand(),
      ny: rand(),
      r: 7 + rand() * 16,
      phase: rand() * Math.PI * 2,
      spin: 0.4 + rand() * 1.2,
      color: i % PALETTE.length,
    });
  }
  return stars;
}

function drawStar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  rot: number,
  color: string,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.fillStyle = color;
  ctx.beginPath();
  for (let i = 0; i < 8; i++) {
    const rad = i % 2 === 0 ? r : r * 0.4;
    const a = -Math.PI / 2 + (i * Math.PI) / 4;
    const px = Math.cos(a) * rad;
    const py = Math.sin(a) * rad;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}
