export type Pt = { x: number; y: number };

/** Mouth is 5 points left → right. Jaw is 7 points left → right around the chin. */
export type Markers = {
  eyeL: Pt;
  eyeR: Pt;
  nose: Pt;
  mouth: Pt[];
  jaw: Pt[];
};

export type View = { scale: number; ox: number; oy: number };

export type Fx = {
  spiral: boolean;
  rays: boolean;
  stars: boolean;
  zoom: boolean;
  spin: boolean;
  mouthOnly: boolean;
  sensitivity: number;
  /** 1 = 100%. Scales how far the jaw flap can drop. */
  mouthMax: number;
  /** 1 = 100%, horizontal mouth width multiplier. */
  mouthWidth: number;
};

export type AudioLevels = {
  level: number;
  bass: number;
  tilt: number;
  onset: number;
};

export type MarkerTone = "cyan" | "yellow" | "pink";

export type MarkerView = {
  id: string;
  pt: Pt;
  label: string;
  short: string;
  tone: MarkerTone;
};

export type CropRect = { x: number; y: number; w: number; h: number };

export type FaceSlot = {
  id: string;
  box: CropRect;
  markers: Markers;
};

export const DEFAULT_FX: Fx = {
  spiral: false,
  rays: true,
  stars: true,
  zoom: true,
  spin: true,
  mouthOnly: false,
  sensitivity: 1,
  mouthMax: 1,
  mouthWidth: 1,
};

export const SILENT: AudioLevels = { level: 0, bass: 0, tilt: 0, onset: 0 };
