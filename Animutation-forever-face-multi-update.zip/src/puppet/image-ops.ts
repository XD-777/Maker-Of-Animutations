import { mapMarkers } from "./markers";
import type { CropRect, Markers } from "./types";

export function cloneCanvas(src: HTMLCanvasElement): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = src.width;
  canvas.height = src.height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("No se pudo preparar el lienzo.");
  ctx.drawImage(src, 0, 0);
  return canvas;
}

export async function canvasFromFile(file: File): Promise<HTMLCanvasElement> {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadHtmlImage(url);
    const maxEdge = 1280;
    const scale = Math.min(1, maxEdge / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.max(1, Math.round(img.naturalWidth * scale));
    const h = Math.max(1, Math.round(img.naturalHeight * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) throw new Error("No se pudo leer la imagen.");
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(img, 0, 0, w, h);
    return canvas;
  } finally {
    URL.revokeObjectURL(url);
  }
}

function loadHtmlImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("No pude abrir esa imagen. Usa JPG, PNG o WebP."));
    img.src = url;
  });
}

/**
 * AI semantic foreground extraction using the IMG.LY background-removal model.
 * Returns a canvas with a real alpha channel; source pixels are not regenerated.
 */
export async function removeBackground(
  src: HTMLCanvasElement,
  _tolerance: number,
  onProgress?: (message: string) => void,
): Promise<HTMLCanvasElement> {
  const toBlob = (canvas: HTMLCanvasElement): Promise<Blob> => new Promise((resolve, reject) => {
    canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("No se pudo preparar la imagen para quitar el fondo.")), "image/png");
  });
  const loadBlob = (blob: Blob): Promise<HTMLImageElement> => new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("No se pudo cargar el resultado del recorte.")); };
    img.src = url;
  });

  // Use a lightweight analysis image; apply only its alpha mask back to the full-resolution source.
  const maxEdge = 512;
  const scale = Math.min(1, maxEdge / Math.max(src.width, src.height));
  const analysis = document.createElement("canvas");
  analysis.width = Math.max(1, Math.round(src.width * scale));
  analysis.height = Math.max(1, Math.round(src.height * scale));
  const analysisCtx = analysis.getContext("2d");
  if (!analysisCtx) throw new Error("No se pudo preparar el análisis de fondo.");
  analysisCtx.drawImage(src, 0, 0, analysis.width, analysis.height);

  // Keep the model as a runtime import to avoid bundling its large dependencies.
  const moduleUrl = "https://esm.sh/@imgly/background-removal@1.5.5";
  const model = await import(/* @vite-ignore */ moduleUrl) as {
    removeBackground: (blob: Blob, options?: { progress?: (key: string, current: number, total: number) => void }) => Promise<Blob>;
  };
  onProgress?.("Cargando modelo ligero (análisis 512 px)…");
  const output = await model.removeBackground(await toBlob(analysis), {
    progress: (key, current, total) => {
      if (total > 0) onProgress?.(`${key}: ${Math.round((current / total) * 100)}%`);
    },
  });
  const maskImage = await loadBlob(output);
  const mask = document.createElement("canvas");
  mask.width = src.width;
  mask.height = src.height;
  const maskCtx = mask.getContext("2d");
  if (!maskCtx) throw new Error("No se pudo aplicar la máscara transparente.");
  maskCtx.imageSmoothingEnabled = true;
  maskCtx.imageSmoothingQuality = "high";
  maskCtx.drawImage(maskImage, 0, 0, mask.width, mask.height);

  // Preserve the original RGB data and use the model only for transparency.
  const result = cloneCanvas(src);
  const resultCtx = result.getContext("2d");
  if (!resultCtx) throw new Error("No se pudo crear el resultado transparente.");
  resultCtx.globalCompositeOperation = "destination-in";
  resultCtx.drawImage(mask, 0, 0);
  resultCtx.globalCompositeOperation = "source-over";
  return result;
}

export function cropImage(
  src: HTMLCanvasElement,
  rect: CropRect,
  markers: Markers,
): { canvas: HTMLCanvasElement; markers: Markers } {
  const x = Math.max(0, Math.round(rect.x));
  const y = Math.max(0, Math.round(rect.y));
  const w = Math.max(1, Math.min(src.width - x, Math.round(rect.w)));
  const h = Math.max(1, Math.min(src.height - y, Math.round(rect.h)));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("No se pudo recortar.");
  ctx.drawImage(src, x, y, w, h, 0, 0, w, h);
  return {
    canvas,
    markers: mapMarkers(markers, (p) => ({ x: p.x - x, y: p.y - y })),
  };
}

export function trimTransparency(
  src: HTMLCanvasElement,
  markers: Markers,
): { canvas: HTMLCanvasElement; markers: Markers; trimmed: boolean } | null {
  const ctx = src.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  const { data, width, height } = ctx.getImageData(0, 0, src.width, src.height);
  let minX = width;
  let minY = height;
  let maxX = -1;
  let maxY = -1;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const a = data[(y * width + x) * 4 + 3] ?? 0;
      if (a > 16) {
        if (x < minX) minX = x;
        if (y < minY) minY = y;
        if (x > maxX) maxX = x;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (maxX < 0) return null;
  const pad = 10;
  const x = Math.max(0, minX - pad);
  const y = Math.max(0, minY - pad);
  const right = Math.min(width - 1, maxX + pad);
  const bottom = Math.min(height - 1, maxY + pad);
  const trimmed = x > 1 || y > 1 || right < width - 2 || bottom < height - 2;
  if (!trimmed) {
    return { canvas: src, markers, trimmed: false };
  }
  const cropped = cropImage(src, { x, y, w: right - x + 1, h: bottom - y + 1 }, markers);
  return { ...cropped, trimmed: true };
}
