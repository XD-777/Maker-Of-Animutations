import type { CropRect, Markers, Pt, View } from "./types";

export function fitView(imgW: number, imgH: number, viewW: number, viewH: number): View {
  const pad = 18;
  const scale = Math.max(
    0.01,
    Math.min((viewW - pad * 2) / imgW, (viewH - pad * 2) / imgH),
  );
  return {
    scale,
    ox: (viewW - imgW * scale) / 2,
    oy: (viewH - imgH * scale) / 2,
  };
}

export function faceView(markers: Markers, viewW: number, viewH: number): View {
  const pts = [markers.eyeL, markers.eyeR, markers.nose, ...markers.mouth, ...markers.jaw];
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const p of pts) {
    minX = Math.min(minX, p.x);
    minY = Math.min(minY, p.y);
    maxX = Math.max(maxX, p.x);
    maxY = Math.max(maxY, p.y);
  }
  const bw = Math.max(8, maxX - minX);
  const bh = Math.max(8, maxY - minY);
  const cx = (minX + maxX) / 2;
  const cy = (minY + maxY) / 2 - bh * 0.04;
  const scale = Math.min((viewW * 0.84) / bw, (viewH * 0.84) / bh);
  return { scale, ox: viewW / 2 - cx * scale, oy: viewH / 2 - cy * scale };
}

export function viewToImage(view: View, vx: number, vy: number): Pt {
  return { x: (vx - view.ox) / view.scale, y: (vy - view.oy) / view.scale };
}

export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export function clampCrop(rect: CropRect, imgW: number, imgH: number): CropRect {
  let { x, y, w, h } = rect;
  w = Math.max(36, w);
  h = Math.max(36, h);
  if (x < 0) {
    w += x;
    x = 0;
  }
  if (y < 0) {
    h += y;
    y = 0;
  }
  if (x + w > imgW) w = imgW - x;
  if (y + h > imgH) h = imgH - y;
  w = Math.max(36, Math.min(w, imgW));
  h = Math.max(36, Math.min(h, imgH));
  x = clamp(x, 0, Math.max(0, imgW - w));
  y = clamp(y, 0, Math.max(0, imgH - h));
  return { x, y, w, h };
}

export type CropHandle = "move" | "nw" | "ne" | "sw" | "se";

export function dragCrop(
  orig: CropRect,
  start: Pt,
  current: Pt,
  handle: CropHandle,
  imgW: number,
  imgH: number,
): CropRect {
  const dx = current.x - start.x;
  const dy = current.y - start.y;
  let { x, y, w, h } = orig;
  if (handle === "move") {
    x += dx;
    y += dy;
  }
  if (handle === "se" || handle === "ne") w += dx;
  if (handle === "sw" || handle === "nw") {
    x += dx;
    w -= dx;
  }
  if (handle === "se" || handle === "sw") h += dy;
  if (handle === "ne" || handle === "nw") {
    y += dy;
    h -= dy;
  }
  return clampCrop({ x, y, w, h }, imgW, imgH);
}

export function initialCrop(imgW: number, imgH: number, markers: Markers | null): CropRect {
  if (!markers) {
    const m = 0.08;
    return clampCrop(
      { x: imgW * m, y: imgH * m, w: imgW * (1 - m * 2), h: imgH * (1 - m * 2) },
      imgW,
      imgH,
    );
  }
  const pts = [markers.eyeL, markers.eyeR, markers.nose, ...markers.mouth, ...markers.jaw];
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const p of pts) {
    minX = Math.min(minX, p.x);
    minY = Math.min(minY, p.y);
    maxX = Math.max(maxX, p.x);
    maxY = Math.max(maxY, p.y);
  }
  const padX = (maxX - minX) * 0.28;
  const padY = (maxY - minY) * 0.28;
  return clampCrop(
    { x: minX - padX, y: minY - padY * 1.4, w: maxX - minX + padX * 2, h: maxY - minY + padY * 2.1 },
    imgW,
    imgH,
  );
}
