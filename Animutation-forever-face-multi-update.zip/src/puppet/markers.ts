import type { MarkerView, Markers, Pt } from "./types";

export function pt(x: number, y: number): Pt {
  return { x, y };
}

export function lerp(a: Pt, b: Pt, t: number): Pt {
  return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
}

export function mid(a: Pt, b: Pt): Pt {
  return lerp(a, b, 0.5);
}

export function dist(a: Pt, b: Pt): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

export function defaultMarkers(w: number, h: number): Markers {
  const s = Math.min(w, h);
  const cx = w * 0.5;
  const top = h * 0.5 - s * 0.32;
  const face = s * 0.34;
  const eyeY = top + face * 0.92;
  const mouthY = top + face * 1.55;
  const mouthW = face * 0.72;
  const dip = face * 0.1;
  return {
    eyeL: { x: cx - face * 0.42, y: eyeY },
    eyeR: { x: cx + face * 0.42, y: eyeY },
    nose: { x: cx, y: top + face * 1.22 },
    mouth: [
      { x: cx - mouthW, y: mouthY },
      { x: cx - mouthW * 0.5, y: mouthY + dip },
      { x: cx, y: mouthY + dip * 1.3 },
      { x: cx + mouthW * 0.5, y: mouthY + dip },
      { x: cx + mouthW, y: mouthY },
    ],
    jaw: [
      { x: cx - mouthW * 1.2, y: mouthY + dip * 0.2 },
      { x: cx - mouthW * 1.45, y: mouthY + face * 0.55 },
      { x: cx - mouthW * 0.75, y: mouthY + face * 0.95 },
      { x: cx, y: mouthY + face * 1.18 },
      { x: cx + mouthW * 0.75, y: mouthY + face * 0.95 },
      { x: cx + mouthW * 1.45, y: mouthY + face * 0.55 },
      { x: cx + mouthW * 1.2, y: mouthY + dip * 0.2 },
    ],
  };
}

const MOUTH_META = [
  ["Comisura izquierda", "Boca L"],
  ["Labio", "Labio"],
  ["Centro de la boca", "Centro"],
  ["Labio", "Labio"],
  ["Comisura derecha", "Boca R"],
] as const;

const JAW_META = [
  ["Mandíbula izquierda", "M. L"],
  ["Mandíbula", "M"],
  ["Mentón", "Mentón"],
  ["Barbilla", "Barbilla"],
  ["Mentón", "Mentón"],
  ["Mandíbula", "M"],
  ["Mandíbula derecha", "M. R"],
] as const;

export function listMarkers(m: Markers): MarkerView[] {
  const out: MarkerView[] = [
    { id: "eyeL", pt: m.eyeL, label: "Ojo izquierdo", short: "Ojo L", tone: "cyan" },
    { id: "eyeR", pt: m.eyeR, label: "Ojo derecho", short: "Ojo R", tone: "cyan" },
    { id: "nose", pt: m.nose, label: "Nariz", short: "Nariz", tone: "yellow" },
  ];
  m.mouth.forEach((p, i) => {
    const meta = MOUTH_META[i] ?? ["Boca", "Boca"];
    out.push({ id: `mouth-${i}`, pt: p, label: meta[0], short: meta[1], tone: "pink" });
  });
  m.jaw.forEach((p, i) => {
    const meta = JAW_META[i] ?? ["Mandíbula", "M"];
    out.push({ id: `jaw-${i}`, pt: p, label: meta[0], short: meta[1], tone: "yellow" });
  });
  return out;
}

export function moveMarker(m: Markers, id: string, nextPt: Pt): Markers {
  const mouth = m.mouth.map((p) => ({ ...p }));
  const jaw = m.jaw.map((p) => ({ ...p }));
  const next: Markers = {
    eyeL: { ...m.eyeL },
    eyeR: { ...m.eyeR },
    nose: { ...m.nose },
    mouth,
    jaw,
  };
  if (id === "eyeL") next.eyeL = nextPt;
  else if (id === "eyeR") next.eyeR = nextPt;
  else if (id === "nose") next.nose = nextPt;
  else if (id.startsWith("mouth-")) {
    const i = Number(id.slice(6));
    if (mouth[i]) mouth[i] = nextPt;
  } else if (id.startsWith("jaw-")) {
    const i = Number(id.slice(4));
    if (jaw[i]) jaw[i] = nextPt;
  }
  return next;
}

export function nudgeMarker(m: Markers, id: string, dx: number, dy: number): Markers {
  const current = listMarkers(m).find((item) => item.id === id);
  if (!current) return m;
  return moveMarker(m, id, { x: current.pt.x + dx, y: current.pt.y + dy });
}

export function mapMarkers(m: Markers, fn: (p: Pt) => Pt): Markers {
  return {
    eyeL: fn(m.eyeL),
    eyeR: fn(m.eyeR),
    nose: fn(m.nose),
    mouth: m.mouth.map(fn),
    jaw: m.jaw.map(fn),
  };
}

/** Keep the chin polygon below the lip line so the cut cannot flip inside out. */
export function sanitizeMarkers(m: Markers): Markers {
  const jaw = m.jaw.map((p) => ({ ...p }));
  const left = m.mouth[0];
  const right = m.mouth[m.mouth.length - 1];
  if (left && jaw[0] && jaw[0].y < left.y) jaw[0] = { x: jaw[0].x, y: left.y + 6 };
  const last = jaw.length - 1;
  if (right && jaw[last] && jaw[last].y < right.y) jaw[last] = { x: jaw[last].x, y: right.y + 6 };
  return { ...m, mouth: m.mouth.map((p) => ({ ...p })), jaw };
}

/** Central JibJab flap: mouth corners across, chin down. Cheeks stay outside. */
export type MouthBlock = { x: number; y: number; w: number; h: number; radius: number };

export function mouthBlock(markers: Markers, widthScale = 1): MouthBlock {
  const left = markers.mouth[0];
  const right = markers.mouth[markers.mouth.length - 1];
  const chin = markers.jaw[3] ?? markers.jaw[Math.floor(markers.jaw.length / 2)];
  if (!left || !right || !chin) return { x: 0, y: 0, w: 24, h: 18, radius: 6 };
  const eyeCenterX = (markers.eyeL.x + markers.eyeR.x) / 2;
  const mouthCenterX = (left.x + right.x) / 2;
  const rawW = Math.max(16, Math.abs(right.x - left.x));
  const noseOffset = markers.nose.x - eyeCenterX;
  const centerX = mouthCenterX + Math.max(-rawW * 0.18, Math.min(rawW * 0.18, noseOffset * 0.12));
  const w = Math.max(8, rawW * Math.max(0.45, Math.min(1.8, widthScale)));
  const x = centerX - w / 2;
  const top = (left.y + right.y) / 2;
  const bottom = Math.max(chin.y, top + w * 0.42);
  const h = Math.max(18, bottom - top);
  const radius = Math.min(w * 0.2, h * 0.34);
  return { x, y: top, w, h, radius };
}

/** How far the chin flap drops. mouthMax scales the widest black gap. */
export function mouthOpenPx(markers: Markers, amount: number, mouthMax = 1, widthScale = 1): number {
  const block = mouthBlock(markers, widthScale);
  const scale = Math.max(0.4, Math.min(2.2, mouthMax));
  const gap = Math.min(block.h * 0.7, Math.max(14, block.w * 0.4)) * scale;
  return Math.max(0, Math.min(1, amount)) * gap;
}

export function mouthAngle(markers: Markers): number {
  const mouthL = markers.mouth[0], mouthR = markers.mouth[markers.mouth.length - 1];
  if (!mouthL || !mouthR) return 0;
  const mouthLine = Math.atan2(mouthR.y - mouthL.y, mouthR.x - mouthL.x);
  const eyeLine = Math.atan2(markers.eyeR.y - markers.eyeL.y, markers.eyeR.x - markers.eyeL.x);
  // Average both lines as orientation cues; manual marker moves update this automatically.
  const sin = Math.sin(mouthLine) + Math.sin(eyeLine);
  const cos = Math.cos(mouthLine) + Math.cos(eyeLine);
  return Math.atan2(sin, cos);
}

export function cutPath(markers: Markers, widthScale = 1): Path2D {
  const block = mouthBlock(markers, widthScale);
  const path = new Path2D();
  const angle = mouthAngle(markers);
  const cx = block.x + block.w / 2, cy = block.y + block.h / 2;
  const rotated = new Path2D();
  roundedFlap(rotated, block.x, block.y, block.w, block.h, block.radius);
  const transform = new DOMMatrix().translate(cx, cy).rotate(angle * 180 / Math.PI).translate(-cx, -cy);
  path.addPath(rotated, transform);
  return path;
}

function roundedFlap(path: Path2D, x: number, y: number, w: number, h: number, radius: number) {
  const top = Math.min(radius * 0.28, w / 2, h / 2);
  const bottom = Math.min(Math.max(radius, 4), w / 2, h / 2);
  path.moveTo(x + top, y);
  path.lineTo(x + w - top, y);
  path.quadraticCurveTo(x + w, y, x + w, y + top);
  path.lineTo(x + w, y + h - bottom);
  path.quadraticCurveTo(x + w, y + h, x + w - bottom, y + h);
  path.lineTo(x + bottom, y + h);
  path.quadraticCurveTo(x, y + h, x, y + h - bottom);
  path.lineTo(x, y + top);
  path.quadraticCurveTo(x, y, x + top, y);
  path.closePath();
}

export function markersFromBox(x: number, y: number, w: number, h: number): Markers {
  const cx = x + w * 0.5;
  const mouthY = y + h * 0.7;
  const mouthW = w * 0.2;
  const dip = h * 0.025;
  return sanitizeMarkers({
    eyeL: { x: x + w * 0.34, y: y + h * 0.4 },
    eyeR: { x: x + w * 0.66, y: y + h * 0.4 },
    nose: { x: cx, y: y + h * 0.54 },
    mouth: [
      { x: cx - mouthW, y: mouthY },
      { x: cx - mouthW * 0.5, y: mouthY + dip },
      { x: cx, y: mouthY + dip * 1.35 },
      { x: cx + mouthW * 0.5, y: mouthY + dip },
      { x: cx + mouthW, y: mouthY },
    ],
    jaw: [
      { x: x + w * 0.28, y: y + h * 0.7 },
      { x: x + w * 0.24, y: y + h * 0.82 },
      { x: x + w * 0.36, y: y + h * 0.94 },
      { x: cx, y: y + h * 0.99 },
      { x: x + w * 0.64, y: y + h * 0.94 },
      { x: x + w * 0.76, y: y + h * 0.82 },
      { x: x + w * 0.72, y: y + h * 0.7 },
    ],
  });
}

type Lm = { x: number; y: number };

export function markersFromLandmarks(lms: Lm[], width: number, height: number): Markers | null {
  if (lms.length < 300) return null;
  const P = (i: number): Pt => {
    const lm = lms[i];
    if (!lm) return { x: width / 2, y: height / 2 };
    return { x: lm.x * width, y: lm.y * height };
  };
  const avg = (ids: number[]): Pt => {
    let x = 0;
    let y = 0;
    for (const id of ids) {
      const p = P(id);
      x += p.x;
      y += p.y;
    }
    return { x: x / ids.length, y: y / ids.length };
  };
  const left = P(61);
  const right = P(291);
  const seam = mid(P(13), P(14));
  const mouth = [
    left,
    lerp(P(37), seam, 0.45),
    seam,
    lerp(P(267), seam, 0.45),
    right,
  ];
  const jawIds = [172, 136, 150, 152, 378, 365, 397];
  const jaw = jawIds.map((id) => P(id));
  return sanitizeMarkers({
    eyeL: avg([33, 133, 159, 145]),
    eyeR: avg([263, 362, 386, 374]),
    nose: P(1),
    mouth,
    jaw,
  });
}
