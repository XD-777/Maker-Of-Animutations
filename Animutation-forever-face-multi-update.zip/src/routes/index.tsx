import { createFileRoute } from "@tanstack/react-router";
import { PuppetApp } from "@/components/puppet-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <PuppetApp />;
}
