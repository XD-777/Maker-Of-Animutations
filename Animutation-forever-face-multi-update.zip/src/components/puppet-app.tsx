import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import {
  AudioLines,
  Crop,
  Crosshair,
  Download,
  Eraser,
  FileAudio,
  Image as ImageIcon,
  MessageCircle,
  Mic,
  Pencil,
  Play,
  RotateCcw,
  ScanFace,
  Scissors,
  Sparkles,
  Undo2,
  Upload,
  Wrench,
  Volume2,
} from "lucide-react";
import { AudioRig, type SourceKind } from "@/puppet/audio-rig";
import { detectFace } from "@/puppet/face-detect";
import { dragCrop, faceView, fitView, initialCrop, viewToImage, type CropHandle } from "@/puppet/geometry";
import { canvasFromFile, cropImage, removeBackground, trimTransparency } from "@/puppet/image-ops";
import { defaultMarkers, listMarkers, mapMarkers, markersFromBox, moveMarker, nudgeMarker, sanitizeMarkers } from "@/puppet/markers";
import { PuppetRenderer } from "@/puppet/renderer";
import { createSample } from "@/puppet/sample-face";
import { DEFAULT_FX, SILENT, type AudioLevels, type CropRect, type FaceSlot, type Fx, type Markers, type Pt } from "@/puppet/types";

const SETTINGS_KEY = "animutation-puppet-settings-v1";

const btn =
  "mm-btn sticker-press inline-flex min-h-11 items-center justify-center gap-2 px-3 py-2 text-left font-semibold text-black disabled:opacity-50";
const solid = btn;
const hot = `${btn} mm-btn-on`;
const sun = `${btn} mm-btn-primary`;
const ice = btn;

const TONE_CLASS = {
  cyan: "bg-[#00d0e0]",
  yellow: "bg-[#ffe14a]",
  pink: "bg-[#ff2f9a]",
} as const;

type Snap = { image: HTMLCanvasElement; markers: Markers };
type Saved = { fx?: Partial<Fx> & { mouth?: unknown }; volume?: number; tolerance?: number };
type StageMode = "edit" | "play" | "still";

function scaledAnalysisCanvas(source: HTMLCanvasElement, maxEdge = 512) {
  const scale = Math.min(1, maxEdge / Math.max(source.width, source.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(source.width * scale));
  canvas.height = Math.max(1, Math.round(source.height * scale));
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("No se pudo preparar el análisis facial.");
  ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
  return { canvas, scale };
}

function markersScaled(markers: Markers, factor: number): Markers {
  return mapMarkers(markers, (p) => ({ x: p.x * factor, y: p.y * factor }));
}

/** Keep slow model initialization from locking the preparation controls indefinitely. */
function detectFaceWithTimeout(canvas: HTMLCanvasElement, limitMs = 9000) {
  let timer: number | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = window.setTimeout(() => reject(new Error("La detección superó los 9 segundos.")), limitMs);
  });
  return Promise.race([detectFace(canvas), timeout]).finally(() => {
    if (timer !== undefined) window.clearTimeout(timer);
  });
}

export function PuppetApp() {
  const [image, setImage] = useState<HTMLCanvasElement | null>(null);
  const [markers, setMarkers] = useState<Markers | null>(null);
  const [kind, setKind] = useState<"sample" | "photo">("sample");
  const [caption, setCaption] = useState("Mr. Bean");
  const [mode, setMode] = useState<StageMode>("edit");
  const [framing, setFraming] = useState<"fit" | "face">("fit");
  const [view, setView] = useState({ scale: 1, ox: 0, oy: 0 });
  const [notice, setNotice] = useState(
    "Mr. Bean ya está en el lienzo. En silencio hasta que subas un MP3/WAV o actives el micrófono.",
  );
  const [detecting, setDetecting] = useState(false);
  const [audioKind, setAudioKind] = useState<SourceKind>("none");
  const [fileName, setFileName] = useState<string | null>(null);
  const [filePaused, setFilePaused] = useState(true);
  const [fx, setFx] = useState<Fx>(DEFAULT_FX);
  const [volume, setVolume] = useState(0.85);
  const [tolerance, setTolerance] = useState(48); // Retained for backward compatibility with saved project JSON.
  const [removingBg, setRemovingBg] = useState(false);
  const [bgToolAvailable, setBgToolAvailable] = useState(true);
  const [crop, setCrop] = useState<CropRect | null>(null);
  const [undo, setUndo] = useState<Snap | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [videoDuration, setVideoDuration] = useState(6);
  const [recordCountdown, setRecordCountdown] = useState<number | null>(null);
  const [ttsText, setTtsText] = useState("");
  const [ttsVoices, setTtsVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [ttsVoiceURI, setTtsVoiceURI] = useState("");
  const [ttsPreset, setTtsPreset] = useState<"jorge" | "carlos" | "carmen" | "ardilla">("jorge");
  const [ttsPitch, setTtsPitch] = useState(0.95);
  const [ttsRate, setTtsRate] = useState(1.05);
  const [ttsSpeaking, setTtsSpeaking] = useState(false);
  const [simulating, setSimulating] = useState(false);
  const [faces, setFaces] = useState<FaceSlot[]>([]);
  const [activeFaceId, setActiveFaceId] = useState<string | null>(null);
  const [armDraw, setArmDraw] = useState(false);
  const [draft, setDraft] = useState<CropRect | null>(null);

  const stageRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<PuppetRenderer | null>(null);
  const audioRef = useRef<AudioRig | null>(null);
  const imageRef = useRef(image);
  const markersRef = useRef(markers);
  const framingRef = useRef(framing);
  const fxRef = useRef(fx);
  const volumeRef = useRef(volume);
  const modeRef = useRef(mode);
  const reduceRef = useRef(reduceMotion);
  const meterRef = useRef<HTMLDivElement>(null);
  const meterValue = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const audioFileRef = useRef<HTMLInputElement>(null);
  const projectRef = useRef<HTMLInputElement>(null);
  const cropDrag = useRef<{ handle: CropHandle; start: Pt; orig: CropRect } | null>(null);
  const faceDrag = useRef<{ id: string; handle: CropHandle; start: Pt; orig: CropRect } | null>(null);
  const draftOrigin = useRef<Pt | null>(null);
  const facesRef = useRef(faces);
  const activeFaceRef = useRef(activeFaceId);
  const simRef = useRef(false);
  const talkRef = useRef({ env: 0, gap: 0, prev: 0, ttsActive: false, ttsEnv: 0, ttsPulse: 0, ttsGap: 0 });
  const ttsUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const ttsPresetRef = useRef<"jorge" | "carlos" | "carmen" | "ardilla">("jorge");
  const patchUndoRef = useRef<Snap | null>(null);
  const ttsTimerRef = useRef<number | null>(null);

  imageRef.current = image;
  markersRef.current = markers;
  framingRef.current = framing;
  fxRef.current = fx;
  volumeRef.current = volume;
  modeRef.current = mode;
  reduceRef.current = reduceMotion;
  facesRef.current = faces;
  activeFaceRef.current = activeFaceId;

  const layout = useCallback(() => {
    const stage = stageRef.current;
    const current = imageRef.current;
    if (!stage || !current) return;
    const w = stage.clientWidth;
    const h = stage.clientHeight;
    if (w < 2 || h < 2) return;
    const next =
      framingRef.current === "face" && markersRef.current
        ? faceView(markersRef.current, w, h)
        : fitView(current.width, current.height, w, h);
    setView(next);
  }, []);

  useEffect(() => {
    rendererRef.current = new PuppetRenderer();
    const synth = window.speechSynthesis;
    const refreshVoices = () => {
      const voices = synth.getVoices();
      setTtsVoices(voices);
      // Voice lists often arrive asynchronously on Android; select a matching Spanish voice when ready.
      if (voices.length) {
        const spanish = voices.filter((voice) => /^es(-|$)/i.test(voice.lang));
        const pool = spanish.length ? spanish : voices;
        const preset = ttsPresetRef.current;
        const match = bestVoiceForPreset(pool, preset);
        if (match) setTtsVoiceURI(match.voiceURI);
      }
    };
    refreshVoices();
    synth.addEventListener?.("voiceschanged", refreshVoices);
    const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduceMotion(motion.matches);
    const onMotion = () => setReduceMotion(motion.matches);
    motion.addEventListener("change", onMotion);
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as Saved;
        if (saved.fx) {
          const { mouth: _mouth, ...rest } = saved.fx;
          setFx((prev) => ({
            ...prev,
            ...rest,
            mouthMax: clampMouth(rest.mouthMax ?? prev.mouthMax),
          }));
        }
        if (typeof saved.volume === "number") setVolume(saved.volume);
        if (typeof saved.tolerance === "number") setTolerance(saved.tolerance);
      }
    } catch {
      /* ignore broken settings */
    }
    let gone = false;
    void createSample()
      .then(({ canvas, markers: demo }) => {
        if (gone) return;
        setImage(canvas);
        setMarkers(demo);
        setCaption("Mr. Bean");
      })
      .catch(() => {
        if (!gone) setNotice("No pude cargar el personaje. Sube una foto para continuar.");
      });
    return () => {
      gone = true;
      motion.removeEventListener("change", onMotion);
      synth.removeEventListener?.("voiceschanged", refreshVoices);
      audioRef.current?.close();
      window.speechSynthesis?.cancel();
      if (ttsTimerRef.current !== null) window.clearTimeout(ttsTimerRef.current);
      rendererRef.current = null;
    };
  }, []);

  useEffect(() => {
    const payload: Saved = { fx, volume, tolerance };
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(payload));
    } catch {
      /* private mode */
    }
  }, [fx, volume, tolerance]);

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    const observer = new ResizeObserver(() => layout());
    observer.observe(stage);
    layout();
    return () => observer.disconnect();
  }, [image, framing, layout]);

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    const block = (event: Event) => {
      event.preventDefault();
    };
    const opts: AddEventListenerOptions = { passive: false };
    stage.addEventListener("touchstart", block, opts);
    stage.addEventListener("touchmove", block, opts);
    stage.addEventListener("pointerdown", block, opts);
    stage.addEventListener("pointermove", block, opts);
    return () => {
      stage.removeEventListener("touchstart", block);
      stage.removeEventListener("touchmove", block);
      stage.removeEventListener("pointerdown", block);
      stage.removeEventListener("pointermove", block);
    };
  }, []);

  useEffect(() => {
    if (image && !markers) setMarkers(defaultMarkers(image.width, image.height));
  }, [image, markers]);



  useEffect(() => {
    const renderer = rendererRef.current;
    const canvas = canvasRef.current;
    if (!renderer || !canvas || !image || !markers || mode !== "edit") return;
    renderer.attach(canvas);
    renderer.setScene(image, markers, view);
    renderer.setFaces(faces);
    renderer.drawEdit(fx.mouthWidth ?? 1);
  }, [image, markers, view, mode, faces, fx.mouthWidth]);

  useEffect(() => {
    if (mode !== "play") return;
    const renderer = rendererRef.current;
    const canvas = canvasRef.current;
    if (!renderer || !canvas || !imageRef.current || !markersRef.current) return;
    renderer.attach(canvas);
    renderer.resetMotion();
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const currentImage = imageRef.current;
      const currentMarkers = markersRef.current;
      if (currentImage && currentMarkers) {
        renderer.setScene(currentImage, currentMarkers, view);
        renderer.setFaces(facesRef.current);
        const audioLevels = audioRef.current?.sample() ?? SILENT;
        const levels = voiceLevels(audioLevels, dt, simRef.current, talkRef.current);
        renderer.frame(dt, levels, fxRef.current, reduceRef.current);
        paintMeter(meterRef.current, meterValue.current, levels.level);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [mode, view]);

  useEffect(() => {
    if (mode !== "still") return;
    const renderer = rendererRef.current;
    const canvas = canvasRef.current;
    if (!renderer || !canvas || !image || !markers) return;
    renderer.attach(canvas);
    renderer.setScene(image, markers, view);
    renderer.setFaces(faces);
    renderer.drawOpenFace(fx.mouthMax, fx.mouthWidth ?? 1);
    paintMeter(meterRef.current, meterValue.current, 0);
  }, [mode, image, markers, view, faces, fx.mouthMax, fx.mouthWidth]);

  function commitMarkers(next: Markers) {
    setMarkers(next);
    const id = activeFaceRef.current;
    if (!id) return;
    setFaces((list) => list.map((face) => (face.id === id ? { ...face, markers: next } : face)));
  }

  function clearFaces() {
    setFaces([]);
    setActiveFaceId(null);
    activeFaceRef.current = null;
    setArmDraw(false);
    setDraft(null);
    faceDrag.current = null;
  }

  function rig(): AudioRig {
    if (!audioRef.current) {
      try {
        audioRef.current = new AudioRig();
      } catch {
        throw new Error("El navegador bloqueó el audio. Vuelve a pulsar el botón para dar permiso.");
      }
    }
    audioRef.current.setVolume(volumeRef.current);
    return audioRef.current;
  }

  async function onUpload(file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setNotice("Ese archivo no es una imagen. Usa JPG, PNG o WebP.");
      return;
    }
    try {
      const canvas = await canvasFromFile(file);
      const nextMarkers = defaultMarkers(canvas.width, canvas.height);
      if (image && markers) setUndo({ image, markers });
      clearFaces();
      setImage(canvas);
      setMarkers(nextMarkers);
      setKind("photo");
      setCaption(file.name);
      setCrop(null);
      framingRef.current = "fit";
      setFraming("fit");
      setMode("edit");
      setNotice("Imagen lista. Auto-detecta el rostro o arrastra los puntos a mano. Los puntos no mueven la página.");
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "No pude abrir la imagen.");
    }
  }

  async function loadDemo() {
    try {
      const { canvas, markers: demo } = await createSample();
      if (image && markers) setUndo({ image, markers });
      clearFaces();
      setImage(canvas);
      setMarkers(demo);
      setKind("sample");
      setCaption("Mr. Bean");
      setCrop(null);
      framingRef.current = "fit";
      setFraming("fit");
      setMode("edit");
      setNotice("Mr. Bean en el lienzo. Arrastra los puntos: la página no se desplaza.");
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "No pude cargar el personaje.");
    }
  }

  function snapshotUndo() {
    if (image && markers) setUndo({ image, markers });
  }

  function doUndo() {
    if (!undo) return;
    setImage(undo.image);
    setMarkers(undo.markers);
    setUndo(null);
    setCrop(null);
    setNotice("Deshice el último recorte.");
  }

  async function knockOutBackground() {
    if (!image || !markers || removingBg || !bgToolAvailable) return;
    snapshotUndo();
    setRemovingBg(true);
    setNotice("Quitafondos IA: procesando. Si tarda más de 10 segundos, se desactivará y priorizaremos el selector de caras.");
    let timeoutId: number | undefined;
    try {
      const timeout = new Promise<never>((_, reject) => {
        timeoutId = window.setTimeout(() => reject(new Error("El procesamiento superó 10 segundos.")), 10000);
      });
      const next = await Promise.race([
        removeBackground(image, tolerance, (progressText) => setNotice(`Quitafondos IA: ${progressText}`)),
        timeout,
      ]);
      if (timeoutId !== undefined) window.clearTimeout(timeoutId);
      setImage(next);
      setNotice("Fondo eliminado con IA. Revisa el recorte y usa Deshacer si necesitas recuperar la imagen anterior.");
    } catch (err) {
      if (timeoutId !== undefined) window.clearTimeout(timeoutId);
      setBgToolAvailable(false);
      setNotice(`${err instanceof Error ? err.message : "Falló el quitafondos."} Quitafondos desactivado en esta sesión. La selección múltiple de caras queda como alternativa recomendada.`);
    } finally {
      setRemovingBg(false);
    }
  }

  function trimEdges() {
    if (!image || !markers) return;
    const result = trimTransparency(image, markers);
    if (!result?.trimmed) {
      setNotice("No hay bordes vacíos. Quita el fondo primero o usa el recorte manual.");
      return;
    }
    snapshotUndo();
    setImage(result.canvas);
    setMarkers(result.markers);
    setNotice("Recorté el aire alrededor de la figura.");
  }

  function beginCrop() {
    if (!image || !markers) return;
    setMode("edit");
    setCrop(initialCrop(image.width, image.height, markers));
    setNotice("Ajusta el marco y aplica el recorte. Los puntos se mudan con la imagen.");
  }

  function applyCrop() {
    if (!image || !markers || !crop) return;
    const next = cropImage(image, crop, markers);
    snapshotUndo();
    setImage(next.canvas);
    setMarkers(next.markers);
    setCrop(null);
    framingRef.current = "fit";
    setFraming("fit");
    setNotice("Recorte aplicado.");
  }

  function centerHead() {
    framingRef.current = "face";
    setFraming("face");
    layout();
    setNotice("Centré la cabeza usando los puntos. Si quedó chica, arrastra la mandíbula y vuelve a centrar.");
  }

  function fitAll() {
    framingRef.current = "fit";
    setFraming("fit");
    layout();
  }

  function patchOpenMouth() {
    if (!image || !markers) return;
    const mouthPts = markers.mouth;
    if (!mouthPts || mouthPts.length < 3) { setNotice("No hay puntos de boca para parchear. Auto-detecta o ajusta los puntos primero."); return; }
    const xs = mouthPts.map((pt) => pt.x), ys = mouthPts.map((pt) => pt.y);
    const x = Math.max(0, Math.floor(Math.min(...xs))), y = Math.max(0, Math.floor(Math.min(...ys)));
    const right = Math.min(image.width, Math.ceil(Math.max(...xs))), bottom = Math.min(image.height, Math.ceil(Math.max(...ys)));
    const w = right - x, h = bottom - y;
    if (w < 3 || h < 3) { setNotice("El área de boca es demasiado pequeña. Ajusta los puntos rosa y vuelve a intentar."); return; }
    const patched = document.createElement("canvas"); patched.width = image.width; patched.height = image.height;
    const ctx = patched.getContext("2d", { willReadFrequently: true }); if (!ctx) return;
    ctx.drawImage(image, 0, 0);
    const srcCtx = image.getContext("2d", { willReadFrequently: true }); if (!srcCtx) return;
    const imageData = srcCtx.getImageData(0, 0, image.width, image.height);
    let r=0,g=0,b=0,n=0; const margin=Math.max(2,Math.round(Math.min(w,h)*0.12));
    for(let sy=Math.max(0,y-margin);sy<Math.min(image.height,bottom+margin);sy++){
      for(let sx=Math.max(0,x-margin);sx<Math.min(image.width,right+margin);sx++){
        if(sx>=x && sx<right && sy>=y && sy<bottom) continue;
        const idx=(sy*image.width+sx)*4, a=imageData.data[idx+3]??0; if(a<100) continue;
        r+=imageData.data[idx]??0;g+=imageData.data[idx+1]??0;b+=imageData.data[idx+2]??0;n++;
      }
    }
    if(!n){ setNotice("No pude tomar un color alrededor de la boca. Prueba con otra foto o ajusta los puntos."); return; }
    const color=`rgb(${Math.round(r/n)}, ${Math.round(g/n)}, ${Math.round(b/n)})`;
    ctx.save(); ctx.filter=`blur(${Math.max(1,Math.min(5,Math.round(Math.min(w,h)*0.04)))}px)`;
    ctx.fillStyle=color; ctx.beginPath(); ctx.moveTo(mouthPts[0].x,mouthPts[0].y); for(const pt of mouthPts.slice(1)) ctx.lineTo(pt.x,pt.y); ctx.closePath(); ctx.fill(); ctx.restore();
    snapshotUndo(); setImage(patched); setMode("edit"); setNotice("Parche aplicado sobre la boca. Usa Deshacer para restaurar la imagen anterior si no te gusta el resultado.");
  }

  function undoPatch() { const previous = patchUndoRef.current; if (!previous) return; setImage(previous.image); setMarkers(previous.markers); patchUndoRef.current = null; setNotice("Parche deshecho: restauré la imagen original anterior al parche."); }

  const TTS_PRESETS = {
    jorge: { label: "👨 Jorge (Clásico)", pitch: 0.95, rate: 1.05 },
    carlos: { label: "🧔 Carlos (Grave)", pitch: 0.65, rate: 0.95 },
    carmen: { label: "👩 Carmen (Mujer)", pitch: 1.35, rate: 1.05 },
    ardilla: { label: "🐿️ Ardilla 2003", pitch: 1.75, rate: 1.25 },
  } as const;

  function chooseTtsPreset(preset: keyof typeof TTS_PRESETS) {
    ttsPresetRef.current = preset;
    setTtsPreset(preset);
    const presetSettings = TTS_PRESETS[preset];
    setTtsPitch(presetSettings.pitch);
    setTtsRate(presetSettings.rate);
    const spanish = ttsVoices.filter((voice) => /^es(-|$)/i.test(voice.lang));
    const pool = spanish.length ? spanish : ttsVoices;
    const found = bestVoiceForPreset(pool, preset);
    if (found) setTtsVoiceURI(found.voiceURI);
    setNotice(found ? `${presetSettings.label}: ${found.name} · tono ${presetSettings.pitch}, velocidad ${presetSettings.rate}.` : `${presetSettings.label}: se aplicaron tono y velocidad; no hay una voz identificada disponible, se usará la voz predeterminada.`);
  }

  function speakText() {
    const text=ttsText.trim(); if(!text){setNotice("Escribe un texto para que el títere lo diga.");return;}
    if(!("speechSynthesis" in window)){setNotice("Este navegador no ofrece Texto a Voz.");return;}
    window.speechSynthesis.cancel(); const utter=new SpeechSynthesisUtterance(text);
    const voice=ttsVoices.find(v=>v.voiceURI===ttsVoiceURI); if(voice) utter.voice=voice;
    utter.pitch=ttsPitch; utter.rate=ttsRate; ttsUtteranceRef.current=utter;
    talkRef.current.ttsActive=true; talkRef.current.ttsEnv=0.15; talkRef.current.ttsPulse=0.15; setTtsSpeaking(true); setMode("play");
    utter.onstart=()=>{ talkRef.current.ttsActive=true; talkRef.current.ttsEnv=0.45; talkRef.current.ttsPulse=0.45; };
    utter.onboundary=(event)=>{
      // Boundary callbacks are word-level on many browsers; create a short envelope pulse for the mouth.
      const length = Math.max(1, event.charLength || 1);
      const pulse = Math.min(0.95, 0.5 + length * 0.045 + Math.random() * 0.12);
      talkRef.current.ttsPulse=pulse; talkRef.current.ttsGap=0.07;
      talkRef.current.ttsEnv=Math.max(talkRef.current.ttsEnv, pulse);
    };
    utter.onend=utter.onerror=()=>{talkRef.current.ttsActive=false; talkRef.current.ttsEnv=0; talkRef.current.ttsPulse=0; setTtsSpeaking(false);};
    window.speechSynthesis.speak(utter); setNotice("TTS activo: la boca se anima siguiendo los eventos de voz. El audio del sintetizador no puede capturarse directamente por MediaRecorder en la mayoría de navegadores.");
  }
  function stopTts() { window.speechSynthesis.cancel(); talkRef.current.ttsActive=false; talkRef.current.ttsEnv=0; talkRef.current.ttsPulse=0; setTtsSpeaking(false); }

  async function autoDetect() {
    if (!image || detecting) return;
    setDetecting(true);
    setMode("edit");
    setNotice("Analizando rostro en resolución optimizada (máximo 512 px)…");
    try {
      const selected = activeFaceId ? facesRef.current.find((face) => face.id === activeFaceId) : undefined;
      let target = image;
      let offset = { x: 0, y: 0 };
      if (selected) {
        const region = document.createElement("canvas");
        region.width = Math.max(2, Math.round(selected.box.w));
        region.height = Math.max(2, Math.round(selected.box.h));
        const regionCtx = region.getContext("2d");
        if (!regionCtx) throw new Error("No se pudo preparar el recuadro de cara activa.");
        regionCtx.drawImage(image, selected.box.x, selected.box.y, selected.box.w, selected.box.h, 0, 0, region.width, region.height);
        target = region;
        offset = { x: selected.box.x, y: selected.box.y };
      }
      const { canvas: analysis, scale } = scaledAnalysisCanvas(target, 512);
      const outcome = await detectFaceWithTimeout(analysis);
      if (!outcome.ok) {
        setNotice(`${outcome.message} Los puntos siguen visibles: arrástralos a mano.`);
        return;
      }
      const mapped = mapMarkers(markersScaled(outcome.markers, 1 / scale), (p) => ({ x: p.x + offset.x, y: p.y + offset.y }));
      commitMarkers(mapped);
      if (outcome.precise) {
        setNotice(selected ? "Rostro detectado dentro de la cara seleccionada. Sus puntos se actualizaron." : "Rostro detectado en análisis ligero de 512 px. Arrastra los puntos si hace falta ajustar.");
      } else {
        setNotice(selected ? "Detección aproximada dentro del recuadro. Ajusta los marcadores manualmente." : "Detección rápida aproximada. Ajusta ojos, boca y barbilla manualmente.");
      }
    } catch {
      setNotice("La detección falló. Los puntos siguen visibles para moverlos manualmente.");
    } finally {
      setDetecting(false);
    }
  }

  function startFaceSelection() {
    if (!image) return;
    setMode("edit");
    setCrop(null);
    setDraft(null);
    draftOrigin.current = null;
    setArmDraw(true);
    setNotice("Dibuja un recuadro sobre la cara que quieras añadir. Al soltar, se detectarán sus puntos automáticamente.");
  }

  function handleFaceBoxPointerDown(event: ReactPointerEvent<HTMLDivElement>) {
    if (!armDraw || !image) return;
    event.preventDefault();
    event.stopPropagation();
    const point = pointerImage(event);
    if (!point) return;
    const start = clampToImage(point, image);
    draftOrigin.current = start;
    setDraft({ x: start.x, y: start.y, w: 1, h: 1 });
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function handleFaceBoxPointerMove(event: ReactPointerEvent<HTMLDivElement>) {
    if (!armDraw || !draftOrigin.current || !image || !event.currentTarget.hasPointerCapture(event.pointerId)) return;
    event.preventDefault();
    const point = pointerImage(event);
    if (!point) return;
    const end = clampToImage(point, image);
    const start = draftOrigin.current;
    setDraft({ x: Math.min(start.x, end.x), y: Math.min(start.y, end.y), w: Math.max(2, Math.abs(end.x - start.x)), h: Math.max(2, Math.abs(end.y - start.y)) });
  }

  async function handleFaceBoxPointerUp(event: ReactPointerEvent<HTMLDivElement>) {
    if (!armDraw || !draftOrigin.current || !image) return;
    event.preventDefault();
    const point = pointerImage(event);
    const start = draftOrigin.current;
    draftOrigin.current = null;
    setArmDraw(false);
    const end = point ? clampToImage(point, image) : start;
    const boxX = Math.min(start.x, end.x);
    const boxY = Math.min(start.y, end.y);
    const box: CropRect = {
      x: boxX, y: boxY,
      w: Math.min(image.width - boxX, Math.max(12, Math.abs(end.x - start.x))),
      h: Math.min(image.height - boxY, Math.max(12, Math.abs(end.y - start.y))),
    };
    setDraft(box);
    setDetecting(true);
    setNotice("Detectando puntos dentro del recuadro seleccionado…");
    try {
      const cropCanvas = document.createElement("canvas");
      cropCanvas.width = Math.max(2, Math.round(box.w));
      cropCanvas.height = Math.max(2, Math.round(box.h));
      const cropCtx = cropCanvas.getContext("2d");
      if (!cropCtx) throw new Error("No se pudo preparar la zona de la cara.");
      cropCtx.drawImage(image, box.x, box.y, box.w, box.h, 0, 0, cropCanvas.width, cropCanvas.height);
      const { canvas: analysis, scale } = scaledAnalysisCanvas(cropCanvas, 512);
      let outcome: Awaited<ReturnType<typeof detectFaceWithTimeout>> | null = null;
      try {
        outcome = await detectFaceWithTimeout(analysis);
      } catch {
        // A face box remains useful even if model loading/analysis is slow: add it with estimated markers.
      }
      let localMarkers = outcome?.ok ? markersScaled(outcome.markers, 1 / scale) : markersFromBox(0, 0, cropCanvas.width, cropCanvas.height);
      localMarkers = mapMarkers(localMarkers, (p) => ({ x: p.x + box.x, y: p.y + box.y }));
      const id = `face-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
      const slot: FaceSlot = { id, box, markers: localMarkers };
      setFaces((existing) => [...existing, slot]);
      setActiveFaceId(id);
      activeFaceRef.current = id;
      setMarkers(localMarkers);
      setDraft(null);
      setNotice(outcome?.ok ? `Cara añadida (${facesRef.current.length + 1}). Puedes repetir “Elegir / Añadir cara” para sumar más personajes.` : "Cara añadida con puntos aproximados porque la detección fue lenta o no encontró puntos. Ajusta los marcadores manualmente.");
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "No se pudo detectar dentro del recuadro.");
    } finally {
      setDraft(null);
      setDetecting(false);
    }
  }

  function activateFace(face: FaceSlot) {
    setActiveFaceId(face.id);
    activeFaceRef.current = face.id;
    setMarkers(face.markers);
    setMode("edit");
    setNotice("Cara seleccionada. Ajusta sus puntos desde el escenario.");
  }

  function removeFace(faceId: string) {
    const remaining = faces.filter((face) => face.id !== faceId);
    setFaces(remaining);
    if (activeFaceRef.current === faceId) {
      const next = remaining[0] ?? null;
      setActiveFaceId(next?.id ?? null);
      activeFaceRef.current = next?.id ?? null;
      if (next) setMarkers(next.markers);
    }
  }

  async function resetPoints() {
    if (!image) return;
    if (kind === "sample") {
      try {
        const fresh = await createSample();
        if (image.width === fresh.canvas.width && image.height === fresh.canvas.height) {
          setMarkers(fresh.markers);
          setNotice("Puntos de Mr. Bean restaurados.");
          return;
        }
      } catch {
        /* usa el recorte genérico */
      }
    }
    setMarkers(defaultMarkers(image.width, image.height));
    setNotice("Puntos reiniciados. Siempre puedes moverlos, aunque no haya detección.");
  }

  async function animate() {
    setCrop(null);
    setMode("play");
    const existing = audioRef.current;
    if (!existing || existing.getKind() === "none") {
      setNotice("Silencio total. No hay beat. Sube un MP3/WAV o activa el micrófono para que la boca se mueva.");
      return;
    }
    try {
      await existing.arm();
      await existing.resumeSelected();
      setAudioKind(existing.getKind());
      setFilePaused(existing.fileIsPaused());
      setNotice(
        existing.getKind() === "mic"
          ? "Micrófono activo. No suena por los altavoces: solo abre la boca."
          : "Reproduciendo tu audio. La mandíbula sigue el volumen.",
      );
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "No pude arrancar el audio.");
    }
  }

  function backToEdit() {
    audioRef.current?.suspendAudible();
    setFilePaused(true);
    setAudioKind(audioRef.current?.getKind() ?? "none");
    setMode("edit");
    setNotice("Modo edición. Mueve los puntos: la página no se desplaza.");
  }

  function showStill() {
    audioRef.current?.suspendAudible();
    setFilePaused(true);
    setAudioKind(audioRef.current?.getKind() ?? "none");
    setCrop(null);
    setMode("still");
    setNotice("Solo imagen: la cara queda quieta con la boca abierta en negro. No es un video y no hay sonido.");
  }

  async function openMic() {
    try {
      const audio = rig();
      const resumed = audio.arm();
      await audio.startMic();
      await resumed;
      setAudioKind("mic");
      setCrop(null);
      setMode("play");
      setNotice("Micrófono activo. No sale por los altavoces: solo mueve la boca. Habla o pon música cerca.");
    } catch (err) {
      setAudioKind(audioRef.current?.getKind() ?? "none");
      setNotice(err instanceof Error ? `${err.message} Usa Simular voz o sube un MP3/WAV.` : "No pude abrir el micrófono. Usa Simular voz o sube un MP3/WAV.");
    }
  }

  function toggleSim() {
    const next = !simRef.current;
    simRef.current = next;
    setSimulating(next);
    setCrop(null);
    setMode("play");
    setNotice(
      next
        ? "Simulador de voz: la boca habla sola. No usa el micrófono y no suena."
        : "Simulador apagado.",
    );
  }

  async function onAudioFile(file: File | undefined) {
    if (!file) return;
    try {
      const audio = rig();
      await audio.loadFile(file);
      setFileName(file.name);
      setFilePaused(false);
      setAudioKind("file");
      setCrop(null);
      setMode("play");
      setNotice(`Reproduciendo ${file.name}. La mandíbula sigue el volumen.`);
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "No pude leer el audio. Prueba con un MP3 o WAV.");
    }
  }

  async function toggleFilePlayback() {
    try {
      const audio = rig();
      await audio.toggleFile();
      setFilePaused(audio.fileIsPaused());
      setAudioKind(audio.getKind());
      if (!audio.fileIsPaused()) {
        setCrop(null);
        setMode("play");
      }
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "No pude reproducir el audio.");
    }
  }

  async function download() {
    const canvas = canvasRef.current;
    const renderer = rendererRef.current;
    const currentImage = imageRef.current;
    const currentMarkers = markersRef.current;
    if (!canvas || !renderer || !currentImage || !currentMarkers) {
      setNotice("Sube una cara antes de descargar.");
      return;
    }
    if (modeRef.current === "still") {
      renderer.attach(canvas);
      renderer.setScene(currentImage, currentMarkers, view);
      renderer.drawOpenFace(fxRef.current.mouthMax, fxRef.current.mouthWidth ?? 1);
      const blob = await canvasToBlob(canvas);
      if (!blob) {
        setNotice("No pude crear el PNG.");
        return;
      }
      saveBlob(blob, "animutation-boca.png");
      setNotice("Imagen descargada: la cara con la boca abierta en negro.");
      return;
    }
    if (typeof MediaRecorder === "undefined" || typeof canvas.captureStream !== "function") {
      setNotice("Este navegador no graba video. Pulsa Solo imagen y luego Descargar imagen.");
      return;
    }
    setExporting(true);
    setCrop(null);
    if (modeRef.current !== "play") setMode("play");
    const hasAudio = !!audioRef.current && audioRef.current.getKind() !== "none";
    setRecordCountdown(videoDuration);
    setNotice(hasAudio ? `Grabando ${videoDuration} segundos de video…` : `Grabando ${videoDuration} segundos. Sin MP3 ni micrófono la boca no se mueve.`);
    await new Promise((resolve) => setTimeout(resolve, 280));
    let rec: MediaRecorder | null = null;
    try {
      const videoStream = canvas.captureStream(30);
      const tracks = [...videoStream.getVideoTracks()];
      const audioStream = audioRef.current?.captureAudio() ?? null;
      if (audioStream) tracks.push(...audioStream.getAudioTracks());
      const activeMic = audioKind === "mic" ? audioRef.current?.getMicStream() ?? null : null;
      if (activeMic) tracks.push(...activeMic.getAudioTracks());
      const stream = new MediaStream(tracks);
      const mime = pickVideoMime();
      rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      const chunks: Blob[] = [];
      rec.ondataavailable = (event) => {
        if (event.data.size > 0) chunks.push(event.data);
      };
      const stopped = new Promise<Blob>((resolve, reject) => {
        if (!rec) {
          reject(new Error("sin grabadora"));
          return;
        }
        rec.onerror = () => reject(new Error("La grabación falló."));
        rec.onstop = () => resolve(new Blob(chunks, { type: rec?.mimeType || "video/webm" }));
      });
      rec.start(200);
      await new Promise<void>((resolve) => {
        let remaining=videoDuration; setRecordCountdown(remaining);
        const tick=()=>{ remaining-=1; setRecordCountdown(Math.max(0,remaining)); if(remaining<=0){ if(talkRef.current.ttsActive) stopTts(); if(ttsTimerRef.current !== null) window.clearTimeout(ttsTimerRef.current); resolve(); } else ttsTimerRef.current=window.setTimeout(tick,1000); };
        ttsTimerRef.current=window.setTimeout(tick,1000);
      });
      if (rec.state !== "inactive") rec.stop();
      const recordedBlob = await stopped;
      if (recordedBlob.type.includes("mp4")) {
        saveBlob(recordedBlob, "animutation.mp4");
        setNotice("Video MP4 exportado nativamente por el navegador, con audio activo.");
      } else {
        saveBlob(recordedBlob, "animutation.webm");
        setNotice("Este navegador no admite MP4 nativo para grabación; exporté el video en WEBM con audio.");
      }
    } catch (err) {
      if (rec && rec.state !== "inactive") rec.stop();
      setNotice(err instanceof Error ? err.message : "No pude grabar el video. Prueba Solo imagen.");
    } finally {
      setExporting(false);
      setRecordCountdown(null);
      if (ttsTimerRef.current !== null) window.clearTimeout(ttsTimerRef.current);
    }
  }

  function nudgeMouth(delta: number) {
    setFx((prev) => ({ ...prev, mouthMax: clampMouth((prev.mouthMax ?? 1) + delta) }));
  }

  function savePuppet() {
    if (!image || !markers) {
      setNotice("No hay una cara para guardar.");
      return;
    }
    const payload = {
      kind: "animutation-puppet",
      version: 1,
      caption,
      fx: { ...fx, mouthMax: clampMouth(fx.mouthMax) },
      mouthMax: clampMouth(fx.mouthMax),
      volume,
      tolerance,
      markers,
      faces,
      image: image.toDataURL("image/png"),
    };
    saveBlob(new Blob([JSON.stringify(payload)], { type: "application/json" }), "proyecto.puppet.json");
    setNotice(`Guardado proyecto.puppet.json. Apertura máxima: ${Math.round(clampMouth(fx.mouthMax) * 100)}%.`);
  }

  async function openPuppet(file: File | undefined) {
    if (!file) return;
    try {
      const data = JSON.parse(await file.text()) as {
        kind?: string;
        caption?: string;
        fx?: Partial<Fx>;
        mouthMax?: number;
        volume?: number;
        tolerance?: number;
        markers?: Markers;
        faces?: FaceSlot[];
        image?: string;
      };
      if (data.kind !== "animutation-puppet" || !data.image || !data.markers) {
        setNotice("Ese archivo no es un .puppet.json.");
        return;
      }
      const loaded = await loadHtmlImage(data.image);
      const canvas = document.createElement("canvas");
      canvas.width = loaded.naturalWidth;
      canvas.height = loaded.naturalHeight;
      canvas.getContext("2d")?.drawImage(loaded, 0, 0);
      const mouthMax = clampMouth(data.mouthMax ?? data.fx?.mouthMax ?? 1);
      setImage(canvas);
      setMarkers(data.markers);
      setFaces(Array.isArray(data.faces) ? data.faces : []);
      setFx((prev) => ({ ...DEFAULT_FX, ...prev, ...data.fx, mouthMax, mouthWidth: clampMouthWidth(data.fx?.mouthWidth ?? DEFAULT_FX.mouthWidth) }));
      if (typeof data.volume === "number") setVolume(data.volume);
      if (typeof data.tolerance === "number") setTolerance(data.tolerance);
      setCaption(data.caption || file.name);
      setKind("photo");
      setCrop(null);
      setMode("edit");
      setNotice(`Proyecto abierto. Apertura máxima: ${Math.round(mouthMax * 100)}%.`);
    } catch {
      setNotice("No pude abrir ese proyecto.");
    }
  }

  function pointerImage(event: { clientX: number; clientY: number }): Pt | null {
    const stage = stageRef.current;
    if (!stage) return null;
    const rect = stage.getBoundingClientRect();
    return viewToImage(view, event.clientX - rect.left, event.clientY - rect.top);
  }

  function onMarkerPointer(id: string, event: ReactPointerEvent<HTMLButtonElement>) {
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.focus();
    event.currentTarget.setPointerCapture(event.pointerId);
    setActiveId(id);
    const point = pointerImage(event);
    if (!point || !image) return;
    if (markers) commitMarkers(moveMarker(markers, id, clampPoint(point, image)));
  }

  function onMarkerMove(id: string, event: ReactPointerEvent<HTMLButtonElement>) {
    event.preventDefault();
    if (activeId !== id || !event.currentTarget.hasPointerCapture(event.pointerId)) return;
    const point = pointerImage(event);
    if (!point || !image) return;
    if (markers) commitMarkers(moveMarker(markers, id, clampPoint(point, image)));
  }

  const dots = markers ? listMarkers(markers) : [];

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-ink lg:h-dvh lg:overflow-hidden">
      <header className="mx-auto w-full max-w-6xl px-3 py-3 lg:px-5">
        <div className="mm-titlebar">
          <h1>Animutation Puppet Maker</h1>
          <p className="text-xs font-bold tracking-wide uppercase">Macromedia</p>
        </div>
        <p className="mm-caption">Sube una cara, marca la boca y haz que cante como un flash de 2003.</p>
        <div className="cafecito-retro-wrap">
          <span className="cafecito-retro-label">¿Te gusta Animutation forever?</span>
          <a href="https://cafecito.app/xd_77" rel="noopener" target="_blank">
            <img
              srcSet="https://cdn.cafecito.app/imgs/buttons/button_5.png 1x, https://cdn.cafecito.app/imgs/buttons/button_5_2x.png 2x, https://cdn.cafecito.app/imgs/buttons/button_5_3.75x.png 3.75x"
              src="https://cdn.cafecito.app/imgs/buttons/button_5.png"
              alt="Invitame un café en cafecito.app"
            />
          </a>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-6xl flex-1 flex-col gap-3 px-3 pb-20 lg:min-h-0 lg:flex-row lg:px-5">
        <div className="flex min-h-0 flex-col gap-3 lg:min-w-0 lg:flex-1">
          <div
            ref={stageRef}
            className="puppet-stage mm-stage sticker relative h-stage min-h-72 overflow-hidden select-none lg:h-auto lg:min-h-0 lg:flex-1"
            style={{ touchAction: "none" }}
            onDragOver={(event) => event.preventDefault()}
            onDrop={(event) => {
              event.preventDefault();
              const file = event.dataTransfer.files[0];
              void onUpload(file);
            }}
            onPointerDown={handleFaceBoxPointerDown}
            onPointerMove={handleFaceBoxPointerMove}
            onPointerUp={handleFaceBoxPointerUp}
          >
            <canvas
              ref={canvasRef}
              className="absolute inset-0 h-full w-full"
              style={{ touchAction: "none" }}
              aria-label="Escenario del títere"
            />
            {draft && image ? (
              <div className="absolute z-30 border-2 border-[#00d0e0] bg-[#00d0e0]/15 pointer-events-none" style={{ left: view.ox + draft.x * view.scale, top: view.oy + draft.y * view.scale, width: draft.w * view.scale, height: draft.h * view.scale }} />
            ) : null}
            {mode === "edit" && !crop && image && !armDraw
              ? dots.map((dot) => {
                  const keyLabel =
                    dot.id === "eyeL" || dot.id === "eyeR" || dot.id === "nose" || dot.id === "mouth-2" || dot.id === "jaw-3";
                  const showLabel = keyLabel || activeId === dot.id;
                  return (
                    <button
                      key={dot.id}
                      type="button"
                      aria-label={dot.label}
                      className={`absolute z-20 flex size-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center select-none ${activeId === dot.id ? "z-30" : ""}`}
                      style={{
                        left: view.ox + dot.pt.x * view.scale,
                        top: view.oy + dot.pt.y * view.scale,
                        touchAction: "none",
                      }}
                      onPointerDown={(event) => onMarkerPointer(dot.id, event)}
                      onPointerMove={(event) => onMarkerMove(dot.id, event)}
                      onPointerUp={() => setActiveId(null)}
                      onTouchStart={(event) => event.preventDefault()}
                      onTouchMove={(event) => event.preventDefault()}
                      onKeyDown={(event) => {
                        const step = event.shiftKey ? 10 : 2;
                        let dx = 0;
                        let dy = 0;
                        if (event.key === "ArrowLeft") dx = -step;
                        else if (event.key === "ArrowRight") dx = step;
                        else if (event.key === "ArrowUp") dy = -step;
                        else if (event.key === "ArrowDown") dy = step;
                        else return;
                        event.preventDefault();
                        if (markers) commitMarkers(nudgeMarker(markers, dot.id, dx, dy));
                      }}
                    >
                      <span className={`pointer-events-none size-4 rounded-full border-2 border-ink ${TONE_CLASS[dot.tone]}`} />
                      <span
                        className={`pointer-events-none absolute top-0 left-1/2 -translate-x-1/2 -translate-y-full rounded-md border-2 border-ink bg-cream px-1 text-xs font-bold whitespace-nowrap text-ink ${showLabel ? "" : "max-sm:sr-only"}`}
                      >
                        {dot.short}
                      </span>
                    </button>
                  );
                })
              : null}
            {crop && image ? (
              <div
                className="crop-dim absolute border-4 border-yellow"
                style={{
                  left: view.ox + crop.x * view.scale,
                  top: view.oy + crop.y * view.scale,
                  width: crop.w * view.scale,
                  height: crop.h * view.scale,
                  touchAction: "none",
                }}
                onPointerDown={(event) => {
                  event.preventDefault();
                  if (event.target !== event.currentTarget) return;
                  const point = pointerImage(event);
                  if (!point) return;
                  cropDrag.current = { handle: "move", start: point, orig: crop };
                  event.currentTarget.setPointerCapture(event.pointerId);
                }}
                onPointerMove={(event) => {
                  event.preventDefault();
                  const drag = cropDrag.current;
                  const current = imageRef.current;
                  if (!drag || !current) return;
                  const point = pointerImage(event);
                  if (!point) return;
                  setCrop(dragCrop(drag.orig, drag.start, point, drag.handle, current.width, current.height));
                }}
                onPointerUp={() => {
                  cropDrag.current = null;
                }}
              >
                {(["nw", "ne", "sw", "se"] as const).map((handle) => (
                  <button
                    key={handle}
                    type="button"
                    aria-label={`Esquina ${handle}`}
                    className={`absolute z-20 size-11 border-2 border-black bg-[#ffe14a] ${handle.includes("n") ? "top-0 -translate-y-1/2" : "bottom-0 translate-y-1/2"} ${handle.includes("w") ? "left-0 -translate-x-1/2" : "right-0 translate-x-1/2"}`}
                    style={{ touchAction: "none" }}
                    onPointerDown={(event) => {
                      event.preventDefault();
                      event.stopPropagation();
                      const point = pointerImage(event);
                      if (!point || !crop) return;
                      cropDrag.current = { handle, start: point, orig: crop };
                      event.currentTarget.setPointerCapture(event.pointerId);
                    }}
                    onPointerMove={(event) => event.preventDefault()}
                  />
                ))}
              </div>
            ) : null}
          </div>

          {image ? (
            <section className="sticker mm-panel p-3 text-ink">
              <h2 className="text-base font-bold">Preparación rápida</h2>
              <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
                {bgToolAvailable ? <button type="button" className={solid} onClick={() => void knockOutBackground()} disabled={removingBg || !!crop || armDraw}>
                  <Eraser className="size-5" aria-hidden /> {removingBg ? "Quitando fondo…" : "Quitar fondo (IA)"}
                </button> : null}
                <button type="button" className={hot} onClick={() => void autoDetect()} disabled={!image || detecting || armDraw}>
                  <ScanFace className="size-5" aria-hidden /> {detecting ? "Detectando…" : "Auto-detectar rostro"}
                </button>
                {bgToolAvailable ? (
                  <button type="button" className={sun} onClick={startFaceSelection} disabled={!image || detecting}>
                    <Crosshair className="size-5" aria-hidden /> {armDraw ? "Dibuja en la foto…" : "🎯 Elegir / Añadir cara"}
                  </button>
                ) : null}
              </div>
              {faces.length ? (
                <div className="mt-3 flex flex-wrap gap-2">
                  {faces.map((face, index) => (
                    <div key={face.id} className="flex items-center gap-1">
                      <button type="button" className={activeFaceId === face.id ? hot : solid} onClick={() => activateFace(face)}>
                        Cara {index + 1}{activeFaceId === face.id ? " ✓" : ""}
                      </button>
                      <button type="button" className={solid} aria-label={`Eliminar cara ${index + 1}`} onClick={() => removeFace(face.id)}>×</button>
                    </div>
                  ))}
                </div>
              ) : null}
              {!bgToolAvailable ? (
                <div className="mt-3 rounded-lg border-2 border-[#ff2f9a] bg-[#ff2f9a]/10 p-3">
                  <p className="font-extrabold">Quitafondos desactivado por lentitud o error</p>
                  <p className="mt-1 text-sm">Usa selección múltiple: encierra una cara con un recuadro y se detectarán sus ojos, nariz y boca. Puedes agregar todas las caras que necesites.</p>
                  <button type="button" className={`${sun} mt-2 w-full border-2 border-[#ff2f9a] bg-[#ff2f9a] text-white font-extrabold`} onClick={startFaceSelection} disabled={!image || detecting}>
                    <Crosshair className="size-5" aria-hidden /> 🎯 Seleccionar / Añadir caras
                  </button>
                </div>
              ) : null}
              {armDraw ? <p className="mt-2 text-sm font-semibold text-ink/80">Arrastra sobre la imagen para encerrar la cara. Al soltar, se analiza esa zona.</p> : null}
            </section>
          ) : null}

          <div className="flex flex-col gap-2 sm:flex-row">
            {mode === "edit" ? (
              <button type="button" className={`${sun} flex-1 text-lg font-bold tracking-wide`} onClick={() => void animate()}>
                <Play className="size-6" aria-hidden />
                ¡Animar!
              </button>
            ) : (
              <button type="button" className={`${ice} flex-1 text-lg font-bold tracking-wide`} onClick={backToEdit}>
                <Pencil className="size-6" aria-hidden />
                Modo edición
              </button>
            )}
            {mode === "play" ? (
              <span className="blink mm-badge inline-flex min-h-11 items-center justify-center px-4 text-sm font-bold">
                Al aire
              </span>
            ) : null}
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <button
              type="button"
              className={`${mode === "still" ? hot : solid} flex-1`}
              aria-pressed={mode === "still"}
              onClick={showStill}
            >
              <ImageIcon className="size-5" aria-hidden />
              Solo imagen
            </button>
            <button type="button" className={`${sun} flex-1`} onClick={() => void download()} disabled={exporting || !image}>
              <Download className="size-5" aria-hidden />
              {exporting ? "Grabando…" : mode === "still" ? "Descargar imagen" : "Descargar video"}
            </button>
          </div>
          {mode !== "still" ? (
            <label className="mt-2 block text-sm font-semibold">Duración del video (segundos): {videoDuration}
              <input className="slider w-full" type="range" min={2} max={30} step={1} value={videoDuration} disabled={exporting} onChange={(e)=>setVideoDuration(Number(e.target.value))}/>
            </label>
          ) : null}
          {recordCountdown !== null ? <div className="mm-countdown" role="status">⏺ Grabando: faltan {recordCountdown}s</div> : null}
          <p className="text-sm text-ink/80" role="status">
            {caption}. {notice}
          </p>
        </div>

        <aside className="flex w-full shrink-0 flex-col gap-3 lg:min-h-0 lg:w-80 lg:overflow-y-auto lg:pr-1">
          <section className="sticker mm-panel p-3 text-ink">
            <h2 className="text-base font-bold">Imagen</h2>
            <p className="mt-1 text-sm text-ink/70">JPG, PNG o WebP. También puedes soltarla sobre el escenario.</p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button type="button" className={sun} onClick={() => fileRef.current?.click()}>
                <Upload className="size-5" aria-hidden />
                Subir
              </button>
              <button type="button" className={solid} onClick={loadDemo}>
                <Sparkles className="size-5" aria-hidden />
                Bean
              </button>
              <button type="button" className={solid} onClick={trimEdges} disabled={!image || !!crop}>
                <Scissors className="size-5" aria-hidden />
                Recortar sobrante
              </button>
              {crop ? (
                <>
                  <button type="button" className={sun} onClick={applyCrop}>
                    Aplicar recorte
                  </button>
                  <button type="button" className={solid} onClick={() => setCrop(null)}>
                    Cancelar
                  </button>
                </>
              ) : (
                <button type="button" className={solid} onClick={beginCrop} disabled={!image}>
                  <Crop className="size-5" aria-hidden />
                  Recorte manual
                </button>
              )}
              <button type="button" className={solid} onClick={centerHead} disabled={!markers}>
                <Crosshair className="size-5" aria-hidden />
                Centrar cabeza
              </button>
              <button type="button" className={solid} onClick={fitAll} disabled={!image}>
                Ajustar
              </button>
              <button type="button" className={solid} onClick={doUndo} disabled={!undo}>
                <Undo2 className="size-5" aria-hidden />
                Deshacer
              </button>
            </div>
            <input
              ref={fileRef}
              className="sr-only"
              type="file"
              accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"
              onChange={(event) => {
                void onUpload(event.target.files?.[0]);
                event.target.value = "";
              }}
            />
          </section>

          <section className="sticker mm-panel p-3 text-ink">
            <h2 className="text-base font-bold">Puntos</h2>
            <p className="mt-1 text-sm text-ink/70">
              Cian: ojos. Rosa: comisuras. La barbilla marca el fondo del bloque.
              Solo baja ese rectángulo central. Cachetes, cuello y hombros se quedan quietos.
            </p>
            <div className="mt-3 grid grid-cols-1 gap-2">
              <button type="button" className={solid} onClick={resetPoints} disabled={!image}>
                <RotateCcw className="size-5" aria-hidden />
                Reiniciar puntos
              </button>
              <button type="button" className={solid} onClick={patchOpenMouth} disabled={!image || !markers}>
                <Wrench className="size-5" aria-hidden /> 🩹 Parchear boca abierta
              </button>
              <button type="button" className={solid} onClick={undoPatch} disabled={!patchUndoRef.current}>Deshacer parche</button>
            </div>
          </section>

          <section className="sticker mm-panel p-3 text-ink">
            <h2 className="text-base font-bold">Sonido</h2>
            <p className="mt-1 text-sm text-ink/70">
              Silencio hasta que subas un archivo o actives el micrófono. Si el iframe bloquea el micrófono, usa Simular voz o sube un archivo MP3/WAV.
            </p>
            <div className="mt-3 grid grid-cols-1 gap-2">
              <button type="button" className={audioKind === "mic" ? hot : solid} aria-pressed={audioKind === "mic"} onClick={() => void openMic()}>
                <Mic className="size-5" aria-hidden />
                Micrófono en vivo
              </button>
              <button
                type="button"
                className={audioKind === "file" ? hot : solid}
                aria-pressed={audioKind === "file"}
                onClick={() => audioFileRef.current?.click()}
              >
                <FileAudio className="size-5" aria-hidden />
                Subir MP3 / WAV
              </button>
              <button type="button" className={simulating ? hot : solid} aria-pressed={simulating} onClick={toggleSim}>
                <MessageCircle className="size-5" aria-hidden />
                {simulating ? "Parar simulador" : "Simular voz"}
              </button>
              {fileName ? (
                <button type="button" className={`${solid} max-w-full overflow-hidden`} onClick={() => void toggleFilePlayback()}>
                  <AudioLines className="size-5 shrink-0" aria-hidden />
                  <span className="truncate">{filePaused ? `Reproducir ${fileName}` : `Pausa ${fileName}`}</span>
                </button>
              ) : null}
            </div>
            <label className="mt-3 block text-sm font-semibold">
              <span className="flex items-center justify-between">
                Volumen
                <span className="mm-num">{Math.round(volume * 100)}</span>
              </span>
              <input
                className="slider"
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={volume}
                onChange={(event) => {
                  const next = Number(event.target.value);
                  setVolume(next);
                  audioRef.current?.setVolume(next);
                }}
              />
            </label>
            <div className="mt-2 flex h-8 items-end gap-1" ref={meterRef} aria-hidden>
              {Array.from({ length: 10 }, (_, index) => (
                <span key={index} data-bar className="h-full w-full origin-bottom rounded-sm bg-ink/15" />
              ))}
            </div>
            <div ref={meterValue} className="sr-only" role="meter" aria-label="Nivel del audio" aria-valuemin={0} aria-valuemax={100} aria-valuenow={0} />
            <input
              ref={audioFileRef}
              className="sr-only"
              type="file"
              accept="audio/mpeg,audio/wav,audio/wave,audio/x-wav,audio/mp3,.mp3,.wav"
              onChange={(event) => {
                void onAudioFile(event.target.files?.[0]);
                event.target.value = "";
              }}
            />
          </section>

          <section className="sticker mm-panel p-3 text-ink">
            <h2 className="text-base font-bold">🗣️ Texto a Voz (TTS)</h2>
            <p className="mt-1 text-sm text-ink/70">Escribir para Hablar, estilo Loquendo 2003. La animación de boca sigue los eventos de voz del sintetizador.</p>
            <textarea className="mt-2 w-full rounded border-2 border-black bg-white p-2 text-black" rows={3} value={ttsText} onChange={(e)=>setTtsText(e.target.value)} placeholder="Escribe algo para que lo diga el títere…" />
            <div className="mt-3 grid grid-cols-1 gap-2">{(Object.keys(TTS_PRESETS) as Array<keyof typeof TTS_PRESETS>).map((preset) => <button key={preset} type="button" className={ttsPreset === preset ? hot : solid} onClick={() => chooseTtsPreset(preset)}>{TTS_PRESETS[preset].label}</button>)}</div><label className="mt-2 block text-sm font-semibold">Voz del navegador (español priorizado)</label>
            <select className="w-full border-2 border-black bg-white p-2 text-black" value={ttsVoiceURI} onChange={(e)=>setTtsVoiceURI(e.target.value)}>
              <option value="">Voz predeterminada</option>{ttsVoices.map(v=><option key={v.voiceURI} value={v.voiceURI}>{v.name} ({v.lang})</option>)}
            </select>
            <label className="mt-3 block text-sm font-semibold">Tono (Pitch): {ttsPitch.toFixed(1)}</label>
            <input className="slider" type="range" min={0} max={2} step={0.1} value={ttsPitch} onChange={(e)=>setTtsPitch(Number(e.target.value))}/>
            <label className="mt-3 block text-sm font-semibold">Velocidad (Rate): {ttsRate.toFixed(1)}</label>
            <input className="slider" type="range" min={0.5} max={2} step={0.1} value={ttsRate} onChange={(e)=>setTtsRate(Number(e.target.value))}/>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button type="button" className={sun} onClick={speakText} disabled={ttsSpeaking}><Volume2 className="size-5"/>▶ Hablar texto</button>
              <button type="button" className={solid} onClick={stopTts} disabled={!ttsSpeaking}>Detener voz</button>
            </div>
          </section>

          <section className="sticker mm-panel p-3 text-ink">
            <h2 className="text-base font-bold">Efectos</h2>
            <p className="mt-1 text-sm text-ink/70">Cuando la mandíbula baja, el hueco es negro sólido, estilo recorte.</p>
            <div className="mt-3 grid grid-cols-1 gap-2">
              <Toggle on={fx.rays} label="Rayos giratorios" onClick={() => setFx((prev) => ({ ...prev, rays: !prev.rays }))} />
              <Toggle on={fx.spiral} label="Espiral psicodélica" onClick={() => setFx((prev) => ({ ...prev, spiral: !prev.spiral }))} />
              <Toggle on={fx.stars} label="Estrellas" onClick={() => setFx((prev) => ({ ...prev, stars: !prev.stars }))} />
              <Toggle on={fx.zoom} label="Zoom al bajo" onClick={() => setFx((prev) => ({ ...prev, zoom: !prev.zoom }))} />
              <Toggle on={fx.spin !== false} label="Rotación suave" onClick={() => setFx((prev) => ({ ...prev, spin: prev.spin === false }))} />
            </div>
            <label className="mt-3 block text-sm font-semibold">
              <span className="flex items-center justify-between">
                Sensibilidad de la boca
                <span className="mm-num">{fx.sensitivity.toFixed(1)}</span>
              </span>
              <input
                className="slider"
                type="range"
                min={0.4}
                max={2.4}
                step={0.1}
                value={fx.sensitivity}
                onChange={(event) => setFx((prev) => ({ ...prev, sensitivity: Number(event.target.value) }))}
              />
            </label>
            <div className="mt-3">
              <p className="text-sm font-semibold">Apertura máxima de boca</p>
              <div className="mt-2 flex items-center gap-2">
                <button type="button" className={`${solid} flex-1`} onClick={() => nudgeMouth(-0.1)} aria-label="Cerrar más">
                  ▲ − Cerrar más
                </button>
                <span className="mm-num min-w-14 text-center text-base">{Math.round((fx.mouthMax ?? 1) * 100)}%</span>
                <button type="button" className={`${solid} flex-1`} onClick={() => nudgeMouth(0.1)} aria-label="Abrir más">
                  ▼ + Abrir más
                </button>
              </div>
              <p className="mt-1 text-xs text-ink/70">Apertura se guarda en proyecto.puppet.json.</p><p className="mt-3 text-sm font-semibold">Ancho de boca</p><div className="mt-2 flex items-center gap-2"><button type="button" className={`${solid} flex-1`} onClick={() => setFx((prev) => ({ ...prev, mouthWidth: Math.max(0.45, (prev.mouthWidth ?? 1) - 0.05) }))}>◀ Angostar (-)</button><span className="mm-num min-w-14 text-center text-base">{Math.round((fx.mouthWidth ?? 1) * 100)}%</span><button type="button" className={`${solid} flex-1`} onClick={() => setFx((prev) => ({ ...prev, mouthWidth: Math.min(1.8, (prev.mouthWidth ?? 1) + 0.05) }))}>Ensanchar (+) ▶</button></div><p className="mt-1 text-xs text-ink/70">El ancho se ajusta desde el centro y queda guardado en el .puppet.json.</p>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <button type="button" className={sun} onClick={savePuppet} disabled={!image || !markers}>
                  <Download className="size-5" aria-hidden />
                  Guardar .puppet.json
                </button>
                <button type="button" className={solid} onClick={() => projectRef.current?.click()}>
                  <Upload className="size-5" aria-hidden />
                  Abrir proyecto
                </button>
              </div>
              <input
                ref={projectRef}
                className="sr-only"
                type="file"
                accept="application/json,.json,.puppet.json"
                onChange={(event) => {
                  void openPuppet(event.target.files?.[0]);
                  event.target.value = "";
                }}
              />
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
}

function Toggle({ on, label, onClick }: { on: boolean; label: string; onClick: () => void }) {
  return (
    <button type="button" aria-pressed={on} onClick={onClick} className={`${solid} w-full justify-between`}>
      <span>{label}</span>
      <span className={`flex h-7 w-12 items-center border-2 border-black p-0.5 ${on ? "bg-[#0a246a]" : "bg-[#d4d0c8]"}`}>
        <span className={`size-5 border-2 border-black bg-white ${on ? "translate-x-4" : "translate-x-0"}`} />
      </span>
    </button>
  );
}

function clampMouthWidth(value: number | undefined): number {
  return Math.max(0.45, Math.min(1.8, value ?? 1));
}

function clampMouth(value: number | undefined): number {
  const next = typeof value === "number" && Number.isFinite(value) ? value : 1;
  return Math.min(2.2, Math.max(0.4, Math.round(next * 10) / 10));
}

function clampPoint(point: Pt, image: HTMLCanvasElement): Pt {
  const padX = image.width * 0.08;
  const padY = image.height * 0.08;
  return {
    x: Math.max(-padX, Math.min(image.width + padX, point.x)),
    y: Math.max(-padY, Math.min(image.height + padY, point.y)),
  };
}

function clampToImage(point: Pt, image: HTMLCanvasElement): Pt {
  return { x: Math.max(0, Math.min(image.width, point.x)), y: Math.max(0, Math.min(image.height, point.y)) };
}

function paintMeter(meter: HTMLDivElement | null, value: HTMLDivElement | null, level: number) {
  if (!meter) return;
  const bars = meter.querySelectorAll<HTMLElement>("[data-bar]");
  bars.forEach((bar, index) => {
    const on = level * 12 > index;
    bar.style.transform = `scaleY(${on ? 0.35 + index * 0.07 : 0.2})`;
    bar.style.background = on
      ? index > 7
        ? "var(--color-pink)"
        : "var(--color-yellow)"
      : "color-mix(in srgb, var(--color-ink) 15%, transparent)";
  });
  if (value) value.setAttribute("aria-valuenow", String(Math.round(level * 100)));
}

function loadHtmlImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("imagen"));
    image.src = src;
  });
}

function canvasToBlob(canvas: HTMLCanvasElement): Promise<Blob | null> {
  return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), "image/png"));
}

function saveBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

function bestVoiceForPreset(voices: SpeechSynthesisVoice[], preset: "jorge" | "carlos" | "carmen" | "ardilla") {
  if (!voices.length) return undefined;
  const spanish = voices.filter((voice) => /^es(-|$)/i.test(voice.lang));
  const pool = spanish.length ? spanish : voices;
  const maleNames = /jorge|diego|juan|pablo|carlos|alberto|andres|andrés|male|masculino|hombre/i;
  const femaleNames = /carmen|sabina|paulina|helena|monica|m[oó]nica|lucia|luc[ií]a|female|femenino|mujer/i;
  const scored = pool.map((voice) => {
    const name = voice.name;
    let score = /^es(-|$)/i.test(voice.lang) ? 100 : 0;
    if (/google|microsoft/i.test(name)) score += 10;
    if (preset === "jorge") {
      if (/jorge/i.test(name)) score += 80;
      if (/diego|juan|pablo|alex|alberto/i.test(name)) score += 45;
      if (maleNames.test(name)) score += 30;
      if (femaleNames.test(name)) score -= 50;
    } else if (preset === "carlos") {
      if (/carlos/i.test(name)) score += 80;
      if (/male|masculino|hombre/i.test(name)) score += 55;
      if (/jorge|diego|juan|pablo/i.test(name)) score += 35;
      if (femaleNames.test(name)) score -= 60;
    } else if (preset === "carmen") {
      if (/carmen/i.test(name)) score += 80;
      if (/sabina|paulina|helena|monica|m[oó]nica|luc[ií]a/i.test(name)) score += 50;
      if (femaleNames.test(name)) score += 35;
      if (maleNames.test(name)) score -= 60;
    } else {
      // Ardilla mainly relies on the high pitch and faster rate; prefer any Spanish voice.
      score += /google|microsoft/i.test(name) ? 20 : 0;
    }
    return { voice, score };
  }).sort((a, b) => b.score - a.score);
  return scored[0]?.voice;
}

function pickVideoMime(): string {
  if (typeof MediaRecorder === "undefined") return "";
  const types = ["video/mp4;codecs=avc1,mp4a.40.2", "video/mp4", "video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"];
  return types.find((type) => MediaRecorder.isTypeSupported(type)) ?? "";
}

type Talk = { env: number; gap: number; prev: number; ttsActive?: boolean; ttsEnv?: number; ttsPulse?: number; ttsGap?: number };

function voiceLevels(audio: AudioLevels, dt: number, sim: boolean, talk: Talk): AudioLevels {
  if (talk.ttsActive) {
    talk.ttsGap = (talk.ttsGap ?? 0) - dt;
    if (talk.ttsGap <= 0) { talk.ttsPulse = 0.35 + Math.random() * 0.55; talk.ttsGap = 0.09 + Math.random() * 0.17; }
    talk.ttsPulse = Math.max(0, (talk.ttsPulse ?? 0) - dt * 3.8);
    talk.ttsEnv = Math.max(talk.ttsPulse ?? 0, (talk.ttsEnv ?? 0) * Math.exp(-dt * 5.5));
    const level = Math.min(1, talk.ttsEnv ?? 0);
    return { level, bass: level * 0.45, tilt: 0, onset: Math.max(0, level - talk.prev) };
  }
  if (!sim) return audio;
  talk.gap -= dt;
  if (talk.gap <= 0) {
    talk.env = 0.42 + Math.random() * 0.58;
    talk.gap = 0.05 + Math.random() * 0.16;
  } else {
    talk.env *= Math.exp(-dt * 9);
  }
  const level = Math.max(0, Math.min(1, talk.env));
  const onset = Math.max(0, level - talk.prev);
  talk.prev = level;
  return { level, bass: level * 0.45, tilt: 0, onset };
}
