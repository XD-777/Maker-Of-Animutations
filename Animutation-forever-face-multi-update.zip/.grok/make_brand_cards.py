#!/usr/bin/env python3
"""Hand-built Animutation Puppet Maker share cards (image gen unavailable)."""

import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

PINK = (255, 47, 123)
CREAM = (255, 246, 223)
INK = (26, 16, 36)
YELLOW = (255, 225, 74)
CYAN = (61, 255, 232)
RAYS = [PINK, YELLOW, CYAN, CREAM]
FONT_PATH = "/workspace/.grok/fonts/LuckiestGuy-Regular.ttf"


def font(size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_PATH, size)


def star_pts(cx, cy, r_out, r_in, n=5, rot=-math.pi / 2):
    pts = []
    for i in range(n * 2):
        ang = rot + i * math.pi / n
        r = r_out if i % 2 == 0 else r_in
        pts.append((cx + r * math.cos(ang), cy + r * math.sin(ang)))
    return pts


def draw_star(d, cx, cy, r, fill, outline=INK, width=4, rot=-math.pi / 2):
    d.polygon(star_pts(cx, cy, r, r * 0.42, rot=rot), fill=fill, outline=outline)
    # polygon outline is 1px; redraw thick by stroking a slightly larger star behind
    # (caller can pass a pre-drawn outline star). width kept for API symmetry.


def draw_star_thick(d, cx, cy, r, fill, width=5, rot=-math.pi / 2):
    d.polygon(star_pts(cx, cy, r + width * 0.65, (r + width * 0.65) * 0.42, rot=rot), fill=INK)
    d.polygon(star_pts(cx, cy, r, r * 0.42, rot=rot), fill=fill)


def sunburst(d, cx, cy, radius, n, rot, colors):
    for i in range(n):
        a0 = rot + i * math.tau / n
        a1 = rot + (i + 1) * math.tau / n
        pts = [(cx, cy)]
        steps = 6
        for s in range(steps + 1):
            a = a0 + (a1 - a0) * s / steps
            pts.append((cx + math.cos(a) * radius, cy + math.sin(a) * radius))
        d.polygon(pts, fill=colors[i % len(colors)])


def puppet(d, cx, cy, r):
    sw = max(4, int(round(r * 0.055)))
    # head
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=CREAM, outline=INK, width=sw)
    # cheeks
    cr = r * 0.16
    for sx in (-1, 1):
        ccx = cx + sx * r * 0.52
        ccy = cy + r * 0.08
        d.ellipse([ccx - cr, ccy - cr * 0.72, ccx + cr, ccy + cr * 0.72], fill=PINK)
    # eyes
    er = r * 0.20
    eye_y = cy - r * 0.22
    for sx in (-1, 1):
        ex = cx + sx * r * 0.36
        d.ellipse([ex - er, eye_y - er, ex + er, eye_y + er], fill=INK)
        hr = er * 0.38
        d.ellipse(
            [ex - er * 0.45, eye_y - er * 0.5, ex - er * 0.45 + hr * 2, eye_y - er * 0.5 + hr * 2],
            fill=CREAM,
        )
    # forehead star
    draw_star_thick(d, cx, cy - r * 0.62, r * 0.16, YELLOW, width=max(3, sw // 2))
    # open jaw
    mw = r * 0.70
    mh = r * 0.50
    top = cy + r * 0.08
    d.ellipse([cx - mw, top, cx + mw, top + mh], fill=INK)
    inset = r * 0.055
    d.ellipse(
        [cx - mw + inset, top + inset * 1.6, cx + mw - inset, top + mh - inset * 0.35],
        fill=CYAN,
    )
    # upper teeth
    inner_l = cx - mw + inset * 2.2
    inner_r = cx + mw - inset * 2.2
    teeth_top = top + inset * 1.15
    teeth_h = r * 0.13
    n = 4
    span = inner_r - inner_l
    gap = span * 0.045
    tw = (span - gap * (n + 1)) / n
    for i in range(n):
        x0 = inner_l + gap + i * (tw + gap)
        d.rectangle([x0, teeth_top, x0 + tw, teeth_top + teeth_h], fill=CREAM, outline=INK, width=max(2, sw // 2))
    # hinge bolts
    br = r * 0.09
    for sx in (-1, 1):
        bx = cx + sx * mw * 0.92
        by = top + mh * 0.42
        d.ellipse([bx - br, by - br, bx + br, by + br], fill=YELLOW, outline=INK, width=max(2, sw // 2))
        arm = br * 0.55
        d.line([(bx - arm, by), (bx + arm, by)], fill=INK, width=max(2, sw // 3))
        d.line([(bx, by - arm), (bx, by + arm)], fill=INK, width=max(2, sw // 3))


def scatter_stars(d, specs):
    for cx, cy, r, fill, rot in specs:
        draw_star_thick(d, cx, cy, r, fill, width=max(3, int(r * 0.12)), rot=rot)


def text_block(lines, sw):
    """lines: list[(text, font)] -> total height and per-line heights using stroke."""
    dummy = ImageDraw.Draw(Image.new("RGB", (8, 8)))
    heights = []
    widths = []
    for text, fnt in lines:
        bb = dummy.textbbox((0, 0), text, font=fnt, stroke_width=sw)
        widths.append(bb[2] - bb[0])
        heights.append(bb[3] - bb[1])
    return widths, heights


def draw_lines(d, cx, cy, lines, fill, sw, gap):
    _, heights = text_block(lines, sw)
    total = sum(heights) + gap * (len(lines) - 1)
    y = cy - total / 2
    for (text, fnt), h in zip(lines, heights):
        d.text(
            (cx, y + h / 2),
            text,
            font=fnt,
            fill=fill,
            stroke_width=sw,
            stroke_fill=INK,
            anchor="mm",
        )
        y += h + gap


def make_og():
    w, h = 1200, 630
    im = Image.new("RGB", (w, h), INK)
    d = ImageDraw.Draw(im)
    sunburst(d, w / 2, h / 2 + 10, 980, 16, -0.18, RAYS)
    scatter_stars(
        d,
        [
            (78, 78, 36, YELLOW, -0.4),
            (1128, 86, 30, CYAN, 0.2),
            (70, 548, 28, CREAM, 0.5),
            (1136, 520, 40, YELLOW, -0.2),
            (190, 540, 22, PINK, 0.8),
            (1040, 150, 24, CREAM, 0.1),
            (220, 120, 18, CYAN, 0.4),
            (980, 560, 20, CYAN, -0.6),
        ],
    )
    puppet(d, 600, 292, 248)

    # Title sticker, slightly tilted, dead-center-ish with real margins.
    lines = [
        ("ANIMUTATION", font(112)),
        ("PUPPET MAKER", font(86)),
    ]
    sw = 8
    gap = 4
    widths, heights = text_block(lines, sw)
    tw = max(widths)
    th = sum(heights) + gap
    pad_x, pad_y = 46, 28
    bw, bh = tw + pad_x * 2, th + pad_y * 2
    layer = Image.new("RGBA", (int(bw + 40), int(bh + 40)), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    ox, oy = 14, 16
    box = [18, 16, 18 + bw, 16 + bh]
    shadow = [box[0] + ox, box[1] + oy, box[2] + ox, box[3] + oy]
    ld.rounded_rectangle(shadow, radius=36, fill=YELLOW + (255,), outline=INK + (255,), width=8)
    ld.rounded_rectangle(box, radius=36, fill=PINK + (255,), outline=INK + (255,), width=8)
    tcx = (box[0] + box[2]) / 2
    tcy = (box[1] + box[3]) / 2 - 2
    draw_lines(ld, tcx, tcy, lines, CREAM, sw, gap)
    rotated = layer.rotate(-3.2, resample=Image.BICUBIC, expand=True)
    px = (w - rotated.width) // 2
    py = (h - rotated.height) // 2 + 18
    im.paste(rotated, (px, py), rotated)

    # A few stars in front, kept off the lettering.
    d = ImageDraw.Draw(im)
    scatter_stars(
        d,
        [
            (150, 300, 26, YELLOW, 0.3),
            (1068, 330, 28, CYAN, -0.5),
        ],
    )
    return im


def make_banner():
    w, h = 1200, 264
    im = Image.new("RGB", (w, h), INK)
    d = ImageDraw.Draw(im)
    sunburst(d, 860, 150, 820, 14, 0.35, RAYS)
    scatter_stars(
        d,
        [
            (560, 46, 18, YELLOW, 0.2),
            (640, 200, 16, CREAM, -0.4),
            (1088, 40, 22, CYAN, 0.5),
            (1148, 168, 16, YELLOW, -0.2),
            (700, 48, 14, PINK, 0.7),
        ],
    )
    puppet(d, 930, 148, 132)

    # Lockup entirely in the left half and above the bottom fifth.
    lines = [
        ("ANIMUTATION", font(54)),
        ("PUPPET MAKER", font(40)),
    ]
    sw = 5
    gap = 2
    widths, heights = text_block(lines, sw)
    tw = max(widths)
    th = sum(heights) + gap
    pad_x, pad_y = 28, 16
    bw, bh = tw + pad_x * 2, th + pad_y * 2
    # Anchor the sticker top-left with comfortable margins.
    x0, y0 = 42, 34
    x1, y1 = x0 + bw, y0 + bh
    assert x1 < 600, (x1, "title entered the right half")
    assert y1 < 264 * 0.80, (y1, "title entered the bottom fifth")
    d.rounded_rectangle([x0 + 8, y0 + 8, x1 + 8, y1 + 8], radius=26, fill=YELLOW, outline=INK, width=6)
    d.rounded_rectangle([x0, y0, x1, y1], radius=26, fill=PINK, outline=INK, width=6)
    # Shadow must also stay out of the forbidden zones.
    assert x1 + 8 < 600
    assert y1 + 8 < 264 * 0.80
    draw_lines(d, (x0 + x1) / 2, (y0 + y1) / 2 - 1, lines, CREAM, sw, gap)
    return im


def main():
    out = Path("/workspace/.grok")
    og = make_og()
    banner = make_banner()
    og.save(out / "og-raw.png")
    banner.save(out / "x-banner-raw.png")
    print("og", og.size, "banner", banner.size)


if __name__ == "__main__":
    main()
