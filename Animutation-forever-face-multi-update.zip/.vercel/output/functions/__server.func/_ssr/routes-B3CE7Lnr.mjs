import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Scissors, c as Play, d as FileAudio, f as Eraser, g as AudioLines, h as Crop, i as Sparkles, l as Pencil, m as Crosshair, n as Undo2, o as ScanFace, p as Drum, s as RotateCcw, t as Upload, u as Mic } from "../_libs/lucide-react.mjs";
import { n as previewPathPrefix } from "./router-6K9Sa1ev.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B3CE7Lnr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AudioRig = class {
	ctx;
	analyser;
	audible;
	freq;
	time;
	kind = "none";
	stream = null;
	micNode = null;
	fileEl = null;
	fileNode = null;
	fileUrl = null;
	beat = null;
	beatBuffer = null;
	prevLevel = 0;
	volume = .85;
	constructor() {
		const ctx = new AudioContext();
		const analyser = ctx.createAnalyser();
		analyser.fftSize = 1024;
		analyser.smoothingTimeConstant = .72;
		const audible = ctx.createGain();
		audible.gain.value = this.volume;
		audible.connect(analyser);
		analyser.connect(ctx.destination);
		this.ctx = ctx;
		this.analyser = analyser;
		this.audible = audible;
		this.freq = new Uint8Array(analyser.frequencyBinCount);
		this.time = new Uint8Array(analyser.fftSize);
	}
	async ensure() {
		if (this.ctx.state !== "running") await this.ctx.resume();
	}
	setVolume(value) {
		this.volume = value;
		this.audible.gain.value = value;
	}
	getKind() {
		return this.kind;
	}
	sample() {
		this.analyser.getByteTimeDomainData(this.time);
		this.analyser.getByteFrequencyData(this.freq);
		let sum = 0;
		for (let i = 0; i < this.time.length; i++) {
			const x = ((this.time[i] ?? 128) - 128) / 128;
			sum += x * x;
		}
		const rms = Math.sqrt(sum / this.time.length);
		const level = Math.min(1, rms * 3.4);
		const n = this.freq.length;
		const bassN = Math.max(2, Math.floor(n * .08));
		let bass = 0;
		let lowMid = 0;
		let highMid = 0;
		const lm1 = Math.floor(n * .28);
		const hm1 = Math.floor(n * .6);
		for (let i = 0; i < n; i++) {
			const v = (this.freq[i] ?? 0) / 255;
			if (i < bassN) bass += v;
			else if (i < lm1) lowMid += v;
			else if (i < hm1) highMid += v;
		}
		bass /= bassN;
		const lm = lowMid / Math.max(1, lm1 - bassN);
		const hm = highMid / Math.max(1, hm1 - lm1);
		const tilt = Math.max(-1, Math.min(1, (hm - lm) * 2.4));
		const onset = Math.max(0, level - this.prevLevel);
		this.prevLevel = level;
		return {
			level,
			bass: Math.min(1, bass * 1.6),
			tilt,
			onset
		};
	}
	hush(except) {
		if (except !== "file" && this.fileEl && !this.fileEl.paused) this.fileEl.pause();
		if (except !== "beat" && this.beat) {
			try {
				this.beat.stop();
			} catch {}
			this.beat.disconnect();
			this.beat = null;
		}
		if (except !== "mic" && (this.micNode || this.stream)) {
			this.micNode?.disconnect();
			this.micNode = null;
			this.stream?.getTracks().forEach((track) => track.stop());
			this.stream = null;
		}
	}
	async startBeat() {
		await this.ensure();
		this.hush("beat");
		if (!this.beatBuffer) this.beatBuffer = createBeatBuffer(this.ctx);
		const src = this.ctx.createBufferSource();
		src.buffer = this.beatBuffer;
		src.loop = true;
		src.connect(this.audible);
		src.start();
		this.beat = src;
		this.kind = "beat";
		src.onended = () => {
			if (this.beat === src) this.beat = null;
		};
	}
	async startMic() {
		await this.ensure();
		if (!navigator.mediaDevices?.getUserMedia) throw new Error("Este navegador no deja usar el micrófono.");
		this.hush("mic");
		if (!this.stream) try {
			this.stream = await navigator.mediaDevices.getUserMedia({
				audio: {
					echoCancellation: true,
					noiseSuppression: true
				},
				video: false
			});
		} catch (err) {
			const name = err instanceof DOMException ? err.name : "";
			if (name === "NotAllowedError" || name === "SecurityError") throw new Error("El navegador bloqueó el micrófono. Permite el acceso y vuelve a intentar.");
			if (name === "NotFoundError") throw new Error("No encontré un micrófono en este dispositivo.");
			throw new Error("No pude abrir el micrófono.");
		}
		this.micNode = this.ctx.createMediaStreamSource(this.stream);
		this.micNode.connect(this.analyser);
		this.kind = "mic";
	}
	async loadFile(file) {
		await this.ensure();
		this.hush("file");
		if (!this.fileEl) {
			this.fileEl = new Audio();
			this.fileEl.preload = "auto";
			this.fileNode = this.ctx.createMediaElementSource(this.fileEl);
			this.fileNode.connect(this.audible);
		}
		if (this.fileUrl) URL.revokeObjectURL(this.fileUrl);
		this.fileUrl = URL.createObjectURL(file);
		this.fileEl.src = this.fileUrl;
		try {
			await this.fileEl.play();
		} catch {
			throw new Error("Ese audio no se pudo leer. Prueba con un MP3 o WAV.");
		}
		this.kind = "file";
	}
	fileIsPaused() {
		return !this.fileEl || this.fileEl.paused;
	}
	async toggleFile() {
		if (!this.fileEl) return;
		await this.ensure();
		if (this.fileEl.paused) {
			this.hush("file");
			await this.fileEl.play();
			this.kind = "file";
		} else this.fileEl.pause();
	}
	/** Pause speakers but keep a live mic armed. */
	suspendAudible() {
		if (this.fileEl && !this.fileEl.paused) this.fileEl.pause();
		if (this.beat) {
			try {
				this.beat.stop();
			} catch {}
			this.beat.disconnect();
			this.beat = null;
		}
	}
	async resumeSelected() {
		if (this.kind === "beat") await this.startBeat();
		else if (this.kind === "file") await this.toggleFileIfPaused();
		else if (this.kind === "mic") await this.startMic();
	}
	async toggleFileIfPaused() {
		if (this.fileEl && this.fileEl.paused) {
			this.hush("file");
			await this.fileEl.play();
		}
	}
	close() {
		this.suspendAudible();
		this.stream?.getTracks().forEach((track) => track.stop());
		if (this.fileUrl) URL.revokeObjectURL(this.fileUrl);
		this.ctx.close();
	}
};
function createBeatBuffer(ctx) {
	const interval = 60 / 112;
	const length = Math.floor(ctx.sampleRate * interval * 2);
	const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
	const data = buffer.getChannelData(0);
	const sr = ctx.sampleRate;
	const kicks = [0, interval];
	const hats = [interval * .5, interval * 1.5];
	for (const t0 of kicks) {
		let phase = 0;
		const n = Math.floor(sr * .2);
		for (let i = 0; i < n; i++) {
			const idx = Math.floor(t0 * sr) + i;
			if (idx < 0 || idx >= data.length) break;
			const t = i / sr;
			const freq = 170 * Math.exp(-t * 12) + 46;
			phase += 2 * Math.PI * freq / sr;
			data[idx] = (data[idx] ?? 0) + Math.sin(phase) * Math.exp(-t * 10) * .95;
		}
	}
	for (const t0 of hats) {
		const n = Math.floor(sr * .045);
		for (let i = 0; i < n; i++) {
			const idx = Math.floor(t0 * sr) + i;
			if (idx < 0 || idx >= data.length) break;
			const env = Math.exp(-i / sr * 70);
			data[idx] = (data[idx] ?? 0) + (Math.random() * 2 - 1) * env * .28;
		}
	}
	for (let i = 0; i < data.length; i++) {
		const v = data[i] ?? 0;
		data[i] = Math.max(-1, Math.min(1, v));
	}
	return buffer;
}
function lerp(a, b, t) {
	return {
		x: a.x + (b.x - a.x) * t,
		y: a.y + (b.y - a.y) * t
	};
}
function mid(a, b) {
	return lerp(a, b, .5);
}
function dist(a, b) {
	return Math.hypot(a.x - b.x, a.y - b.y);
}
function defaultMarkers(w, h) {
	const s = Math.min(w, h);
	const cx = w * .5;
	const top = h * .5 - s * .32;
	const face = s * .34;
	const eyeY = top + face * .92;
	const mouthY = top + face * 1.55;
	const mouthW = face * .72;
	const dip = face * .1;
	return {
		eyeL: {
			x: cx - face * .42,
			y: eyeY
		},
		eyeR: {
			x: cx + face * .42,
			y: eyeY
		},
		nose: {
			x: cx,
			y: top + face * 1.22
		},
		mouth: [
			{
				x: cx - mouthW,
				y: mouthY
			},
			{
				x: cx - mouthW * .5,
				y: mouthY + dip
			},
			{
				x: cx,
				y: mouthY + dip * 1.3
			},
			{
				x: cx + mouthW * .5,
				y: mouthY + dip
			},
			{
				x: cx + mouthW,
				y: mouthY
			}
		],
		jaw: [
			{
				x: cx - mouthW * 1.2,
				y: mouthY + dip * .2
			},
			{
				x: cx - mouthW * 1.45,
				y: mouthY + face * .55
			},
			{
				x: cx - mouthW * .75,
				y: mouthY + face * .95
			},
			{
				x: cx,
				y: mouthY + face * 1.18
			},
			{
				x: cx + mouthW * .75,
				y: mouthY + face * .95
			},
			{
				x: cx + mouthW * 1.45,
				y: mouthY + face * .55
			},
			{
				x: cx + mouthW * 1.2,
				y: mouthY + dip * .2
			}
		]
	};
}
var MOUTH_META = [
	["Comisura izquierda", "Boca L"],
	["Labio", "Labio"],
	["Centro de la boca", "Centro"],
	["Labio", "Labio"],
	["Comisura derecha", "Boca R"]
];
var JAW_META = [
	["Mandíbula izquierda", "M. L"],
	["Mandíbula", "M"],
	["Mentón", "Mentón"],
	["Barbilla", "Barbilla"],
	["Mentón", "Mentón"],
	["Mandíbula", "M"],
	["Mandíbula derecha", "M. R"]
];
function listMarkers(m) {
	const out = [
		{
			id: "eyeL",
			pt: m.eyeL,
			label: "Ojo izquierdo",
			short: "Ojo L",
			tone: "cyan"
		},
		{
			id: "eyeR",
			pt: m.eyeR,
			label: "Ojo derecho",
			short: "Ojo R",
			tone: "cyan"
		},
		{
			id: "nose",
			pt: m.nose,
			label: "Nariz",
			short: "Nariz",
			tone: "yellow"
		}
	];
	m.mouth.forEach((p, i) => {
		const meta = MOUTH_META[i] ?? ["Boca", "Boca"];
		out.push({
			id: `mouth-${i}`,
			pt: p,
			label: meta[0],
			short: meta[1],
			tone: "pink"
		});
	});
	m.jaw.forEach((p, i) => {
		const meta = JAW_META[i] ?? ["Mandíbula", "M"];
		out.push({
			id: `jaw-${i}`,
			pt: p,
			label: meta[0],
			short: meta[1],
			tone: "yellow"
		});
	});
	return out;
}
function moveMarker(m, id, nextPt) {
	const mouth = m.mouth.map((p) => ({ ...p }));
	const jaw = m.jaw.map((p) => ({ ...p }));
	const next = {
		eyeL: { ...m.eyeL },
		eyeR: { ...m.eyeR },
		nose: { ...m.nose },
		mouth,
		jaw
	};
	if (id === "eyeL") next.eyeL = nextPt;
	else if (id === "eyeR") next.eyeR = nextPt;
	else if (id === "nose") next.nose = nextPt;
	else if (id.startsWith("mouth-")) {
		const i = Number(id.slice(6));
		if (mouth[i]) mouth[i] = nextPt;
	} else if (id.startsWith("jaw-")) {
		const i = Number(id.slice(4));
		if (jaw[i]) jaw[i] = nextPt;
	}
	return next;
}
function nudgeMarker(m, id, dx, dy) {
	const current = listMarkers(m).find((item) => item.id === id);
	if (!current) return m;
	return moveMarker(m, id, {
		x: current.pt.x + dx,
		y: current.pt.y + dy
	});
}
function mapMarkers(m, fn) {
	return {
		eyeL: fn(m.eyeL),
		eyeR: fn(m.eyeR),
		nose: fn(m.nose),
		mouth: m.mouth.map(fn),
		jaw: m.jaw.map(fn)
	};
}
/** Keep the chin polygon below the lip line so the cut cannot flip inside out. */
function sanitizeMarkers(m) {
	const jaw = m.jaw.map((p) => ({ ...p }));
	const left = m.mouth[0];
	const right = m.mouth[m.mouth.length - 1];
	if (left && jaw[0] && jaw[0].y < left.y) jaw[0] = {
		x: jaw[0].x,
		y: left.y + 6
	};
	const last = jaw.length - 1;
	if (right && jaw[last] && jaw[last].y < right.y) jaw[last] = {
		x: jaw[last].x,
		y: right.y + 6
	};
	return {
		...m,
		mouth: m.mouth.map((p) => ({ ...p })),
		jaw
	};
}
function cutPath(markers) {
	const path = new Path2D();
	curve(path, markers.mouth, true);
	curve(path, [...markers.jaw].reverse(), false);
	path.closePath();
	return path;
}
function curve(path, pts, move) {
	if (pts.length === 0) return;
	const first = pts[0];
	if (!first) return;
	if (move) path.moveTo(first.x, first.y);
	else path.lineTo(first.x, first.y);
	if (pts.length < 3) {
		for (let i = 1; i < pts.length; i++) {
			const p = pts[i];
			if (p) path.lineTo(p.x, p.y);
		}
		return;
	}
	for (let i = 1; i < pts.length - 1; i++) {
		const curr = pts[i];
		const next = pts[i + 1];
		if (!curr || !next) continue;
		const xc = (curr.x + next.x) / 2;
		const yc = (curr.y + next.y) / 2;
		path.quadraticCurveTo(curr.x, curr.y, xc, yc);
	}
	const last = pts[pts.length - 1];
	if (last) path.lineTo(last.x, last.y);
}
function markersFromBox(x, y, w, h) {
	const cx = x + w * .5;
	const mouthY = y + h * .7;
	const mouthW = w * .2;
	const dip = h * .025;
	return sanitizeMarkers({
		eyeL: {
			x: x + w * .34,
			y: y + h * .4
		},
		eyeR: {
			x: x + w * .66,
			y: y + h * .4
		},
		nose: {
			x: cx,
			y: y + h * .54
		},
		mouth: [
			{
				x: cx - mouthW,
				y: mouthY
			},
			{
				x: cx - mouthW * .5,
				y: mouthY + dip
			},
			{
				x: cx,
				y: mouthY + dip * 1.35
			},
			{
				x: cx + mouthW * .5,
				y: mouthY + dip
			},
			{
				x: cx + mouthW,
				y: mouthY
			}
		],
		jaw: [
			{
				x: x + w * .28,
				y: y + h * .7
			},
			{
				x: x + w * .24,
				y: y + h * .82
			},
			{
				x: x + w * .36,
				y: y + h * .94
			},
			{
				x: cx,
				y: y + h * .99
			},
			{
				x: x + w * .64,
				y: y + h * .94
			},
			{
				x: x + w * .76,
				y: y + h * .82
			},
			{
				x: x + w * .72,
				y: y + h * .7
			}
		]
	});
}
function markersFromLandmarks(lms, width, height) {
	if (lms.length < 300) return null;
	const P = (i) => {
		const lm = lms[i];
		if (!lm) return {
			x: width / 2,
			y: height / 2
		};
		return {
			x: lm.x * width,
			y: lm.y * height
		};
	};
	const avg = (ids) => {
		let x = 0;
		let y = 0;
		for (const id of ids) {
			const p = P(id);
			x += p.x;
			y += p.y;
		}
		return {
			x: x / ids.length,
			y: y / ids.length
		};
	};
	const left = P(61);
	const right = P(291);
	const seam = mid(P(13), P(14));
	const mouth = [
		left,
		lerp(P(37), seam, .45),
		seam,
		lerp(P(267), seam, .45),
		right
	];
	const jaw = [
		172,
		136,
		150,
		152,
		378,
		365,
		397
	].map((id) => P(id));
	return sanitizeMarkers({
		eyeL: avg([
			33,
			133,
			159,
			145
		]),
		eyeR: avg([
			263,
			362,
			386,
			374
		]),
		nose: P(1),
		mouth,
		jaw
	});
}
/** Absolute URL that still works when the preview is mounted under a path prefix. */
function publicAsset(path) {
	const clean = path.startsWith("/") ? path : `/${path}`;
	if (typeof window === "undefined") return clean;
	return `${previewPathPrefix(window.location.hostname, window.location.pathname) ?? ""}${clean}`;
}
var landmarkerPromise = null;
async function loadLandmarker() {
	if (!landmarkerPromise) landmarkerPromise = (async () => {
		const vision = await import("../_libs/mediapipe__tasks-vision.mjs").then((n) => n.t);
		const fileset = await vision.FilesetResolver.forVisionTasks(publicAsset("/mediapipe"));
		return vision.FaceLandmarker.createFromOptions(fileset, {
			baseOptions: {
				modelAssetPath: publicAsset("/models/face_landmarker.task"),
				delegate: "CPU"
			},
			runningMode: "IMAGE",
			numFaces: 1,
			minFaceDetectionConfidence: .35,
			minFacePresenceConfidence: .35
		});
	})().catch((err) => {
		landmarkerPromise = null;
		throw err;
	});
	return landmarkerPromise;
}
function shapeDetector() {
	const ctor = window.FaceDetector;
	if (!ctor) return null;
	try {
		return new ctor({
			fastMode: false,
			maxDetectedFaces: 1
		});
	} catch {
		return null;
	}
}
async function detectFace(canvas) {
	try {
		const face = (await loadLandmarker()).detect(canvas).faceLandmarks[0];
		if (face) {
			const markers = markersFromLandmarks(face, canvas.width, canvas.height);
			if (markers) return {
				ok: true,
				markers,
				precise: true
			};
		}
	} catch (err) {
		console.warn("MediaPipe no pudo detectar", err);
	}
	const basic = await detectWithShape(canvas);
	if (basic) return {
		ok: true,
		markers: basic,
		precise: false
	};
	return {
		ok: false,
		message: "No veo un rostro claro en esta imagen. No pasa nada: coloca los puntos con el dedo o el mouse. Funciona igual con dibujos."
	};
}
async function detectWithShape(canvas) {
	const detector = shapeDetector();
	if (!detector) return null;
	let faces = [];
	try {
		faces = await detector.detect(canvas);
	} catch {
		return null;
	}
	const face = faces[0];
	if (!face?.boundingBox) return null;
	const box = face.boundingBox;
	const markers = markersFromBox(box.x ?? box.left ?? 0, box.y ?? box.top ?? 0, box.width, box.height);
	let eyeL = null;
	let eyeR = null;
	let nose = null;
	let mouth = null;
	for (const landmark of face.landmarks ?? []) {
		const loc = landmark.locations?.[0];
		if (!loc) continue;
		const p = {
			x: loc.x,
			y: loc.y
		};
		if (landmark.type === "eye") {
			if (!eyeL || p.x < eyeL.x) {
				if (eyeL) eyeR = eyeL;
				eyeL = p;
			} else eyeR = p;
		} else if (landmark.type === "nose") nose = p;
		else if (landmark.type === "mouth") mouth = p;
	}
	if (eyeL) markers.eyeL = eyeL;
	if (eyeR) markers.eyeR = eyeR;
	if (nose) markers.nose = nose;
	if (mouth) {
		const dx = mouth.x - (markers.mouth[2]?.x ?? mouth.x);
		const dy = mouth.y - (markers.mouth[2]?.y ?? mouth.y);
		markers.mouth = markers.mouth.map((p) => ({
			x: p.x + dx,
			y: p.y + dy
		}));
	}
	return markers;
}
function fitView(imgW, imgH, viewW, viewH) {
	const scale = Math.max(.01, Math.min((viewW - 36) / imgW, (viewH - 36) / imgH));
	return {
		scale,
		ox: (viewW - imgW * scale) / 2,
		oy: (viewH - imgH * scale) / 2
	};
}
function faceView(markers, viewW, viewH) {
	const pts = [
		markers.eyeL,
		markers.eyeR,
		markers.nose,
		...markers.mouth,
		...markers.jaw
	];
	let minX = Infinity;
	let minY = Infinity;
	let maxX = -Infinity;
	let maxY = -Infinity;
	for (const p of pts) {
		minX = Math.min(minX, p.x);
		minY = Math.min(minY, p.y);
		maxX = Math.max(maxX, p.x);
		maxY = Math.max(maxY, p.y);
	}
	const bw = Math.max(8, maxX - minX);
	const bh = Math.max(8, maxY - minY);
	const cx = (minX + maxX) / 2;
	const cy = (minY + maxY) / 2 - bh * .04;
	const scale = Math.min(viewW * .84 / bw, viewH * .84 / bh);
	return {
		scale,
		ox: viewW / 2 - cx * scale,
		oy: viewH / 2 - cy * scale
	};
}
function viewToImage(view, vx, vy) {
	return {
		x: (vx - view.ox) / view.scale,
		y: (vy - view.oy) / view.scale
	};
}
function clamp(n, min, max) {
	return Math.max(min, Math.min(max, n));
}
function clampCrop(rect, imgW, imgH) {
	let { x, y, w, h } = rect;
	w = Math.max(36, w);
	h = Math.max(36, h);
	if (x < 0) {
		w += x;
		x = 0;
	}
	if (y < 0) {
		h += y;
		y = 0;
	}
	if (x + w > imgW) w = imgW - x;
	if (y + h > imgH) h = imgH - y;
	w = Math.max(36, Math.min(w, imgW));
	h = Math.max(36, Math.min(h, imgH));
	x = clamp(x, 0, Math.max(0, imgW - w));
	y = clamp(y, 0, Math.max(0, imgH - h));
	return {
		x,
		y,
		w,
		h
	};
}
function dragCrop(orig, start, current, handle, imgW, imgH) {
	const dx = current.x - start.x;
	const dy = current.y - start.y;
	let { x, y, w, h } = orig;
	if (handle === "move") {
		x += dx;
		y += dy;
	}
	if (handle === "se" || handle === "ne") w += dx;
	if (handle === "sw" || handle === "nw") {
		x += dx;
		w -= dx;
	}
	if (handle === "se" || handle === "sw") h += dy;
	if (handle === "ne" || handle === "nw") {
		y += dy;
		h -= dy;
	}
	return clampCrop({
		x,
		y,
		w,
		h
	}, imgW, imgH);
}
function initialCrop(imgW, imgH, markers) {
	if (!markers) {
		const m = .08;
		return clampCrop({
			x: imgW * m,
			y: imgH * m,
			w: imgW * (1 - m * 2),
			h: imgH * (1 - m * 2)
		}, imgW, imgH);
	}
	const pts = [
		markers.eyeL,
		markers.eyeR,
		markers.nose,
		...markers.mouth,
		...markers.jaw
	];
	let minX = Infinity;
	let minY = Infinity;
	let maxX = -Infinity;
	let maxY = -Infinity;
	for (const p of pts) {
		minX = Math.min(minX, p.x);
		minY = Math.min(minY, p.y);
		maxX = Math.max(maxX, p.x);
		maxY = Math.max(maxY, p.y);
	}
	const padX = (maxX - minX) * .28;
	const padY = (maxY - minY) * .28;
	return clampCrop({
		x: minX - padX,
		y: minY - padY * 1.4,
		w: maxX - minX + padX * 2,
		h: maxY - minY + padY * 2.1
	}, imgW, imgH);
}
function cloneCanvas(src) {
	const canvas = document.createElement("canvas");
	canvas.width = src.width;
	canvas.height = src.height;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) throw new Error("No se pudo preparar el lienzo.");
	ctx.drawImage(src, 0, 0);
	return canvas;
}
async function canvasFromFile(file) {
	const url = URL.createObjectURL(file);
	try {
		const img = await loadHtmlImage(url);
		const scale = Math.min(1, 1280 / Math.max(img.naturalWidth, img.naturalHeight));
		const w = Math.max(1, Math.round(img.naturalWidth * scale));
		const h = Math.max(1, Math.round(img.naturalHeight * scale));
		const canvas = document.createElement("canvas");
		canvas.width = w;
		canvas.height = h;
		const ctx = canvas.getContext("2d", { willReadFrequently: true });
		if (!ctx) throw new Error("No se pudo leer la imagen.");
		ctx.imageSmoothingEnabled = true;
		ctx.imageSmoothingQuality = "high";
		ctx.drawImage(img, 0, 0, w, h);
		return canvas;
	} finally {
		URL.revokeObjectURL(url);
	}
}
function loadHtmlImage(url) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("No pude abrir esa imagen. Usa JPG, PNG o WebP."));
		img.src = url;
	});
}
/**
* Flood-fills from the borders, knocking out pixels close to each edge seed.
* Flat studio backdrops disappear; a busy photo only loses the matching rim.
*/
function removeBackground(src, tolerance) {
	const canvas = cloneCanvas(src);
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) return canvas;
	const w = canvas.width;
	const h = canvas.height;
	const img = ctx.getImageData(0, 0, w, h);
	const d = img.data;
	const visited = new Uint8Array(w * h);
	const tol2 = tolerance * tolerance;
	const qx = new Int32Array(w * h);
	const qy = new Int32Array(w * h);
	const flood = (sx, sy) => {
		const si = sy * w + sx;
		if (visited[si]) return;
		const so = si * 4;
		const sr = d[so] ?? 0;
		const sg = d[so + 1] ?? 0;
		const sb = d[so + 2] ?? 0;
		let qs = 0;
		let qe = 0;
		qx[qe] = sx;
		qy[qe] = sy;
		qe += 1;
		visited[si] = 1;
		while (qs < qe) {
			const x = qx[qs] ?? 0;
			const y = qy[qs] ?? 0;
			qs += 1;
			const i = y * w + x;
			const o = i * 4;
			const dr = (d[o] ?? 0) - sr;
			const dg = (d[o + 1] ?? 0) - sg;
			const db = (d[o + 2] ?? 0) - sb;
			if (!((d[o + 3] ?? 0) < 10) && dr * dr + dg * dg + db * db > tol2) {
				visited[i] = 0;
				continue;
			}
			d[o + 3] = 0;
			const next = [
				[x + 1, y],
				[x - 1, y],
				[x, y + 1],
				[x, y - 1]
			];
			for (const [nx, ny] of next) {
				if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
				const ni = ny * w + nx;
				if (visited[ni]) continue;
				visited[ni] = 1;
				qx[qe] = nx;
				qy[qe] = ny;
				qe += 1;
			}
		}
	};
	for (let x = 0; x < w; x++) {
		flood(x, 0);
		flood(x, h - 1);
	}
	for (let y = 0; y < h; y++) {
		flood(0, y);
		flood(w - 1, y);
	}
	ctx.putImageData(img, 0, 0);
	return canvas;
}
function cropImage(src, rect, markers) {
	const x = Math.max(0, Math.round(rect.x));
	const y = Math.max(0, Math.round(rect.y));
	const w = Math.max(1, Math.min(src.width - x, Math.round(rect.w)));
	const h = Math.max(1, Math.min(src.height - y, Math.round(rect.h)));
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("No se pudo recortar.");
	ctx.drawImage(src, x, y, w, h, 0, 0, w, h);
	return {
		canvas,
		markers: mapMarkers(markers, (p) => ({
			x: p.x - x,
			y: p.y - y
		}))
	};
}
function trimTransparency(src, markers) {
	const ctx = src.getContext("2d", { willReadFrequently: true });
	if (!ctx) return null;
	const { data, width, height } = ctx.getImageData(0, 0, src.width, src.height);
	let minX = width;
	let minY = height;
	let maxX = -1;
	let maxY = -1;
	for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) if ((data[(y * width + x) * 4 + 3] ?? 0) > 16) {
		if (x < minX) minX = x;
		if (y < minY) minY = y;
		if (x > maxX) maxX = x;
		if (y > maxY) maxY = y;
	}
	if (maxX < 0) return null;
	const pad = 10;
	const x = Math.max(0, minX - pad);
	const y = Math.max(0, minY - pad);
	const right = Math.min(width - 1, maxX + pad);
	const bottom = Math.min(height - 1, maxY + pad);
	if (!(x > 1 || y > 1 || right < width - 2 || bottom < height - 2)) return {
		canvas: src,
		markers,
		trimmed: false
	};
	return {
		...cropImage(src, {
			x,
			y,
			w: right - x + 1,
			h: bottom - y + 1
		}, markers),
		trimmed: true
	};
}
var PALETTE = [
	"#ff2f7b",
	"#ffe14a",
	"#3dffe8",
	"#fff6df"
];
var PuppetRenderer = class {
	canvas = null;
	image = null;
	markers = null;
	view = {
		scale: 1,
		ox: 0,
		oy: 0
	};
	layers = null;
	stars = makeStars(48);
	t = 0;
	mouth = 0;
	bassSmooth = 0;
	tiltSmooth = 0;
	autoPeak = .05;
	bassPeak = .05;
	imageToken = 0;
	attach(canvas) {
		this.canvas = canvas;
	}
	setScene(image, markers, view) {
		if (this.image !== image) {
			this.imageToken += 1;
			this.layers = null;
		}
		this.image = image;
		this.markers = markers;
		this.view = view;
	}
	resetMotion() {
		this.mouth = 0;
		this.bassSmooth = 0;
		this.tiltSmooth = 0;
		this.t = 0;
	}
	drawEdit() {
		const ctx = this.prep();
		if (!ctx || !this.image || !this.markers) return;
		const { dpr, w, h } = this.size();
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.clearRect(0, 0, w, h);
		drawChecker(ctx, w, h);
		this.blitImage(ctx, dpr, this.image);
		this.strokeGuides(ctx, dpr);
	}
	frame(dt, levels, fx, reduceMotion) {
		const ctx = this.prep();
		if (!ctx || !this.image || !this.markers) return;
		const { dpr, w, h } = this.size();
		this.t += dt;
		this.follow(dt, levels, fx.sensitivity);
		const markers = this.markers;
		const faceH = Math.max(40, Math.max(...markers.jaw.map((p) => p.y)) - Math.min(markers.eyeL.y, markers.eyeR.y));
		const openPx = this.mouth * faceH * .22;
		const spin = reduceMotion ? .15 : 1;
		const headRot = Math.sin(this.t * 1.7) * (.035 + this.mouth * .1) * (reduceMotion ? .35 : 1);
		const bob = -this.bassSmooth * faceH * .045;
		const sway = Math.sin(this.t * 1.25) * this.mouth * faceH * .02;
		const zoom = fx.zoom ? 1 + this.bassSmooth * .16 : 1;
		const jawTilt = this.tiltSmooth * .22 * (reduceMotion ? .4 : 1);
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.clearRect(0, 0, w, h);
		drawBackdrop(ctx, w, h, this.t * spin, fx, this.stars);
		const view = this.view;
		ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.ox, dpr * view.oy);
		const pivot = markers.nose;
		ctx.translate(pivot.x + sway, pivot.y);
		ctx.rotate(headRot);
		ctx.translate(0, bob);
		ctx.scale(zoom, zoom);
		ctx.translate(-pivot.x, -pivot.y);
		const layers = this.ensureLayers();
		drawMouthInterior(ctx, markers, layers.cut, openPx, fx.mouth);
		ctx.drawImage(layers.upper, 0, 0);
		drawJaw(ctx, layers.jaw, markers, openPx, jawTilt);
		drawEyes(ctx, this.image, markers, this.mouth, levels.onset, this.t, reduceMotion, view.scale * zoom);
	}
	follow(dt, levels, sensitivity) {
		this.autoPeak = Math.max(levels.level, this.autoPeak * Math.exp(-dt * .45));
		if (this.autoPeak < .035) this.autoPeak = .035;
		const norm = Math.min(1, levels.level / this.autoPeak);
		const drive = Math.min(1, norm * sensitivity);
		const attack = drive > this.mouth ? 18 : 8;
		this.mouth += (drive - this.mouth) * (1 - Math.exp(-dt * attack));
		this.bassPeak = Math.max(levels.bass, this.bassPeak * Math.exp(-dt * 1.1));
		const bnorm = Math.min(1, levels.bass / Math.max(.04, this.bassPeak));
		this.bassSmooth += (bnorm - this.bassSmooth) * (1 - Math.exp(-dt * 14));
		const tiltTarget = levels.tilt * this.mouth;
		this.tiltSmooth += (tiltTarget - this.tiltSmooth) * (1 - Math.exp(-dt * 8));
		return drive;
	}
	ensureLayers() {
		if (!this.image || !this.markers) throw new Error("sin escena");
		const key = `${this.imageToken}:${layerKey(this.image, this.markers)}`;
		if (this.layers?.key === key) return this.layers;
		const w = this.image.width;
		const h = this.image.height;
		const cut = cutPath(this.markers);
		const upper = document.createElement("canvas");
		upper.width = w;
		upper.height = h;
		const uctx = upper.getContext("2d");
		if (!uctx) throw new Error("lienzo");
		uctx.drawImage(this.image, 0, 0);
		uctx.globalCompositeOperation = "destination-out";
		uctx.fill(cut);
		const jaw = document.createElement("canvas");
		jaw.width = w;
		jaw.height = h;
		const jctx = jaw.getContext("2d");
		if (!jctx) throw new Error("lienzo");
		jctx.save();
		jctx.clip(cut);
		jctx.drawImage(this.image, 0, 0);
		jctx.restore();
		this.layers = {
			upper,
			jaw,
			cut,
			key
		};
		return this.layers;
	}
	prep() {
		const canvas = this.canvas;
		if (!canvas) return null;
		const { dpr, w, h } = this.size();
		const bw = Math.max(1, Math.round(w * dpr));
		const bh = Math.max(1, Math.round(h * dpr));
		if (canvas.width !== bw || canvas.height !== bh) {
			canvas.width = bw;
			canvas.height = bh;
		}
		return canvas.getContext("2d");
	}
	size() {
		const canvas = this.canvas;
		return {
			dpr: Math.min(2, window.devicePixelRatio || 1),
			w: canvas?.clientWidth ?? 1,
			h: canvas?.clientHeight ?? 1
		};
	}
	blitImage(ctx, dpr, image) {
		const view = this.view;
		ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.ox, dpr * view.oy);
		ctx.imageSmoothingEnabled = true;
		ctx.drawImage(image, 0, 0);
	}
	strokeGuides(ctx, dpr) {
		if (!this.markers) return;
		const view = this.view;
		ctx.setTransform(dpr * view.scale, 0, 0, dpr * view.scale, dpr * view.ox, dpr * view.oy);
		const weight = 3 / view.scale;
		strokeCurve(ctx, this.markers.mouth, "#ff2f7b", weight);
		strokeCurve(ctx, this.markers.jaw, "#ffe14a", weight);
		ctx.setLineDash([8 / view.scale, 7 / view.scale]);
		ctx.beginPath();
		const mouthEnd = this.markers.mouth[this.markers.mouth.length - 1];
		const jawEnd = this.markers.jaw[this.markers.jaw.length - 1];
		const jawStart = this.markers.jaw[0];
		const mouthStart = this.markers.mouth[0];
		if (mouthEnd && jawEnd) {
			ctx.moveTo(mouthEnd.x, mouthEnd.y);
			ctx.lineTo(jawEnd.x, jawEnd.y);
		}
		if (jawStart && mouthStart) {
			ctx.moveTo(jawStart.x, jawStart.y);
			ctx.lineTo(mouthStart.x, mouthStart.y);
		}
		ctx.strokeStyle = "#fff6df";
		ctx.lineWidth = weight;
		ctx.stroke();
		ctx.setLineDash([]);
	}
};
function layerKey(image, markers) {
	const body = [
		markers.eyeL,
		markers.eyeR,
		markers.nose,
		...markers.mouth,
		...markers.jaw
	].map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(";");
	return `${image.width}x${image.height}:${body}`;
}
function strokeCurve(ctx, pts, color, width) {
	if (pts.length < 2) return;
	ctx.beginPath();
	ctx.moveTo(pts[0].x, pts[0].y);
	for (let i = 1; i < pts.length - 1; i++) {
		const curr = pts[i];
		const next = pts[i + 1];
		ctx.quadraticCurveTo(curr.x, curr.y, (curr.x + next.x) / 2, (curr.y + next.y) / 2);
	}
	const last = pts[pts.length - 1];
	ctx.lineTo(last.x, last.y);
	ctx.strokeStyle = color;
	ctx.lineWidth = width;
	ctx.lineJoin = "round";
	ctx.lineCap = "round";
	ctx.stroke();
}
function drawChecker(ctx, w, h) {
	const size = 18;
	for (let y = 0; y < h; y += size) for (let x = 0; x < w; x += size) {
		ctx.fillStyle = ((x / size | 0) + (y / size | 0)) % 2 === 0 ? "#241833" : "#1a1028";
		ctx.fillRect(x, y, size, size);
	}
}
function drawBackdrop(ctx, w, h, t, fx, stars) {
	ctx.fillStyle = "#140c22";
	ctx.fillRect(0, 0, w, h);
	if (fx.rays) {
		ctx.save();
		ctx.translate(w / 2, h / 2);
		ctx.rotate(t * .28);
		const radius = Math.hypot(w, h);
		const slices = 16;
		for (let i = 0; i < slices; i++) {
			ctx.beginPath();
			ctx.moveTo(0, 0);
			ctx.arc(0, 0, radius, i * Math.PI * 2 / slices, (i + 1) * Math.PI * 2 / slices);
			ctx.closePath();
			ctx.fillStyle = PALETTE[i % PALETTE.length] ?? "#ffe14a";
			ctx.fill();
		}
		ctx.restore();
	}
	if (fx.spiral) {
		ctx.save();
		ctx.translate(w / 2, h / 2);
		ctx.rotate(t * .45);
		ctx.lineWidth = Math.max(10, w * .018);
		ctx.lineCap = "round";
		for (let k = 0; k < 4; k++) {
			ctx.beginPath();
			ctx.strokeStyle = PALETTE[k] ?? "#ff2f7b";
			const off = k * Math.PI / 2;
			let started = false;
			for (let a = 0; a < Math.PI * 9; a += .14) {
				const r = 6 + a * (Math.max(w, h) * .018);
				const x = Math.cos(a + off) * r;
				const y = Math.sin(a + off) * r;
				if (!started) {
					ctx.moveTo(x, y);
					started = true;
				} else ctx.lineTo(x, y);
			}
			ctx.stroke();
		}
		ctx.restore();
	}
	if (fx.stars) for (const star of stars) {
		const tw = .55 + Math.sin(t * 2.4 + star.phase) * .45;
		drawStar(ctx, star.nx * w, star.ny * h, star.r * (.7 + tw * .5), t * star.spin + star.phase, PALETTE[star.color] ?? "#fff6df");
	}
}
function drawMouthInterior(ctx, markers, cut, openPx, style) {
	ctx.save();
	ctx.clip(cut);
	if (style === "black") {
		ctx.fillStyle = "#07060c";
		ctx.fillRect(-10, -10, 4e3, 4e3);
	} else {
		ctx.fillStyle = "#7a102c";
		ctx.fillRect(-10, -10, 4e3, 4e3);
		const mouth = markers.mouth;
		const center = mouth[2] ?? mouth[0];
		const left = mouth[0];
		const right = mouth[mouth.length - 1];
		if (center && left && right) {
			const width = dist(left, right);
			ctx.fillStyle = "#e21d4a";
			ctx.beginPath();
			ctx.ellipse(center.x, center.y + openPx * .28, width * .46, Math.max(8, openPx * .42), 0, 0, Math.PI * 2);
			ctx.fill();
			if (openPx > 10) {
				const span = right.x - left.x;
				const count = 4;
				for (let i = 0; i < count; i++) {
					const x = left.x + span * ((i + .5) / count);
					ctx.fillStyle = "#fff6df";
					roundTop(ctx, x - span * .07, center.y + 2, span * .13, Math.min(16, openPx * .22));
				}
				ctx.fillStyle = "#ff8ab0";
				ctx.beginPath();
				ctx.ellipse(center.x, center.y + openPx * .42, width * .2, Math.max(6, openPx * .26), 0, 0, Math.PI * 2);
				ctx.fill();
				ctx.strokeStyle = "#7a102c";
				ctx.lineWidth = 3;
				ctx.beginPath();
				ctx.moveTo(center.x, center.y + openPx * .28);
				ctx.lineTo(center.x, center.y + openPx * .58);
				ctx.stroke();
			}
		}
	}
	ctx.restore();
}
function roundTop(ctx, x, y, w, h) {
	ctx.beginPath();
	ctx.moveTo(x, y + h);
	ctx.lineTo(x, y + h * .45);
	ctx.quadraticCurveTo(x + w / 2, y, x + w, y + h * .45);
	ctx.lineTo(x + w, y + h);
	ctx.closePath();
	ctx.fill();
}
function drawJaw(ctx, jaw, markers, openPx, tilt) {
	const pivot = markers.mouth[2] ?? markers.nose;
	const jawPts = markers.jaw;
	let cx = 0;
	let cy = 0;
	for (const p of jawPts) {
		cx += p.x;
		cy += p.y;
	}
	cx /= Math.max(1, jawPts.length);
	cy /= Math.max(1, jawPts.length);
	ctx.save();
	ctx.translate(pivot.x, pivot.y);
	ctx.rotate(tilt);
	ctx.translate(0, openPx);
	ctx.translate(-pivot.x, -pivot.y);
	ctx.translate(cx, cy);
	ctx.scale(1.02, 1.02);
	ctx.translate(-cx, -cy);
	ctx.drawImage(jaw, 0, 0);
	ctx.restore();
}
function drawEyes(ctx, image, markers, mouth, onset, t, reduceMotion, viewScale) {
	const gap = dist(markers.eyeL, markers.eyeR);
	const radius = Math.max(10, gap * .28);
	const scl = 1 + mouth * .08 + Math.min(.55, onset * (reduceMotion ? 1.2 : 4));
	const shake = reduceMotion ? 0 : Math.min(10, onset * 42);
	drawOneEye(ctx, image, markers.eyeL, radius, scl, shake, t, 0, viewScale);
	drawOneEye(ctx, image, markers.eyeR, radius, scl, shake, t, 1.7, viewScale);
}
function drawOneEye(ctx, image, eye, radius, scl, shake, t, phase, viewScale) {
	const jx = Math.sin(t * 42 + phase) * shake;
	const jy = Math.cos(t * 37 + phase) * shake * .6;
	const rot = Math.sin(t * 18 + phase) * Math.min(.35, shake * .04);
	ctx.save();
	ctx.translate(eye.x + jx, eye.y + jy);
	ctx.rotate(rot);
	ctx.scale(scl, scl);
	ctx.beginPath();
	ctx.arc(0, 0, radius, 0, Math.PI * 2);
	ctx.clip();
	ctx.drawImage(image, -eye.x, -eye.y);
	ctx.restore();
	if (scl > 1.06) {
		ctx.save();
		ctx.translate(eye.x + jx, eye.y + jy);
		ctx.rotate(rot);
		ctx.beginPath();
		ctx.arc(0, 0, radius * scl, 0, Math.PI * 2);
		ctx.strokeStyle = "#1a1024";
		ctx.lineWidth = 3 / Math.max(.2, viewScale);
		ctx.stroke();
		ctx.restore();
	}
}
function makeStars(count) {
	let seed = 202003;
	const rand = () => {
		seed = (seed * 16807 + 11) % 2147483647;
		return (seed & 2147483647) / 2147483647;
	};
	const stars = [];
	for (let i = 0; i < count; i++) stars.push({
		nx: rand(),
		ny: rand(),
		r: 7 + rand() * 16,
		phase: rand() * Math.PI * 2,
		spin: .4 + rand() * 1.2,
		color: i % PALETTE.length
	});
	return stars;
}
function drawStar(ctx, x, y, r, rot, color) {
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(rot);
	ctx.fillStyle = color;
	ctx.beginPath();
	for (let i = 0; i < 8; i++) {
		const rad = i % 2 === 0 ? r : r * .4;
		const a = -Math.PI / 2 + i * Math.PI / 4;
		const px = Math.cos(a) * rad;
		const py = Math.sin(a) * rad;
		if (i === 0) ctx.moveTo(px, py);
		else ctx.lineTo(px, py);
	}
	ctx.closePath();
	ctx.fill();
	ctx.restore();
}
var INK = "#1a1024";
var CREAM = "#fff6df";
var PINK = "#ff2f7b";
var YELLOW = "#ffe14a";
var CYAN = "#3dffe8";
var PEACH = "#ffc7a3";
var BLUSH = "#ff6b93";
var SAMPLE_H = 1040;
function sampleMarkers() {
	return {
		eyeL: {
			x: 345,
			y: 490
		},
		eyeR: {
			x: 555,
			y: 490
		},
		nose: {
			x: 450,
			y: 575
		},
		mouth: [
			{
				x: 330,
				y: 640
			},
			{
				x: 385,
				y: 672
			},
			{
				x: 450,
				y: 684
			},
			{
				x: 515,
				y: 672
			},
			{
				x: 570,
				y: 640
			}
		],
		jaw: [
			{
				x: 300,
				y: 655
			},
			{
				x: 265,
				y: 740
			},
			{
				x: 320,
				y: 820
			},
			{
				x: 450,
				y: 870
			},
			{
				x: 580,
				y: 820
			},
			{
				x: 635,
				y: 740
			},
			{
				x: 600,
				y: 655
			}
		]
	};
}
function createSample() {
	const canvas = document.createElement("canvas");
	canvas.width = 900;
	canvas.height = SAMPLE_H;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("No se pudo dibujar el personaje.");
	drawBobo(ctx);
	const markers = sampleMarkers();
	const trimmed = trimTransparency(canvas, markers);
	if (trimmed?.trimmed) return {
		canvas: trimmed.canvas,
		markers: trimmed.markers
	};
	return {
		canvas,
		markers
	};
}
function drawBobo(ctx) {
	ctx.clearRect(0, 0, 900, SAMPLE_H);
	const spikes = [
		[
			250,
			300,
			-.7,
			PINK
		],
		[
			330,
			230,
			-.35,
			YELLOW
		],
		[
			450,
			190,
			0,
			CYAN
		],
		[
			570,
			230,
			.35,
			PINK
		],
		[
			650,
			300,
			.7,
			YELLOW
		],
		[
			390,
			210,
			-.12,
			PINK
		],
		[
			510,
			210,
			.12,
			CYAN
		]
	];
	for (const [x, y, rot, color] of spikes) spike(ctx, x, y, 92, 150, color, rot);
	ear(ctx, 214, 530);
	ear(ctx, 686, 530);
	ctx.fillStyle = PEACH;
	ctx.strokeStyle = INK;
	ctx.lineWidth = 10;
	ctx.beginPath();
	ctx.ellipse(450, 530, 230, 270, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.stroke();
	ctx.fillStyle = BLUSH;
	ctx.beginPath();
	ctx.ellipse(320, 590, 42, 24, -.2, 0, Math.PI * 2);
	ctx.ellipse(580, 590, 42, 24, .2, 0, Math.PI * 2);
	ctx.fill();
	eye(ctx, 345, 490);
	eye(ctx, 555, 490);
	ctx.strokeStyle = INK;
	ctx.lineWidth = 8;
	ctx.lineCap = "round";
	ctx.beginPath();
	ctx.moveTo(300, 430);
	ctx.quadraticCurveTo(345, 400, 400, 428);
	ctx.moveTo(500, 428);
	ctx.quadraticCurveTo(555, 400, 600, 430);
	ctx.stroke();
	ctx.fillStyle = YELLOW;
	ctx.strokeStyle = INK;
	ctx.lineWidth = 7;
	ctx.beginPath();
	ctx.moveTo(450, 545);
	ctx.quadraticCurveTo(490, 575, 450, 610);
	ctx.quadraticCurveTo(410, 575, 450, 545);
	ctx.fill();
	ctx.stroke();
	ctx.fillStyle = PINK;
	ctx.strokeStyle = INK;
	ctx.lineWidth = 7;
	ctx.beginPath();
	ctx.ellipse(450, 628, 108, 26, 0, Math.PI, 0);
	ctx.fill();
	ctx.stroke();
	ctx.beginPath();
	ctx.ellipse(450, 712, 96, 32, 0, 0, Math.PI);
	ctx.fill();
	ctx.stroke();
	ctx.fillStyle = INK;
	ctx.beginPath();
	ctx.ellipse(560, 600, 8, 8, 0, 0, Math.PI * 2);
	ctx.fill();
	star(ctx, 450, 790, 28, YELLOW);
}
function spike(ctx, x, y, w, h, color, rot) {
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(rot);
	ctx.fillStyle = color;
	ctx.strokeStyle = INK;
	ctx.lineWidth = 8;
	ctx.lineJoin = "round";
	ctx.beginPath();
	ctx.moveTo(0, -h * .65);
	ctx.lineTo(w * .42, h * .35);
	ctx.lineTo(-w * .42, h * .35);
	ctx.closePath();
	ctx.fill();
	ctx.stroke();
	ctx.restore();
}
function ear(ctx, x, y) {
	ctx.fillStyle = PEACH;
	ctx.strokeStyle = INK;
	ctx.lineWidth = 8;
	ctx.beginPath();
	ctx.ellipse(x, y, 46, 62, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.stroke();
	ctx.fillStyle = PINK;
	ctx.beginPath();
	ctx.ellipse(x, y, 22, 34, 0, 0, Math.PI * 2);
	ctx.fill();
}
function eye(ctx, x, y) {
	ctx.fillStyle = CREAM;
	ctx.strokeStyle = INK;
	ctx.lineWidth = 8;
	ctx.beginPath();
	ctx.ellipse(x, y, 54, 58, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.stroke();
	ctx.fillStyle = INK;
	ctx.beginPath();
	ctx.ellipse(x + 6, y + 6, 24, 28, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = CYAN;
	ctx.beginPath();
	ctx.arc(x + 14, y - 4, 8, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = CREAM;
	ctx.beginPath();
	ctx.arc(x - 16, y - 18, 10, 0, Math.PI * 2);
	ctx.fill();
}
function star(ctx, x, y, r, color) {
	ctx.save();
	ctx.translate(x, y);
	ctx.fillStyle = color;
	ctx.strokeStyle = INK;
	ctx.lineWidth = 6;
	ctx.lineJoin = "round";
	ctx.beginPath();
	for (let i = 0; i < 8; i++) {
		const rad = i % 2 === 0 ? r : r * .42;
		const a = -Math.PI / 2 + i * Math.PI / 4;
		const px = Math.cos(a) * rad;
		const py = Math.sin(a) * rad;
		if (i === 0) ctx.moveTo(px, py);
		else ctx.lineTo(px, py);
	}
	ctx.closePath();
	ctx.fill();
	ctx.stroke();
	ctx.restore();
}
var DEFAULT_FX = {
	spiral: false,
	rays: true,
	stars: true,
	zoom: true,
	mouth: "cartoon",
	sensitivity: 1
};
var SILENT = {
	level: 0,
	bass: 0,
	tilt: 0,
	onset: 0
};
var SETTINGS_KEY = "animutation-puppet-settings-v1";
var btn = "sticker sticker-press inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl px-3 py-2 text-left font-semibold text-ink disabled:opacity-50";
var solid = `${btn} bg-cream`;
var hot = `${btn} bg-pink`;
var sun = `${btn} bg-yellow`;
var ice = `${btn} bg-cyan`;
var TONE_CLASS = {
	cyan: "bg-cyan",
	yellow: "bg-yellow",
	pink: "bg-pink"
};
function PuppetApp() {
	const [image, setImage] = (0, import_react.useState)(null);
	const [markers, setMarkers] = (0, import_react.useState)(null);
	const [kind, setKind] = (0, import_react.useState)("sample");
	const [caption, setCaption] = (0, import_react.useState)("Personaje demo · Bobo");
	const [mode, setMode] = (0, import_react.useState)("edit");
	const [framing, setFraming] = (0, import_react.useState)("fit");
	const [view, setView] = (0, import_react.useState)({
		scale: 1,
		ox: 0,
		oy: 0
	});
	const [notice, setNotice] = (0, import_react.useState)("Bobo ya está en el lienzo. Sube otra cara o pulsa ¡Animar! para el beat de prueba.");
	const [detecting, setDetecting] = (0, import_react.useState)(false);
	const [audioKind, setAudioKind] = (0, import_react.useState)("none");
	const [fileName, setFileName] = (0, import_react.useState)(null);
	const [filePaused, setFilePaused] = (0, import_react.useState)(true);
	const [fx, setFx] = (0, import_react.useState)(DEFAULT_FX);
	const [volume, setVolume] = (0, import_react.useState)(.85);
	const [tolerance, setTolerance] = (0, import_react.useState)(48);
	const [crop, setCrop] = (0, import_react.useState)(null);
	const [undo, setUndo] = (0, import_react.useState)(null);
	const [activeId, setActiveId] = (0, import_react.useState)(null);
	const [reduceMotion, setReduceMotion] = (0, import_react.useState)(false);
	const stageRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	const rendererRef = (0, import_react.useRef)(null);
	const audioRef = (0, import_react.useRef)(null);
	const imageRef = (0, import_react.useRef)(image);
	const markersRef = (0, import_react.useRef)(markers);
	const framingRef = (0, import_react.useRef)(framing);
	const fxRef = (0, import_react.useRef)(fx);
	const volumeRef = (0, import_react.useRef)(volume);
	const modeRef = (0, import_react.useRef)(mode);
	const reduceRef = (0, import_react.useRef)(reduceMotion);
	const meterRef = (0, import_react.useRef)(null);
	const meterValue = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const audioFileRef = (0, import_react.useRef)(null);
	const cropDrag = (0, import_react.useRef)(null);
	imageRef.current = image;
	markersRef.current = markers;
	framingRef.current = framing;
	fxRef.current = fx;
	volumeRef.current = volume;
	modeRef.current = mode;
	reduceRef.current = reduceMotion;
	const layout = (0, import_react.useCallback)(() => {
		const stage = stageRef.current;
		const current = imageRef.current;
		if (!stage || !current) return;
		const w = stage.clientWidth;
		const h = stage.clientHeight;
		if (w < 2 || h < 2) return;
		const next = framingRef.current === "face" && markersRef.current ? faceView(markersRef.current, w, h) : fitView(current.width, current.height, w, h);
		setView(next);
	}, []);
	(0, import_react.useEffect)(() => {
		rendererRef.current = new PuppetRenderer();
		const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
		setReduceMotion(motion.matches);
		const onMotion = () => setReduceMotion(motion.matches);
		motion.addEventListener("change", onMotion);
		try {
			const raw = localStorage.getItem(SETTINGS_KEY);
			if (raw) {
				const saved = JSON.parse(raw);
				if (saved.fx) setFx((prev) => ({
					...prev,
					...saved.fx
				}));
				if (typeof saved.volume === "number") setVolume(saved.volume);
				if (typeof saved.tolerance === "number") setTolerance(saved.tolerance);
			}
		} catch {}
		const { canvas, markers: demo } = createSample();
		setImage(canvas);
		setMarkers(demo);
		return () => {
			motion.removeEventListener("change", onMotion);
			audioRef.current?.close();
			rendererRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const payload = {
			fx,
			volume,
			tolerance
		};
		try {
			localStorage.setItem(SETTINGS_KEY, JSON.stringify(payload));
		} catch {}
	}, [
		fx,
		volume,
		tolerance
	]);
	(0, import_react.useEffect)(() => {
		const stage = stageRef.current;
		if (!stage) return;
		const observer = new ResizeObserver(() => layout());
		observer.observe(stage);
		layout();
		return () => observer.disconnect();
	}, [
		image,
		framing,
		layout
	]);
	(0, import_react.useEffect)(() => {
		const renderer = rendererRef.current;
		const canvas = canvasRef.current;
		if (!renderer || !canvas || !image || !markers || mode !== "edit") return;
		renderer.attach(canvas);
		renderer.setScene(image, markers, view);
		renderer.drawEdit();
	}, [
		image,
		markers,
		view,
		mode
	]);
	(0, import_react.useEffect)(() => {
		if (mode !== "play") return;
		const renderer = rendererRef.current;
		const canvas = canvasRef.current;
		if (!renderer || !canvas || !imageRef.current || !markersRef.current) return;
		renderer.attach(canvas);
		renderer.resetMotion();
		let raf = 0;
		let last = performance.now();
		const loop = (now) => {
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			const currentImage = imageRef.current;
			const currentMarkers = markersRef.current;
			if (currentImage && currentMarkers) {
				renderer.setScene(currentImage, currentMarkers, view);
				const levels = audioRef.current?.sample() ?? SILENT;
				renderer.frame(dt, levels, fxRef.current, reduceRef.current);
				paintMeter(meterRef.current, meterValue.current, levels.level);
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [mode, view]);
	function rig() {
		if (!audioRef.current) audioRef.current = new AudioRig();
		audioRef.current.setVolume(volumeRef.current);
		return audioRef.current;
	}
	async function onUpload(file) {
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			setNotice("Ese archivo no es una imagen. Usa JPG, PNG o WebP.");
			return;
		}
		try {
			const canvas = await canvasFromFile(file);
			const nextMarkers = defaultMarkers(canvas.width, canvas.height);
			if (image && markers) setUndo({
				image,
				markers
			});
			setImage(canvas);
			setMarkers(nextMarkers);
			setKind("photo");
			setCaption(file.name);
			setCrop(null);
			framingRef.current = "fit";
			setFraming("fit");
			setMode("edit");
			setNotice("Imagen lista. Auto-detecta el rostro o arrastra los puntos a mano.");
		} catch (err) {
			setNotice(err instanceof Error ? err.message : "No pude abrir la imagen.");
		}
	}
	function loadDemo() {
		const { canvas, markers: demo } = createSample();
		if (image && markers) setUndo({
			image,
			markers
		});
		setImage(canvas);
		setMarkers(demo);
		setKind("sample");
		setCaption("Personaje demo · Bobo");
		setCrop(null);
		framingRef.current = "fit";
		setFraming("fit");
		setMode("edit");
		setNotice("Bobo de vuelta. La estrella de la barbilla es la que tiene que botar.");
	}
	function snapshotUndo() {
		if (image && markers) setUndo({
			image,
			markers
		});
	}
	function doUndo() {
		if (!undo) return;
		setImage(undo.image);
		setMarkers(undo.markers);
		setUndo(null);
		setCrop(null);
		setNotice("Deshice el último recorte.");
	}
	function knockOutBackground() {
		if (!image || !markers) return;
		snapshotUndo();
		const next = removeBackground(image, tolerance);
		setImage(next);
		setNotice("Fondo recortado desde los bordes. Si se comió la figura, baja la fuerza o deshaz.");
	}
	function trimEdges() {
		if (!image || !markers) return;
		const result = trimTransparency(image, markers);
		if (!result?.trimmed) {
			setNotice("No hay bordes vacíos. Quita el fondo primero o usa el recorte manual.");
			return;
		}
		snapshotUndo();
		setImage(result.canvas);
		setMarkers(result.markers);
		setNotice("Recorté el aire alrededor de la figura.");
	}
	function beginCrop() {
		if (!image || !markers) return;
		setMode("edit");
		setCrop(initialCrop(image.width, image.height, markers));
		setNotice("Ajusta el marco y aplica el recorte. Los puntos se mudan con la imagen.");
	}
	function applyCrop() {
		if (!image || !markers || !crop) return;
		const next = cropImage(image, crop, markers);
		snapshotUndo();
		setImage(next.canvas);
		setMarkers(next.markers);
		setCrop(null);
		framingRef.current = "fit";
		setFraming("fit");
		setNotice("Recorte aplicado.");
	}
	function centerHead() {
		framingRef.current = "face";
		setFraming("face");
		layout();
		setNotice("Centré la cabeza usando los puntos. Si quedó chica, arrastra la mandíbula y vuelve a centrar.");
	}
	function fitAll() {
		framingRef.current = "fit";
		setFraming("fit");
		layout();
	}
	async function autoDetect() {
		if (!image || detecting) return;
		setDetecting(true);
		setMode("edit");
		setNotice("Buscando el rostro…");
		try {
			const outcome = await detectFace(image);
			if (!outcome.ok) {
				setNotice(outcome.message);
				return;
			}
			setMarkers(outcome.markers);
			if (outcome.precise) setNotice("Encontré el rostro y coloqué los puntos. Arrástralos si la boca no calza.");
			else setNotice("Ubiqué la cara a grandes rasgos. Ajusta ojos, la línea rosa de la boca y la barbilla a mano.");
		} finally {
			setDetecting(false);
		}
	}
	function resetPoints() {
		if (!image) return;
		if (kind === "sample") {
			const fresh = createSample();
			if (image.width === fresh.canvas.width && image.height === fresh.canvas.height) {
				setMarkers(fresh.markers);
				setNotice("Puntos de Bobo restaurados.");
				return;
			}
		}
		setMarkers(defaultMarkers(image.width, image.height));
		setNotice("Puntos reiniciados. Auto-detectar los coloca otra vez si hay una cara real.");
	}
	async function animate() {
		const audio = rig();
		audio.ensure();
		setCrop(null);
		setMode("play");
		try {
			if (audio.getKind() === "none") {
				await audio.startBeat();
				setAudioKind("beat");
				setNotice("Beat de prueba en marcha. Cambia al micrófono o sube un MP3 cuando quieras.");
			} else {
				await audio.resumeSelected();
				setAudioKind(audio.getKind());
				setFilePaused(audio.fileIsPaused());
			}
		} catch (err) {
			setNotice(err instanceof Error ? err.message : "No pude arrancar el audio.");
		}
	}
	function backToEdit() {
		audioRef.current?.suspendAudible();
		setFilePaused(true);
		setMode("edit");
		setNotice("Modo edición. Mueve la línea rosa si la boca partió mal y vuelve a animar.");
	}
	async function useBeat() {
		const audio = rig();
		audio.ensure();
		try {
			await audio.startBeat();
			setAudioKind("beat");
			setFilePaused(true);
			setNotice("Beat de prueba sonando. Pulsa ¡Animar! si todavía estás en edición.");
			if (modeRef.current !== "play") setMode("play");
		} catch (err) {
			setNotice(err instanceof Error ? err.message : "No pude crear el beat.");
		}
	}
	async function useMic() {
		const audio = rig();
		audio.ensure();
		try {
			await audio.startMic();
			setAudioKind("mic");
			setNotice("Micrófono activo. No se oye por los altavoces: solo mueve la boca. Habla o pon música cerca.");
			if (modeRef.current !== "play") setMode("play");
		} catch (err) {
			setAudioKind(audio.getKind());
			setNotice(err instanceof Error ? err.message : "No pude abrir el micrófono.");
		}
	}
	async function onAudioFile(file) {
		if (!file) return;
		const audio = rig();
		audio.ensure();
		try {
			await audio.loadFile(file);
			setFileName(file.name);
			setFilePaused(false);
			setAudioKind("file");
			setNotice(`Reproduciendo ${file.name}. La mandíbula sigue el volumen.`);
			if (modeRef.current !== "play") setMode("play");
		} catch (err) {
			setNotice(err instanceof Error ? err.message : "No pude leer el audio.");
		}
	}
	async function toggleFilePlayback() {
		const audio = rig();
		audio.ensure();
		try {
			await audio.toggleFile();
			setFilePaused(audio.fileIsPaused());
			setAudioKind(audio.getKind());
			if (!audio.fileIsPaused() && modeRef.current !== "play") setMode("play");
		} catch (err) {
			setNotice(err instanceof Error ? err.message : "No pude reproducir el audio.");
		}
	}
	function pointerImage(event) {
		const stage = stageRef.current;
		if (!stage) return null;
		const rect = stage.getBoundingClientRect();
		return viewToImage(view, event.clientX - rect.left, event.clientY - rect.top);
	}
	function onMarkerPointer(id, event) {
		event.currentTarget.setPointerCapture(event.pointerId);
		setActiveId(id);
		const point = pointerImage(event);
		if (!point || !image) return;
		setMarkers((current) => current ? moveMarker(current, id, clampPoint(point, image)) : current);
	}
	function onMarkerMove(id, event) {
		if (activeId !== id || !event.currentTarget.hasPointerCapture(event.pointerId)) return;
		const point = pointerImage(event);
		if (!point || !image) return;
		setMarkers((current) => current ? moveMarker(current, id, clampPoint(point, image)) : current);
	}
	const dots = markers ? listMarkers(markers) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-cream lg:h-dvh lg:overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mx-auto flex w-full max-w-6xl items-end justify-between gap-3 px-3 py-3 lg:px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-bold tracking-widest text-cyan uppercase",
				children: "Estudio flash · boca abierta"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "font-display text-3xl leading-none text-yellow sm:text-4xl",
				children: ["Animutation", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block text-pink",
					children: "Puppet Maker"
				})]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden max-w-xs text-right text-sm text-cream/80 sm:block",
				children: "Sube una cara, marca la boca y haz que cante como un flash de 2003."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-6xl flex-1 flex-col gap-3 px-3 pb-20 lg:min-h-0 lg:flex-row lg:px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-col gap-3 lg:min-w-0 lg:flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						ref: stageRef,
						className: "sticker relative h-stage min-h-72 overflow-hidden bg-ink lg:h-auto lg:min-h-0 lg:flex-1",
						onDragOver: (event) => event.preventDefault(),
						onDrop: (event) => {
							event.preventDefault();
							const file = event.dataTransfer.files[0];
							onUpload(file);
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
								ref: canvasRef,
								className: "absolute inset-0 h-full w-full touch-none",
								"aria-label": "Escenario del títere"
							}),
							mode === "edit" && !crop && image ? dots.map((dot) => {
								const showLabel = dot.id === "eyeL" || dot.id === "eyeR" || dot.id === "nose" || dot.id === "mouth-2" || dot.id === "jaw-3" || activeId === dot.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-label": dot.label,
									className: `absolute z-10 flex size-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center ${activeId === dot.id ? "z-30" : ""}`,
									style: {
										left: view.ox + dot.pt.x * view.scale,
										top: view.oy + dot.pt.y * view.scale
									},
									onPointerDown: (event) => onMarkerPointer(dot.id, event),
									onPointerMove: (event) => onMarkerMove(dot.id, event),
									onPointerUp: () => setActiveId(null),
									onKeyDown: (event) => {
										const step = event.shiftKey ? 10 : 2;
										let dx = 0;
										let dy = 0;
										if (event.key === "ArrowLeft") dx = -step;
										else if (event.key === "ArrowRight") dx = step;
										else if (event.key === "ArrowUp") dy = -step;
										else if (event.key === "ArrowDown") dy = step;
										else return;
										event.preventDefault();
										setMarkers((current) => current ? nudgeMarker(current, dot.id, dx, dy) : current);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-4 rounded-full border-2 border-ink ${TONE_CLASS[dot.tone]}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `pointer-events-none absolute top-0 left-1/2 -translate-x-1/2 -translate-y-full rounded-md border-2 border-ink bg-cream px-1 text-xs font-bold whitespace-nowrap text-ink ${showLabel ? "" : "max-sm:sr-only"}`,
										children: dot.short
									})]
								}, dot.id);
							}) : null,
							crop && image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "crop-dim absolute border-4 border-yellow",
								style: {
									left: view.ox + crop.x * view.scale,
									top: view.oy + crop.y * view.scale,
									width: crop.w * view.scale,
									height: crop.h * view.scale
								},
								onPointerDown: (event) => {
									if (event.target !== event.currentTarget) return;
									const point = pointerImage(event);
									if (!point) return;
									cropDrag.current = {
										handle: "move",
										start: point,
										orig: crop
									};
									event.currentTarget.setPointerCapture(event.pointerId);
								},
								onPointerMove: (event) => {
									const drag = cropDrag.current;
									const current = imageRef.current;
									if (!drag || !current) return;
									const point = pointerImage(event);
									if (!point) return;
									setCrop(dragCrop(drag.orig, drag.start, point, drag.handle, current.width, current.height));
								},
								onPointerUp: () => {
									cropDrag.current = null;
								},
								children: [
									"nw",
									"ne",
									"sw",
									"se"
								].map((handle) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": `Esquina ${handle}`,
									className: `absolute z-20 size-11 rounded-full border-4 border-ink bg-yellow ${handle.includes("n") ? "top-0 -translate-y-1/2" : "bottom-0 translate-y-1/2"} ${handle.includes("w") ? "left-0 -translate-x-1/2" : "right-0 translate-x-1/2"}`,
									onPointerDown: (event) => {
										event.stopPropagation();
										const point = pointerImage(event);
										if (!point || !crop) return;
										cropDrag.current = {
											handle,
											start: point,
											orig: crop
										};
										event.currentTarget.setPointerCapture(event.pointerId);
									}
								}, handle))
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [mode === "edit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `${sun} font-display flex-1 text-2xl tracking-wide`,
							onClick: () => void animate(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								className: "size-6",
								"aria-hidden": true
							}), "¡Animar!"]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `${ice} font-display flex-1 text-2xl tracking-wide`,
							onClick: backToEdit,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {
								className: "size-6",
								"aria-hidden": true
							}), "Modo edición"]
						}), mode === "play" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "blink sticker inline-flex min-h-11 items-center justify-center rounded-2xl bg-pink px-4 font-display text-lg text-ink",
							children: "Al aire"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-cream/80",
						role: "status",
						children: [
							caption,
							". ",
							notice
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "flex w-full shrink-0 flex-col gap-3 lg:min-h-0 lg:w-80 lg:overflow-y-auto lg:pr-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sticker rounded-card bg-cream p-3 text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl",
								children: "Imagen"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-ink/70",
								children: "JPG, PNG o WebP. También puedes soltarla sobre el escenario."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid grid-cols-2 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: sun,
										onClick: () => fileRef.current?.click(),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
											className: "size-5",
											"aria-hidden": true
										}), "Subir"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: solid,
										onClick: loadDemo,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
											className: "size-5",
											"aria-hidden": true
										}), "Bobo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: solid,
										onClick: knockOutBackground,
										disabled: !image || !!crop,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {
											className: "size-5",
											"aria-hidden": true
										}), "Quitar fondo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: solid,
										onClick: trimEdges,
										disabled: !image || !!crop,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scissors, {
											className: "size-5",
											"aria-hidden": true
										}), "Recortar sobrante"]
									}),
									crop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: sun,
										onClick: applyCrop,
										children: "Aplicar recorte"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: solid,
										onClick: () => setCrop(null),
										children: "Cancelar"
									})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: solid,
										onClick: beginCrop,
										disabled: !image,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crop, {
											className: "size-5",
											"aria-hidden": true
										}), "Recorte manual"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: solid,
										onClick: centerHead,
										disabled: !markers,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, {
											className: "size-5",
											"aria-hidden": true
										}), "Centrar cabeza"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: solid,
										onClick: fitAll,
										disabled: !image,
										children: "Ajustar"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: solid,
										onClick: doUndo,
										disabled: !undo,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {
											className: "size-5",
											"aria-hidden": true
										}), "Deshacer"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-3 block text-sm font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center justify-between",
									children: ["Fuerza al quitar fondo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-pink",
										children: Math.round(tolerance)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "slider",
									type: "range",
									min: 18,
									max: 120,
									step: 1,
									value: tolerance,
									onChange: (event) => setTolerance(Number(event.target.value))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileRef,
								className: "sr-only",
								type: "file",
								accept: "image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp",
								onChange: (event) => {
									onUpload(event.target.files?.[0]);
									event.target.value = "";
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sticker rounded-card bg-cream p-3 text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl",
								children: "Puntos"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-ink/70",
								children: "Cian: ojos. Amarillo: nariz y mandíbula. Rosa: el corte de la boca. La barbilla es lo que baja. Flechas del teclado empujan el punto enfocado."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid grid-cols-1 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: hot,
									onClick: () => void autoDetect(),
									disabled: !image || detecting,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanFace, {
										className: "size-5",
										"aria-hidden": true
									}), detecting ? "Buscando el rostro…" : "Auto-detectar rostro"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: solid,
									onClick: resetPoints,
									disabled: !image,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
										className: "size-5",
										"aria-hidden": true
									}), "Reiniciar puntos"]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sticker rounded-card bg-cream p-3 text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl",
								children: "Sonido"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-ink/70",
								children: "El micrófono no sale por los altavoces. El archivo y el beat sí."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid grid-cols-1 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: audioKind === "beat" ? hot : solid,
										"aria-pressed": audioKind === "beat",
										onClick: () => void useBeat(),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drum, {
											className: "size-5",
											"aria-hidden": true
										}), "Beat de prueba"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: audioKind === "mic" ? hot : solid,
										"aria-pressed": audioKind === "mic",
										onClick: () => void useMic(),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {
											className: "size-5",
											"aria-hidden": true
										}), "Micrófono en vivo"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: audioKind === "file" ? hot : solid,
										"aria-pressed": audioKind === "file",
										onClick: () => audioFileRef.current?.click(),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileAudio, {
											className: "size-5",
											"aria-hidden": true
										}), "Subir MP3 / WAV"]
									}),
									fileName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: `${solid} max-w-full overflow-hidden`,
										onClick: () => void toggleFilePlayback(),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, {
											className: "size-5 shrink-0",
											"aria-hidden": true
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: filePaused ? `Reproducir ${fileName}` : `Pausa ${fileName}`
										})]
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-3 block text-sm font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center justify-between",
									children: ["Volumen", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-pink",
										children: Math.round(volume * 100)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "slider",
									type: "range",
									min: 0,
									max: 1,
									step: .01,
									value: volume,
									onChange: (event) => {
										const next = Number(event.target.value);
										setVolume(next);
										audioRef.current?.setVolume(next);
									}
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex h-8 items-end gap-1",
								ref: meterRef,
								"aria-hidden": true,
								children: Array.from({ length: 10 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"data-bar": true,
									className: "h-full w-full origin-bottom rounded-sm bg-ink/15"
								}, index))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								ref: meterValue,
								className: "sr-only",
								role: "meter",
								"aria-label": "Nivel del audio",
								"aria-valuemin": 0,
								"aria-valuemax": 100,
								"aria-valuenow": 0
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: audioFileRef,
								className: "sr-only",
								type: "file",
								accept: "audio/mpeg,audio/wav,audio/wave,audio/x-wav,audio/mp3,.mp3,.wav",
								onChange: (event) => {
									onAudioFile(event.target.files?.[0]);
									event.target.value = "";
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "sticker rounded-card bg-cream p-3 text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl",
								children: "Efectos"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid grid-cols-1 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on: fx.rays,
										label: "Rayos giratorios",
										onClick: () => setFx((prev) => ({
											...prev,
											rays: !prev.rays
										}))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on: fx.spiral,
										label: "Espiral psicodélica",
										onClick: () => setFx((prev) => ({
											...prev,
											spiral: !prev.spiral
										}))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on: fx.stars,
										label: "Estrellas",
										onClick: () => setFx((prev) => ({
											...prev,
											stars: !prev.stars
										}))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on: fx.zoom,
										label: "Zoom al bajo",
										onClick: () => setFx((prev) => ({
											...prev,
											zoom: !prev.zoom
										}))
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm font-semibold",
								children: "Interior de la boca"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MouthButton, {
									current: fx.mouth,
									value: "black",
									label: "Negro sólido",
									onPick: (mouth) => setFx((prev) => ({
										...prev,
										mouth
									}))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MouthButton, {
									current: fx.mouth,
									value: "cartoon",
									label: "Rojo y lengua",
									onPick: (mouth) => setFx((prev) => ({
										...prev,
										mouth
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-3 block text-sm font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center justify-between",
									children: ["Sensibilidad de la boca", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-pink",
										children: fx.sensitivity.toFixed(1)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "slider",
									type: "range",
									min: .4,
									max: 2.4,
									step: .1,
									value: fx.sensitivity,
									onChange: (event) => setFx((prev) => ({
										...prev,
										sensitivity: Number(event.target.value)
									}))
								})]
							})
						]
					})
				]
			})]
		})]
	});
}
function Toggle({ on, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: `${solid} w-full justify-between`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `flex h-7 w-12 items-center rounded-full border-2 border-ink p-0.5 ${on ? "bg-pink" : "bg-cream"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-5 rounded-full border-2 border-ink bg-yellow ${on ? "translate-x-4" : "translate-x-0"}` })
		})]
	});
}
function MouthButton({ current, value, label, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": current === value,
		className: current === value ? hot : solid,
		onClick: () => onPick(value),
		children: label
	});
}
function clampPoint(point, image) {
	const padX = image.width * .08;
	const padY = image.height * .08;
	return {
		x: Math.max(-padX, Math.min(image.width + padX, point.x)),
		y: Math.max(-padY, Math.min(image.height + padY, point.y))
	};
}
function paintMeter(meter, value, level) {
	if (!meter) return;
	meter.querySelectorAll("[data-bar]").forEach((bar, index) => {
		const on = level * 12 > index;
		bar.style.transform = `scaleY(${on ? .35 + index * .07 : .2})`;
		bar.style.background = on ? index > 7 ? "var(--color-pink)" : "var(--color-yellow)" : "color-mix(in srgb, var(--color-ink) 15%, transparent)";
	});
	if (value) value.setAttribute("aria-valuenow", String(Math.round(level * 100)));
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PuppetApp, {});
}
//#endregion
export { Home as component };
